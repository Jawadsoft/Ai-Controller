import fetch from 'node-fetch';

async function testDAIVEChatComponent() {
  try {
    console.log('🧪 Testing D.A.I.V.E. Chat Component Integration...\n');
    
    const testData = {
      vehicleId: 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5',
      sessionId: 'component_test_' + Date.now(),
      message: 'I want an ideal car for my family',
      customerInfo: {
        name: 'Family Customer',
        email: 'family@example.com'
      }
    };
    
    console.log('📤 Testing family car request...');
    console.log('Message:', testData.message);
    
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    const data = await response.json();
    
    if (data.success) {
      console.log('✅ Component integration successful!');
      console.log('Response:', data.data.response);
      console.log('Lead Score:', data.data.leadScore + '%');
      console.log('Handoff:', data.data.shouldHandoff ? 'Yes' : 'No');
      
      // Test follow-up questions that would be triggered by quick actions
      const followUpTests = [
        'What safety features does this vehicle have?',
        'What is the price and financing options?',
        'Can I schedule a test drive?',
        'What are the fuel efficiency ratings?',
        'How much cargo space does it have?'
      ];
      
      console.log('\n🔄 Testing quick action responses...');
      
      for (const question of followUpTests) {
        const followUpData = {
          ...testData,
          message: question
        };
        
        const followUpResponse = await fetch('http://localhost:3000/api/daive/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(followUpData),
        });
        
        const followUpResult = await followUpResponse.json();
        
        if (followUpResult.success) {
          console.log(`✅ "${question}" - Lead Score: ${followUpResult.data.leadScore}%`);
        } else {
          console.log(`❌ "${question}" - Failed`);
        }
      }
      
    } else {
      console.log('❌ Component integration failed:', data.error);
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testDAIVEChatComponent(); 