// Test script to check ETL configurations
import { query } from './src/database/connection.js';

async function testETLConfigs() {
  try {
    console.log('🔍 Testing ETL configurations...');
    
    const dealerId = '2e00a324-5931-4377-aef1-9ee9362e11a6'; // dealer1@example.com
    
    // Check if any ETL configs exist
    const configsResult = await query(`
      SELECT 
        ec.*,
        cs.connection_type, cs.host_url, cs.port, cs.username, cs.remote_directory,
        ss.frequency, ss.time_hour, ss.time_minute, ss.day_of_week, ss.day_of_month,
        ffs.file_type, ffs.delimiter, ffs.multi_value_delimiter, ffs.include_header,
        fns.naming_pattern, fns.include_timestamp,
        comp.company_name, comp.company_id
      FROM etl_export_configs ec
      LEFT JOIN etl_connection_settings cs ON ec.id = cs.export_config_id
      LEFT JOIN etl_schedule_settings ss ON ec.id = ss.export_config_id
      LEFT JOIN etl_file_format_settings ffs ON ec.id = ffs.export_config_id
      LEFT JOIN etl_file_naming_settings fns ON ec.id = fns.export_config_id
      LEFT JOIN etl_company_settings comp ON ec.id = comp.export_config_id
      WHERE ec.dealer_id = $1
      ORDER BY ec.created_at DESC
    `, [dealerId]);
    
    console.log('\n=== ETL Configurations ===');
    console.log('Total configs found:', configsResult.rows.length);
    
    configsResult.rows.forEach((config, index) => {
      console.log(`\n--- Config ${index + 1} ---`);
      console.log('ID:', config.id);
      console.log('Config Name:', config.config_name);
      console.log('Dealer ID:', config.dealer_id);
      console.log('Is Active:', config.is_active);
      console.log('Created At:', config.created_at);
      console.log('Connection Type:', config.connection_type);
      console.log('Host URL:', config.host_url);
      console.log('Schedule Frequency:', config.frequency);
      console.log('File Type:', config.file_type);
      console.log('Company Name:', config.company_name);
    });
    
    // Check all ETL tables
    console.log('\n=== Database Tables Check ===');
    
    const tables = [
      'etl_export_configs',
      'etl_connection_settings', 
      'etl_schedule_settings',
      'etl_file_format_settings',
      'etl_file_naming_settings',
      'etl_company_settings'
    ];
    
    for (const table of tables) {
      const result = await query(`SELECT COUNT(*) as count FROM ${table}`);
      console.log(`${table}: ${result.rows[0].count} records`);
    }
    
  } catch (error) {
    console.error('❌ Error testing ETL configs:', error);
  }
}

testETLConfigs(); 