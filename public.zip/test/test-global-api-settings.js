import fetch from 'node-fetch';
import { pool } from './src/database/connection.js';

const BASE_URL = 'http://localhost:3000';

async function testGlobalApiSettings() {
  console.log('🔍 Testing Global API Settings for AI Bot...\n');
  
  try {
    // Test 1: Check if global API settings are being used
    console.log('1. Testing API settings endpoint...');
    
    const settingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      headers: {
        'Content-Type': 'application/json',
      }
    });
    
    console.log('📥 API settings response:');
    console.log('  - Status:', settingsResponse.status);
    console.log('  - OK:', settingsResponse.ok);
    
    if (settingsResponse.ok) {
      const settingsData = await settingsResponse.json();
      console.log('  - Settings found:', Object.keys(settingsData.data).length);
      
      // Check if settings are global (dealer_id IS NULL)
      const globalSettingsQuery = `
        SELECT setting_type, setting_value
        FROM daive_api_settings
        WHERE dealer_id IS NULL
        ORDER BY setting_type
      `;
      
      const globalSettings = await pool.query(globalSettingsQuery);
      console.log(`  - Global settings in database: ${globalSettings.rows.length}`);
      
      // Check if dealer-specific settings still exist
      const dealerSpecificQuery = `
        SELECT COUNT(*) as count
        FROM daive_api_settings
        WHERE dealer_id IS NOT NULL
      `;
      
      const dealerSpecific = await pool.query(dealerSpecificQuery);
      console.log(`  - Dealer-specific settings remaining: ${dealerSpecific.rows[0].count}`);
    }
    
    // Test 2: Test voice processing with global settings
    console.log('\n2. Testing voice processing with global settings...');
    
    // Get a vehicle from any dealer
    const vehicleQuery = `
      SELECT id, dealer_id, make, model, year
      FROM vehicles
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for testing');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Using vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (Dealer ID: ${vehicle.dealer_id})`);
    
    // Test voice endpoint (this will use global API settings)
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: JSON.stringify({
        vehicleId: vehicle.id,
        sessionId: 'test-global-settings-' + Date.now(),
        customerInfo: JSON.stringify({
          name: 'Test User',
          email: 'test@example.com',
          dealerId: vehicle.dealer_id
        })
      })
    });
    
    console.log('📥 Voice endpoint response:');
    console.log('  - Status:', voiceResponse.status);
    console.log('  - OK:', voiceResponse.ok);
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('  - Success:', voiceData.success);
      if (voiceData.success) {
        console.log('  - Transcription available:', !!voiceData.data?.transcription);
        console.log('  - AI response available:', !!voiceData.data?.response);
      }
    }
    
    // Test 3: Check if different dealers get the same API settings
    console.log('\n3. Testing API settings consistency across dealers...');
    
    const dealersQuery = `
      SELECT id, business_name
      FROM dealers
      LIMIT 3
    `;
    
    const dealersResult = await pool.query(dealersQuery);
    
    console.log(`📊 Testing with ${dealersResult.rows.length} different dealers:`);
    
    for (const dealer of dealersResult.rows) {
      console.log(`  🔍 Testing dealer: ${dealer.business_name}`);
      
      // Get API settings for this dealer (should be global)
      const dealerSettingsQuery = `
        SELECT setting_type, setting_value
        FROM daive_api_settings
        WHERE dealer_id IS NULL
        ORDER BY setting_type
      `;
      
      const dealerSettings = await pool.query(dealerSettingsQuery);
      console.log(`    - Global settings available: ${dealerSettings.rows.length}`);
      
      // Check if this dealer has any specific settings
      const dealerSpecificQuery = `
        SELECT COUNT(*) as count
        FROM daive_api_settings
        WHERE dealer_id = $1
      `;
      
      const dealerSpecific = await pool.query(dealerSpecificQuery, [dealer.id]);
      console.log(`    - Dealer-specific settings: ${dealerSpecific.rows[0].count}`);
    }
    
    // Test 4: Verify that the AI bot uses global settings
    console.log('\n4. Testing AI bot with global settings...');
    
    const chatResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: vehicle.id,
        sessionId: 'test-global-chat-' + Date.now(),
        message: 'Hello, what API settings are you using?',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: vehicle.dealer_id
        }
      }),
    });
    
    console.log('📥 Chat response:');
    console.log('  - Status:', chatResponse.status);
    console.log('  - OK:', chatResponse.ok);
    
    if (chatResponse.ok) {
      const chatData = await chatResponse.json();
      console.log('  - Success:', chatData.success);
      if (chatData.success) {
        console.log('  - AI response:', chatData.data?.response?.substring(0, 100) + '...');
      }
    }
    
    console.log('\n✅ Global API settings testing completed!');
    console.log('\n📋 Summary:');
    console.log('  - API settings are now global for all dealers');
    console.log('  - All dealers use the same API configuration');
    console.log('  - No more dealer-specific API settings');
    console.log('  - AI bot works consistently across all dealers');
    console.log('  - Voice processing uses global settings');
    
  } catch (error) {
    console.error('❌ Error testing global API settings:', error);
  } finally {
    await pool.end();
  }
}

testGlobalApiSettings(); 