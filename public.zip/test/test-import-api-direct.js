import fetch from 'node-fetch';

const API_BASE_URL = 'http://localhost:3000/api';

async function testImportAPI() {
  try {
    // Test without authentication first
    console.log('Testing import configs endpoint without auth...');
    const response = await fetch(`${API_BASE_URL}/import/configs`);
    console.log('Response status:', response.status);
    console.log('Response text:', await response.text());
    
    // Test with a fake token
    console.log('\nTesting with fake token...');
    const response2 = await fetch(`${API_BASE_URL}/import/configs`, {
      headers: {
        'Authorization': 'Bearer fake-token'
      }
    });
    console.log('Response status:', response2.status);
    console.log('Response text:', await response2.text());
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testImportAPI(); 