import fetch from 'node-fetch';

async function testOpenAITTSDirect() {
  try {
    console.log('🎤 Testing OpenAI TTS directly...\n');
    
    // Use the API key from the database check
    const apiKey = 'sk-proj-N3...c9cA'; // Replace with your actual key
    
    console.log('1. Testing OpenAI TTS API connection...');
    
    const testText = "Hello! I'm D.A.I.V.E., your AI vehicle assistant. This is a test of OpenAI TTS with the tts-1-hd model.";
    
    const response = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'tts-1-hd',
        input: testText,
        voice: 'alloy',
        response_format: 'mp3',
        speed: 1.0
      })
    });
    
    if (response.ok) {
      console.log('✅ OpenAI TTS API connection successful');
      const audioBuffer = await response.arrayBuffer();
      console.log(`📁 Audio file size: ${(audioBuffer.byteLength / 1024).toFixed(2)} KB`);
      console.log('🎵 Audio generated successfully!');
    } else {
      const errorText = await response.text();
      console.error('❌ OpenAI TTS API failed:', response.status, errorText);
    }
    
  } catch (error) {
    console.error('❌ OpenAI TTS test error:', error);
  }
}

testOpenAITTSDirect(); 