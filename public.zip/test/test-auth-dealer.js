import { pool } from './src/database/connection.js';

console.log('🔐 Testing authentication and dealer ID system...');

const testAuthDealer = async () => {
  try {
    // Check if we have any users with dealer profiles
    console.log('👥 Checking users with dealer profiles...');
    const usersResult = await pool.query(`
      SELECT u.id, u.email, u.role, dp.id as dealer_profile_id, dp.business_name
      FROM users u
      LEFT JOIN dealer_profiles dp ON u.id = dp.user_id
      WHERE u.role = 'dealer'
      LIMIT 5
    `);
    
    console.log('📊 Users with dealer profiles:');
    usersResult.rows.forEach(row => {
      console.log(`   - ${row.email} (${row.role}) - Dealer ID: ${row.dealer_profile_id || 'None'} - Business: ${row.business_name || 'None'}`);
    });
    
    // Check if we have any dealer profiles
    console.log('\n🏢 Checking dealer profiles...');
    const dealerProfilesResult = await pool.query(`
      SELECT id, user_id, business_name, contact_name
      FROM dealer_profiles
      LIMIT 5
    `);
    
    console.log('📊 Dealer profiles:');
    dealerProfilesResult.rows.forEach(row => {
      console.log(`   - ID: ${row.id} - User: ${row.user_id} - Business: ${row.business_name} - Contact: ${row.contact_name}`);
    });
    
    // Check if we have API keys for any dealers
    console.log('\n🔑 Checking API keys for dealers...');
    const apiKeysResult = await pool.query(`
      SELECT dealer_id, setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL
      AND setting_type IN ('openai_key', 'elevenlabs_key', 'deepgram_key')
      ORDER BY dealer_id, setting_type
    `);
    
    console.log('📊 API keys by dealer:');
    const dealerKeys = {};
    apiKeysResult.rows.forEach(row => {
      if (!dealerKeys[row.dealer_id]) {
        dealerKeys[row.dealer_id] = {};
      }
      dealerKeys[row.dealer_id][row.setting_type] = row.setting_value.substring(0, 8) + '...';
    });
    
    Object.entries(dealerKeys).forEach(([dealerId, keys]) => {
      console.log(`   - Dealer ${dealerId}:`);
      Object.entries(keys).forEach(([keyType, keyValue]) => {
        console.log(`     * ${keyType}: ${keyValue}`);
      });
    });
    
    // Check voice settings for dealers
    console.log('\n🎤 Checking voice settings for dealers...');
    const voiceSettingsResult = await pool.query(`
      SELECT dealer_id, setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL
      AND setting_type LIKE 'voice_%'
      ORDER BY dealer_id, setting_type
    `);
    
    console.log('📊 Voice settings by dealer:');
    const dealerVoiceSettings = {};
    voiceSettingsResult.rows.forEach(row => {
      if (!dealerVoiceSettings[row.dealer_id]) {
        dealerVoiceSettings[row.dealer_id] = {};
      }
      dealerVoiceSettings[row.dealer_id][row.setting_type] = row.setting_value;
    });
    
    Object.entries(dealerVoiceSettings).forEach(([dealerId, settings]) => {
      console.log(`   - Dealer ${dealerId}:`);
      Object.entries(settings).forEach(([settingType, settingValue]) => {
        console.log(`     * ${settingType}: ${settingValue}`);
      });
    });
    
    console.log('\n🎯 Summary:');
    if (dealerProfilesResult.rows.length > 0) {
      console.log('✅ Dealer profiles exist');
      if (Object.keys(dealerKeys).length > 0) {
        console.log('✅ API keys are configured for dealers');
        console.log('💡 Voice functionality should work for authenticated dealers');
      } else {
        console.log('⚠️ No API keys configured for dealers');
        console.log('💡 Configure API keys in DAIVE Settings for each dealer');
      }
    } else {
      console.log('❌ No dealer profiles found');
      console.log('💡 Create dealer profiles for users with dealer role');
    }
    
  } catch (error) {
    console.error('❌ Error testing auth dealer system:', error);
  } finally {
    await pool.end();
  }
};

testAuthDealer(); 