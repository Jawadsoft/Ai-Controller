// Simple test for local CSV preview endpoint
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Test if our CSV file exists
const testFile = path.join(__dirname, 'uploads', 'import', 'test-sample.csv');
console.log('Test CSV file path:', testFile);
console.log('File exists:', fs.existsSync(testFile));

if (fs.existsSync(testFile)) {
  console.log('File content preview:');
  const content = fs.readFileSync(testFile, 'utf8');
  console.log(content.substring(0, 200));
}

// Test CSV parsing with csv-parser
import('csv-parser').then(async (csvParserModule) => {
  const csvParser = csvParserModule.default;
  console.log('\nTesting CSV parser:');
  console.log('CSV parser type:', typeof csvParser);
  
  if (fs.existsSync(testFile)) {
    const results = [];
    let headers = [];
    
    fs.createReadStream(testFile)
      .pipe(csvParser())
      .on('headers', (headerList) => {
        console.log('Headers:', headerList);
        headers = headerList;
      })
      .on('data', (data) => {
        results.push(data);
      })
      .on('end', () => {
        console.log('Parsing complete!');
        console.log('Total rows:', results.length);
        console.log('Sample data:', results[0]);
        process.exit(0);
      })
      .on('error', (error) => {
        console.error('CSV parsing error:', error);
        process.exit(1);
      });
  }
}).catch(error => {
  console.error('Import error:', error);
  process.exit(1);
});