import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

async function testVoiceWithDeepgram() {
  try {
    console.log('🎤 Testing voice recognition with Deepgram...\n');
    
    // Create a test audio file
    const testAudioPath = path.join(process.cwd(), 'test-voice-deepgram.wav');
    
    // Create a simple WAV file for testing
    const sampleRate = 16000;
    const duration = 3; // 3 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate a simple tone (440 Hz sine wave)
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      const sample = Math.sin(2 * Math.PI * 440 * i / sampleRate) * 0.3;
      audioData.writeInt16LE(Math.floor(sample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(testAudioPath, wavFile);
    
    console.log('✅ Test audio file created');
    
    // Test the voice endpoint
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath), 'test-voice.wav');
    formData.append('vehicleId', '0fcaedd8-042e-4094-80ca-85cb71cd5584');
    formData.append('sessionId', `test_${Date.now()}`);
    formData.append('customerInfo', JSON.stringify({
      name: 'Test User',
      email: 'test@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }));
    
    console.log('📤 Sending voice data to backend...');
    
    const response = await fetch('http://localhost:3000/api/daive/voice', {
      method: 'POST',
      body: formData
    });
    
    console.log('📥 Response status:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Voice API response:');
      console.log(JSON.stringify(data, null, 2));
      
      if (data.success) {
        console.log('\n📝 Transcription:', data.data?.transcription);
        console.log('🤖 AI Response:', data.data?.response?.substring(0, 100) + '...');
        console.log('📊 Lead Score:', data.data?.leadScore);
        console.log('🔊 Audio Response:', data.data?.audioResponseUrl ? 'Generated' : 'None');
      }
    } else {
      const errorText = await response.text();
      console.error('❌ Voice API error:', response.status, errorText);
      
      // Handle specific error cases
      if (response.status === 400) {
        console.log('💡 This might be due to:');
        console.log('   - Voice recognition not configured');
        console.log('   - Missing API keys');
        console.log('   - Invalid audio format');
      } else if (response.status === 500) {
        console.log('💡 This might be due to:');
        console.log('   - Server error');
        console.log('   - Database connection issue');
        console.log('   - API service unavailable');
      }
    }
    
    // Clean up
    if (fs.existsSync(testAudioPath)) {
      fs.unlinkSync(testAudioPath);
      console.log('✅ Test audio file cleaned up');
    }
    
  } catch (error) {
    console.error('❌ Error testing voice with Deepgram:', error);
  }
}

testVoiceWithDeepgram(); 