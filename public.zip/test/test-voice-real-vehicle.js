import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { pool } from './src/database/connection.js';

const BASE_URL = 'http://localhost:3000';

async function testVoiceWithRealVehicle() {
  console.log('🎤 Testing Voice Endpoint with Real Vehicle...\n');
  
  try {
    // Get a real vehicle ID from the database
    console.log('1. Getting real vehicle ID from database...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id IS NOT NULL 
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found in database');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    console.log(`🏢 Dealer ID: ${vehicle.dealer_id}`);
    
    // Create a mock audio file
    const mockAudioPath = path.join(process.cwd(), 'test-voice-real.wav');
    const mockAudioContent = Buffer.from('mock audio content for testing', 'utf8');
    fs.writeFileSync(mockAudioPath, mockAudioContent);
    
    // Test voice endpoint with real vehicle
    console.log('\n2. Testing voice endpoint with real vehicle...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(mockAudioPath));
    formData.append('vehicleId', vehicle.id);
    formData.append('sessionId', 'test-session-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'Test Customer',
      email: 'test@example.com',
      dealerId: vehicle.dealer_id
    }));
    
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      body: formData
    });
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ Voice endpoint is working');
      console.log('📝 Response received');
      console.log('📝 Transcription:', voiceData.data?.transcription || 'No transcription');
      console.log('📝 Response:', voiceData.data?.response || 'No response');
      console.log('📝 Audio Response URL:', voiceData.data?.audioResponseUrl || 'No audio response');
      
      if (voiceData.data?.transcription === "Sorry, I couldn't understand your voice. Please try again.") {
        console.log('⚠️ This is expected for mock audio - real voice should work');
      }
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ Voice endpoint error');
      console.log('Status:', voiceResponse.status);
      console.log('Error:', errorData);
    }
    
    // Clean up test file
    if (fs.existsSync(mockAudioPath)) {
      fs.unlinkSync(mockAudioPath);
    }
    
    console.log('\n🎯 Voice Recognition Status:');
    console.log('✅ Voice endpoint is accessible');
    console.log('✅ Real vehicle ID is being used');
    console.log('✅ Dealer ID is being passed correctly');
    console.log('\n📱 To fix "voice recognition not configured":');
    console.log('1. Check that the dealer has OpenAI API key configured');
    console.log('2. Ensure voice is enabled in DAIVE Settings');
    console.log('3. Try speaking clearly when using the microphone');
    
  } catch (error) {
    console.error('❌ Error testing voice endpoint:', error.message);
  } finally {
    await pool.end();
  }
}

testVoiceWithRealVehicle(); 