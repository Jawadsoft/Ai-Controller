import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:dealeriq@localhost:5432/vehicle_management'
});

async function testImportFunction() {
  const client = await pool.connect();
  
  try {
    console.log('Testing import_vehicle_from_csv function...');
    
    // Test if function exists
    const functionCheck = await client.query(`
      SELECT routine_name 
      FROM information_schema.routines 
      WHERE routine_name = 'import_vehicle_from_csv'
    `);
    
    if (functionCheck.rows.length === 0) {
      console.error('❌ import_vehicle_from_csv function does not exist');
      console.log('Please run the add-vehicle-columns.sql script to create the function');
      return;
    }
    
    console.log('✅ import_vehicle_from_csv function exists');
    
    // Check what dealer IDs exist
    const dealersCheck = await client.query('SELECT id FROM dealers LIMIT 5');
    console.log('Available dealer IDs:', dealersCheck.rows.map(d => d.id));
    
    if (dealersCheck.rows.length === 0) {
      console.error('❌ No dealers found in database');
      return;
    }
    
    // Use the first available dealer ID
    const testDealerId = dealersCheck.rows[0].id;
    const testVin = 'TEST123456789';
    
    console.log(`Testing with Dealer ID: ${testDealerId}, VIN: ${testVin}`);
    
    const result = await client.query(`
      SELECT import_vehicle_from_csv(
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25
      ) as vehicle_id
    `, [
      testDealerId,
      testVin,
      'Test Make',
      'Test Model',
      'Test Series',
      'TEST001',
      'Sedan',
      false,
      'Red',
      'Black',
      'V6',
      '3.0L',
      'Navigation,Bluetooth',
      50000,
      25000.00,
      24000.00,
      'Automatic',
      28000.00,
      1000.00,
      500.00,
      200.00,
      1500.00,
      500.00,
      'https://example.com/photo.jpg',
      2020
    ]);
    
    console.log('✅ Function executed successfully');
    console.log('Vehicle ID:', result.rows[0].vehicle_id);
    
    // Check if vehicle was created
    const vehicleCheck = await client.query(
      'SELECT id, vin, dealer_id FROM vehicles WHERE vin = $1',
      [testVin]
    );
    
    if (vehicleCheck.rows.length > 0) {
      console.log('✅ Vehicle created in database');
      console.log('Vehicle details:', vehicleCheck.rows[0]);
    } else {
      console.error('❌ Vehicle not found in database');
    }
    
  } catch (error) {
    console.error('❌ Error testing import function:', error);
  } finally {
    client.release();
  }
}

testImportFunction()
  .then(() => {
    console.log('Test completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Test failed:', error);
    process.exit(1);
  }); 