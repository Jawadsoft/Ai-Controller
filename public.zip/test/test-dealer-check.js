import { Pool } from 'pg';

const pool = new Pool({
  connectionString: 'postgresql://postgres:dealeriq@localhost:5432/vehicle_management'
});

async function checkDealer() {
  try {
    const result = await pool.query('SELECT * FROM dealers WHERE id = $1', ['0aa94346-ed1d-420e-8823-bcd97bf6456f']);
    console.log('Dealer:', result.rows);
    
    if (result.rows.length > 0) {
      const dealer = result.rows[0];
      console.log('Dealer user_id:', dealer.user_id);
      
      // Check the user
      const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [dealer.user_id]);
      console.log('User:', userResult.rows);
    }
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await pool.end();
  }
}

checkDealer(); 