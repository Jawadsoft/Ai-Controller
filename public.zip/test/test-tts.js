import { pool } from './src/database/connection.js';

console.log('🧪 Testing TTS functionality...');

const testTTS = async () => {
  try {
    // Check global voice settings
    console.log('📊 Checking global voice settings...');
    const voiceSettingsResult = await pool.query(`
      SELECT setting_type, setting_value 
      FROM daive_api_settings 
      WHERE dealer_id IS NULL AND setting_type LIKE 'voice_%'
    `);
    
    console.log('Voice settings:');
    voiceSettingsResult.rows.forEach(row => {
      console.log(`   - ${row.setting_type}: ${row.setting_value}`);
    });
    
    // Check global API keys
    console.log('\n🔑 Checking global API keys...');
    const apiKeysResult = await pool.query(`
      SELECT setting_type, setting_value 
      FROM daive_api_settings 
      WHERE dealer_id IS NULL AND setting_type IN ('openai_key', 'elevenlabs_key', 'deepgram_key')
    `);
    
    console.log('API keys:');
    apiKeysResult.rows.forEach(row => {
      const keyPreview = row.setting_value.substring(0, 8) + '...';
      console.log(`   - ${row.setting_type}: ${keyPreview}`);
    });
    
    // Test if voice is enabled
    const voiceEnabled = voiceSettingsResult.rows.find(row => row.setting_type === 'voice_enabled')?.setting_value === 'true';
    const hasApiKeys = apiKeysResult.rows.length > 0;
    
    console.log('\n📋 TTS Status:');
    console.log(`   - Voice enabled: ${voiceEnabled ? '✅' : '❌'}`);
    console.log(`   - API keys available: ${hasApiKeys ? '✅' : '❌'}`);
    
    if (voiceEnabled && hasApiKeys) {
      console.log('\n🎉 TTS should be working!');
      console.log('💡 Try using voice input in the application now.');
    } else {
      console.log('\n⚠️ TTS is not properly configured:');
      if (!voiceEnabled) console.log('   - Voice is not enabled');
      if (!hasApiKeys) console.log('   - No API keys available');
    }
    
  } catch (error) {
    console.error('❌ Error testing TTS:', error);
  } finally {
    await pool.end();
  }
};

testTTS(); 