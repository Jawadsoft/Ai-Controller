import fetch from 'node-fetch';

const API_BASE_URL = 'http://localhost:8080/api';

async function testFrontendAPI() {
  try {
    console.log('Testing frontend API proxy...');
    
    // Test without authentication first
    const response = await fetch(`${API_BASE_URL}/import/configs`);
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    
    const responseText = await response.text();
    console.log('Response text (first 500 chars):', responseText.substring(0, 500));
    
    // Test with a fake token
    console.log('\nTesting with fake token...');
    const response2 = await fetch(`${API_BASE_URL}/import/configs`, {
      headers: {
        'Authorization': 'Bearer fake-token'
      }
    });
    console.log('Response status:', response2.status);
    const responseText2 = await response2.text();
    console.log('Response text (first 500 chars):', responseText2.substring(0, 500));
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testFrontendAPI(); 