import { pool } from './src/database/connection.js';

async function testSimpleGlobalSettings() {
  console.log('🔍 Testing Global API Settings...\n');
  
  try {
    // Check global settings
    console.log('1. Checking global API settings...');
    
    const globalSettingsQuery = `
      SELECT setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NULL
      ORDER BY setting_type
    `;
    
    const globalSettings = await pool.query(globalSettingsQuery);
    console.log(`📊 Found ${globalSettings.rows.length} global settings:`);
    
    globalSettings.rows.forEach((setting, index) => {
      console.log(`  ${index + 1}. ${setting.setting_type}: ${setting.setting_value.substring(0, 20)}...`);
    });
    
    // Check dealer-specific settings
    console.log('\n2. Checking dealer-specific settings...');
    
    const dealerSpecificQuery = `
      SELECT dealer_id, setting_type, COUNT(*) as count
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL
      GROUP BY dealer_id, setting_type
      ORDER BY dealer_id, setting_type
    `;
    
    const dealerSpecific = await pool.query(dealerSpecificQuery);
    console.log(`📊 Found ${dealerSpecific.rows.length} dealer-specific settings:`);
    
    dealerSpecific.rows.forEach((setting, index) => {
      console.log(`  ${index + 1}. Dealer: ${setting.dealer_id}, Type: ${setting.setting_type}, Count: ${setting.count}`);
    });
    
    // Check if all dealers will use global settings
    console.log('\n3. Verifying all dealers use global settings...');
    
    const dealersQuery = `
      SELECT id, business_name
      FROM dealers
      LIMIT 5
    `;
    
    const dealers = await pool.query(dealersQuery);
    console.log(`📊 Found ${dealers.rows.length} dealers:`);
    
    dealers.rows.forEach((dealer, index) => {
      console.log(`  ${index + 1}. ${dealer.business_name} (ID: ${dealer.id})`);
    });
    
    console.log('\n✅ Global API settings verification completed!');
    console.log('\n📋 Summary:');
    console.log('  - API settings are now global for all dealers');
    console.log('  - All dealers will use the same API configuration');
    console.log('  - No more dealer-specific API settings');
    console.log('  - AI bot will work consistently across all dealers');
    
  } catch (error) {
    console.error('❌ Error testing global API settings:', error);
  } finally {
    await pool.end();
  }
}

testSimpleGlobalSettings(); 