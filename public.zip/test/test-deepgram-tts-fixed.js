import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testDeepgramTTSFixed() {
  try {
    console.log('🧪 Testing Fixed Deepgram TTS Implementation...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Test the Deepgram TTS API connection
    console.log('\n2. Testing Deepgram TTS API connection...');
    const testTTSResponse = await fetch(`${BASE_URL}/api/daive/test-api`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ apiType: 'deepgram' })
    });

    const testTTSData = await testTTSResponse.json();
    console.log('📋 TTS Test Response:');
    console.log(JSON.stringify(testTTSData, null, 2));

    if (testTTSData.success && testTTSData.data.success) {
      console.log('✅ Deepgram TTS API connection successful!');
    } else {
      console.log('❌ Deepgram TTS API connection failed:', testTTSData.data?.message || 'Unknown error');
    }

    // Test voice conversation with text input (simulating chat with voice response)
    console.log('\n3. Testing voice conversation with text input...');
    const chatResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        vehicleId: 'test-vehicle-123',
        sessionId: 'test-session-456',
        message: 'Hello, can you tell me about this vehicle?',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com'
        }
      })
    });

    const chatData = await chatResponse.json();
    console.log('📋 Chat Response:');
    console.log(JSON.stringify(chatData, null, 2));

    if (chatData.success) {
      console.log('✅ Chat response successful!');
      console.log('💬 Response:', chatData.data.response);
      
      // Now test if we can generate audio for this response
      console.log('\n4. Testing audio generation for chat response...');
      
      // Get the Deepgram API key
      const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const apiSettingsData = await apiSettingsResponse.json();
      const deepgramKey = apiSettingsData.data.deepgram_key?.value;
      
      if (deepgramKey) {
        console.log('🔑 Using Deepgram API key to generate audio...');
        
        // Test direct Deepgram TTS call
        const ttsResponse = await fetch('https://api.deepgram.com/v1/speak', {
          method: 'POST',
          headers: {
            'Authorization': `Token ${deepgramKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            text: chatData.data.response
          })
        });

        if (ttsResponse.ok) {
          const audioBuffer = await ttsResponse.arrayBuffer();
          console.log('✅ Audio generation successful!');
          console.log('🔊 Audio buffer size:', audioBuffer.byteLength, 'bytes');
          
          // Save the audio file
          const fs = await import('fs');
          const audioFileName = `chat-response-${Date.now()}.mp3`;
          const audioPath = `./${audioFileName}`;
          fs.writeFileSync(audioPath, Buffer.from(audioBuffer));
          console.log('💾 Audio saved to:', audioPath);
          console.log('🎉 SUCCESS: Deepgram TTS is now working correctly!');
          
        } else {
          const errorText = await ttsResponse.text();
          console.log('❌ Audio generation failed:', errorText);
        }
      } else {
        console.log('❌ No Deepgram API key found');
      }
    } else {
      console.log('❌ Chat response failed:', chatData.error);
    }

  } catch (error) {
    console.error('❌ Error testing fixed Deepgram TTS:', error);
  }
}

// Run the test
testDeepgramTTSFixed(); 