import fetch from 'node-fetch';

const API_BASE_URL = 'http://localhost:3000/api';

async function testImportConfigs() {
  try {
    // Login with the correct dealer credentials
    console.log('Attempting to login with dealer1@example.com...');
    const loginResponse = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      })
    });

    if (!loginResponse.ok) {
      console.log('Login failed. Response:', await loginResponse.text());
      return;
    }

    const loginData = await loginResponse.json();
    console.log('Login successful:', loginData);
    
    // Test the import configs endpoint with the token
    const configsResponse = await fetch(`${API_BASE_URL}/import/configs`, {
      headers: {
        'Authorization': `Bearer ${loginData.token}`
      }
    });

    console.log('Import configs response status:', configsResponse.status);
    
    if (configsResponse.ok) {
      const configsData = await configsResponse.json();
      console.log('Import configs data:', configsData);
    } else {
      const errorText = await configsResponse.text();
      console.log('Import configs error:', errorText);
    }
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testImportConfigs(); 