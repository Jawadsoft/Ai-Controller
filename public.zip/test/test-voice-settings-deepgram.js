import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testDeepgramVoiceProvider() {
  try {
    console.log('🧪 Testing Deepgram Voice Provider Configuration...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Test data with Deepgram as voice provider
    const deepgramVoiceSettings = {
      enabled: true,
      language: 'en-US',
      voiceSpeed: 1.2,
      voicePitch: 1.1,
      voiceProvider: 'deepgram',
      speechProvider: 'deepgram',
      ttsProvider: 'deepgram'
    };

    console.log('\n📤 Setting voice provider to Deepgram:');
    console.log(JSON.stringify(deepgramVoiceSettings, null, 2));

    // Save voice settings with Deepgram
    const saveResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(deepgramVoiceSettings)
    });

    const saveResult = await saveResponse.json();
    console.log('\n💾 Save Response:');
    console.log(JSON.stringify(saveResult, null, 2));

    if (saveResult.success) {
      console.log('✅ Voice settings with Deepgram saved successfully!');
      
      // Now retrieve the settings to verify they were saved correctly
      console.log('\n📥 Retrieving saved voice settings...');
      
      const getResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const getResult = await getResponse.json();
      console.log('\n📋 Retrieved Voice Settings:');
      console.log(JSON.stringify(getResult, null, 2));

      if (getResult.success) {
        const settings = getResult.data;
        console.log('\n🔍 Verification:');
        console.log(`- Enabled: ${settings.enabled}`);
        console.log(`- Language: ${settings.language}`);
        console.log(`- Voice Speed: ${settings.voiceSpeed}`);
        console.log(`- Voice Pitch: ${settings.voicePitch}`);
        console.log(`- Voice Provider: ${settings.voiceProvider}`);
        console.log(`- Speech Provider: ${settings.speechProvider}`);
        console.log(`- TTS Provider: ${settings.ttsProvider}`);

        // Check if Deepgram is set as voice provider
        if (settings.voiceProvider === 'deepgram') {
          console.log('\n🎉 SUCCESS: Deepgram is now set as the voice provider!');
          console.log('✅ All voice-related providers are now using Deepgram');
        } else {
          console.log('\n❌ FAILURE: Voice provider is not set to Deepgram');
        }
      } else {
        console.log('\n❌ Failed to retrieve voice settings');
      }
    } else {
      console.log('\n❌ Failed to save voice settings');
    }

  } catch (error) {
    console.error('❌ Error testing Deepgram voice provider:', error);
  }
}

// Run the test
testDeepgramVoiceProvider(); 