// Import environment setup first (loads API keys from database)
import './setup-env.js';

import http from 'http';

const BASE_URL = 'localhost:3000';
const DEALER_ID = '0aa94346-ed1d-420e-8823-bcd97bf6456f';

// Helper function to make HTTP requests
function makeRequest(path, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json',
      }
    };

    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          resolve({
            status: res.statusCode,
            data: parsedData,
            headers: res.headers
          });
        } catch (error) {
          resolve({
            status: res.statusCode,
            data: responseData,
            headers: res.headers
          });
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    
    req.end();
  });
}

async function testCrewAI() {
  console.log('🧪 Testing Crew AI functionality...\n');

  // Check environment variables first
  console.log('🔧 Environment Check:');
  console.log('- OpenAI API Key:', process.env.OPENAI_API_KEY ? '✅ Set' : '❌ NOT SET');
  console.log('- Database URL:', process.env.DATABASE_URL ? '✅ Set' : '❌ NOT SET');
  console.log('- Port:', process.env.PORT || '❌ NOT SET');
  console.log('');

  if (!process.env.OPENAI_API_KEY) {
    console.log('❌ OpenAI API key not set!');
    console.log('💡 Please add your OpenAI API key to the daive_api_settings table');
    console.log('📝 You can:');
    console.log('   1. Run: node add-openai-key-to-db.js');
    console.log('   2. Or use the DAIVE Settings UI in your frontend');
    console.log('   3. Or set it manually in setup-env.js');
    return;
  }

  try {
    // Test 1: Check if backend is running
    console.log('1️⃣ Testing backend connectivity...');
    try {
      const healthResponse = await makeRequest(`/api/daive/crew-ai-settings?dealerId=${DEALER_ID}`);
      if (healthResponse.status === 200) {
        console.log('✅ Backend is running and responding');
      } else {
        console.log('❌ Backend responded with error:', healthResponse.status);
        return;
      }
    } catch (error) {
      console.log('❌ Backend is not accessible:', error.message);
      console.log('💡 Try starting the backend with: node src/server.js');
      return;
    }

    // Test 2: Check Crew AI settings
    console.log('\n2️⃣ Testing Crew AI settings...');
    try {
      const settingsResponse = await makeRequest(`/api/daive/crew-ai-settings?dealerId=${DEALER_ID}`);
      
      if (settingsResponse.status === 200 && settingsResponse.data.success) {
        console.log('✅ Crew AI settings loaded successfully');
        console.log('📋 Settings:', {
          enabled: settingsResponse.data.data.enabled,
          autoRouting: settingsResponse.data.data.autoRouting,
          enableSalesCrew: settingsResponse.data.data.enableSalesCrew,
          enableCustomerServiceCrew: settingsResponse.data.data.enableCustomerServiceCrew,
          enableInventoryCrew: settingsResponse.data.data.enableInventoryCrew
        });
      } else {
        console.log('❌ Failed to load Crew AI settings:', settingsResponse.data.error || 'Unknown error');
      }
    } catch (error) {
      console.log('❌ Error loading Crew AI settings:', error.message);
    }

    // Test 3: Test regular chat endpoint
    console.log('\n3️⃣ Testing regular chat endpoint...');
    try {
      const chatPayload = {
        vehicleId: null,
        sessionId: 'test-session-' + Date.now(),
        message: 'Hello, this is a test message. Can you help me find a family car?',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: DEALER_ID
        }
      };

      const chatResponse = await makeRequest('/api/daive/chat', 'POST', chatPayload);

      if (chatResponse.status === 200) {
        console.log('✅ Chat endpoint responded successfully');
        console.log('📋 Response structure:', {
          success: chatResponse.data.success,
          hasData: !!chatResponse.data.data,
          dataKeys: chatResponse.data.data ? Object.keys(chatResponse.data.data) : 'No data',
          hasResponse: !!chatResponse.data.data?.response,
          responseLength: chatResponse.data.data?.response?.length || 0,
          responsePreview: chatResponse.data.data?.response?.substring(0, 100) + '...'
        });
        
        if (chatResponse.data.success && chatResponse.data.data?.response) {
          console.log('🎉 AI response generated successfully!');
          console.log('🤖 Response preview:', chatResponse.data.data.response.substring(0, 200) + '...');
        } else {
          console.log('⚠️ Chat endpoint worked but no AI response generated');
          console.log('🔍 Full response data:', JSON.stringify(chatResponse.data, null, 2));
        }
      } else {
        console.log('❌ Chat endpoint failed:', chatResponse.status, chatResponse.data);
      }
    } catch (error) {
      console.log('❌ Error testing chat endpoint:', error.message);
    }

    // Test 4: Test Crew AI endpoint
    console.log('\n4️⃣ Testing Crew AI endpoint...');
    try {
      const crewAIPayload = {
        vehicleId: null,
        sessionId: 'test-crew-ai-' + Date.now(),
        message: 'I need help with financing options for a new vehicle',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: DEALER_ID
        }
      };

      const crewAIResponse = await makeRequest('/api/daive/crew-ai', 'POST', crewAIPayload);

      if (crewAIResponse.status === 200) {
        console.log('✅ Crew AI endpoint responded successfully');
        console.log('📋 Crew AI response structure:', {
          success: crewAIResponse.data.success,
          hasData: !!crewAIResponse.data.data,
          dataKeys: crewAIResponse.data.data ? Object.keys(crewAIResponse.data.data) : 'No data',
          hasResponse: !!crewAIResponse.data.data?.response,
          responseLength: crewAIResponse.data.data?.response?.length || 0,
          crewUsed: crewAIResponse.data.data?.crewUsed,
          crewType: crewAIResponse.data.data?.crewType
        });
        
        if (crewAIResponse.data.success && crewAIResponse.data.data?.response) {
          console.log('🎉 Crew AI response generated successfully!');
          console.log('🤖 Response preview:', crewAIResponse.data.data.response.substring(0, 200) + '...');
        } else {
          console.log('⚠️ Crew AI endpoint worked but no AI response generated');
          console.log('🔍 Full response data:', JSON.stringify(crewAIResponse.data, null, 2));
        }
      } else {
        console.log('❌ Crew AI endpoint failed:', crewAIResponse.status, crewAIResponse.data);
      }
    } catch (error) {
      console.log('❌ Error testing Crew AI endpoint:', error.message);
    }

    // Test 5: Check for common issues
    console.log('\n5️⃣ Checking for common issues...');
    console.log('📝 Check your backend console for any error messages');
    console.log('🔑 Verify that your OpenAI API key is configured');
    console.log('🗄️ Check if your database is running and accessible');
    console.log('⚙️ Verify that Crew AI services are properly initialized');

  } catch (error) {
    console.error('❌ Test failed with error:', error);
  }
}

// Run the test
testCrewAI().then(() => {
  console.log('\n🏁 Crew AI testing completed!');
  console.log('📊 Check the results above to identify any issues.');
}).catch(error => {
  console.error('💥 Test execution failed:', error);
}); 