import jwt from 'jsonwebtoken';

// Use the same secret as in env.example
const JWT_SECRET = 'your-super-secret-jwt-key-here';

// Create a token for the dealer user
const token = jwt.sign(
  { userId: '2e00a324-5931-4377-aef1-9ee9362e11a6' }, // This is the dealer1 user ID
  JWT_SECRET,
  { expiresIn: '7d' }
);

console.log('Generated JWT token:', token);

// Test the token
try {
  const decoded = jwt.verify(token, JWT_SECRET);
  console.log('Token is valid, decoded:', decoded);
} catch (error) {
  console.error('Token verification failed:', error);
} 