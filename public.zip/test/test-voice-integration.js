import { pool } from './src/database/connection.js';

async function testVoiceIntegration() {
  try {
    console.log('🎵 Testing Voice Integration for dealer1@example.com...\n');
    
    // Get dealer ID and API settings
    const dealerResult = await pool.query(
      'SELECT id FROM dealers WHERE email = $1',
      ['dealer1@example.com']
    );
    
    if (dealerResult.rows.length === 0) {
      console.log('❌ Dealer not found');
      return;
    }
    
    const dealerId = dealerResult.rows[0].id;
    
    // Get ElevenLabs API key
    const apiResult = await pool.query(
      'SELECT setting_value FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
      [dealerId, 'elevenlabs_key']
    );
    
    if (apiResult.rows.length === 0 || !apiResult.rows[0].setting_value) {
      console.log('❌ ElevenLabs API key not found');
      return;
    }
    
    const elevenLabsKey = apiResult.rows[0].setting_value;
    console.log('✅ ElevenLabs API key found');
    
    // Test ElevenLabs API connection
    console.log('\n🔗 Testing ElevenLabs API connection...');
    try {
      const response = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: {
          'xi-api-key': elevenLabsKey,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const voices = await response.json();
        console.log('✅ ElevenLabs API connection successful!');
        console.log(`📊 Available voices: ${voices.voices?.length || 0}`);
        
        if (voices.voices && voices.voices.length > 0) {
          console.log('🎤 Sample voices available:');
          voices.voices.slice(0, 3).forEach(voice => {
            console.log(`   - ${voice.name} (${voice.voice_id})`);
          });
        }
      } else {
        console.log('❌ ElevenLabs API connection failed');
        console.log(`Status: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.log('❌ Error testing ElevenLabs API:', error.message);
    }
    
    // Test voice synthesis
    console.log('\n🎵 Testing voice synthesis...');
    try {
      const testText = "Hello! I'm D.A.I.V.E., your AI sales assistant. How can I help you today?";
      const voiceId = "21m00Tcm4TlvDq8ikWAM"; // Rachel voice
      
      const synthesisResponse = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'xi-api-key': elevenLabsKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: testText,
          model_id: "eleven_monolingual_v1",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5
          }
        })
      });
      
      if (synthesisResponse.ok) {
        console.log('✅ Voice synthesis test successful!');
        console.log('📝 Test text processed successfully');
        console.log('🎤 Voice response would be generated in real conversations');
      } else {
        console.log('❌ Voice synthesis test failed');
        console.log(`Status: ${synthesisResponse.status} ${synthesisResponse.statusText}`);
      }
    } catch (error) {
      console.log('❌ Error testing voice synthesis:', error.message);
    }
    
    console.log('\n🎯 Voice Integration Summary:');
    console.log('✅ ElevenLabs API key is configured');
    console.log('✅ API connection is working');
    console.log('✅ Voice synthesis is ready');
    console.log('\n📱 Next Steps:');
    console.log('1. Go to DAIVE Settings → Voice Settings');
    console.log('2. Enable "Voice Responses"');
    console.log('3. Select "ElevenLabs" as provider');
    console.log('4. Test in a vehicle conversation');
    
  } catch (error) {
    console.error('❌ Error testing voice integration:', error);
  } finally {
    await pool.end();
  }
}

testVoiceIntegration(); 