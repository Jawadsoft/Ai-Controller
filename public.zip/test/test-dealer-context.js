import fetch from 'node-fetch';
import { pool } from './src/database/connection.js';

const BASE_URL = 'http://localhost:3000';

async function testDealerContext() {
  console.log('🔍 Testing Dealer Context for AI Bot...\n');
  
  try {
    // Get Clay Cooley's dealer information
    console.log('1. Getting Clay Cooley dealer information...');
    const dealerQuery = `
      SELECT id, business_name, email 
      FROM dealers 
      WHERE business_name ILIKE '%clay cooley%' 
      OR business_name ILIKE '%clay%cooley%'
      LIMIT 1
    `;
    
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length === 0) {
      console.log('❌ Clay Cooley dealer not found in database');
      return;
    }
    
    const dealer = dealerResult.rows[0];
    console.log(`✅ Found dealer: ${dealer.business_name} (ID: ${dealer.id})`);
    
    // Get a vehicle from Clay Cooley's inventory
    console.log('\n2. Getting vehicle from Clay Cooley inventory...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id = $1
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery, [dealer.id]);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for Clay Cooley');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    
    // Test 1: Check if the dealer context is being passed correctly
    console.log('\n3. Testing dealer context in AI bot...');
    
    const testResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: vehicle.id,
        sessionId: 'dealer-context-test-' + Date.now(),
        message: 'Hello, what dealership am I talking to?',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com',
          dealerId: dealer.id
        }
      }),
    });
    
    const testData = await testResponse.json();
    console.log('📥 AI Bot response:');
    console.log('  - Status:', testResponse.status);
    console.log('  - Success:', testData.success);
    if (testData.success) {
      console.log('  - Response:', testData.response);
      console.log('  - Contains Clay Cooley:', testData.response.toLowerCase().includes('clay cooley'));
      console.log('  - Contains dealer name:', testData.response.toLowerCase().includes(dealer.business_name.toLowerCase()));
    }
    
    // Test 2: Check if the system prompt includes the correct dealer
    console.log('\n4. Testing system prompt dealer context...');
    
    // Get the vehicle context to see what dealer is being used
    const vehicleContextQuery = `
      SELECT v.*, d.business_name, d.id as dealer_id
      FROM vehicles v
      JOIN dealers d ON v.dealer_id = d.id
      WHERE v.id = $1
    `;
    
    const vehicleContextResult = await pool.query(vehicleContextQuery, [vehicle.id]);
    
    if (vehicleContextResult.rows.length > 0) {
      const vehicleContext = vehicleContextResult.rows[0];
      console.log('📊 Vehicle context:');
      console.log('  - Vehicle:', `${vehicleContext.year} ${vehicleContext.make} ${vehicleContext.model}`);
      console.log('  - Dealer ID:', vehicleContext.dealer_id);
      console.log('  - Dealer Name:', vehicleContext.business_name);
      console.log('  - Expected Dealer:', dealer.business_name);
      console.log('  - Dealer Match:', vehicleContext.business_name === dealer.business_name);
    }
    
    // Test 3: Check if there are any vehicles from other dealers
    console.log('\n5. Checking for vehicles from other dealers...');
    
    const otherDealersQuery = `
      SELECT DISTINCT d.business_name, d.id, COUNT(v.id) as vehicle_count
      FROM dealers d
      LEFT JOIN vehicles v ON d.id = v.dealer_id
      WHERE d.id != $1
      GROUP BY d.id, d.business_name
      HAVING COUNT(v.id) > 0
    `;
    
    const otherDealersResult = await pool.query(otherDealersQuery, [dealer.id]);
    
    console.log(`📊 Found ${otherDealersResult.rows.length} other dealers with vehicles:`);
    otherDealersResult.rows.forEach((otherDealer, index) => {
      console.log(`  ${index + 1}. ${otherDealer.business_name} (${otherDealer.vehicle_count} vehicles)`);
    });
    
    // Test 4: Verify that the AI bot only offers vehicles from the correct dealer
    console.log('\n6. Testing AI bot dealer isolation...');
    
    const isolationResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: vehicle.id,
        sessionId: 'dealer-isolation-test-' + Date.now(),
        message: 'Show me other vehicles you have',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com',
          dealerId: dealer.id
        }
      }),
    });
    
    const isolationData = await isolationResponse.json();
    console.log('📥 Isolation test response:');
    console.log('  - Status:', isolationResponse.status);
    console.log('  - Success:', isolationData.success);
    if (isolationData.success) {
      console.log('  - Response:', isolationData.response.substring(0, 200) + '...');
      console.log('  - Mentions correct dealer:', isolationData.response.toLowerCase().includes(dealer.business_name.toLowerCase()));
      
      // Check if it mentions any other dealers
      const mentionsOtherDealers = otherDealersResult.rows.some(otherDealer => 
        isolationData.response.toLowerCase().includes(otherDealer.business_name.toLowerCase())
      );
      console.log('  - Mentions other dealers:', mentionsOtherDealers);
    }
    
    console.log('\n✅ Dealer context testing completed!');
    console.log('\n📋 Summary:');
    console.log('  - AI bot should now use the correct dealer context');
    console.log('  - System prompt should include the specific dealer name');
    console.log('  - Alternative vehicles should only be from the current dealer');
    console.log('  - No cross-dealer contamination should occur');
    
  } catch (error) {
    console.error('❌ Error testing dealer context:', error);
  } finally {
    await pool.end();
  }
}

testDealerContext(); 