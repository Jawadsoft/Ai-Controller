import fetch from 'node-fetch';

async function testDAIVEPrompts() {
  try {
    console.log('🧪 Testing D.A.I.V.E. prompts endpoint...\n');
    
    // First, let's get a valid auth token for dealer1@example.com
    console.log('1. Getting auth token...');
    const loginResponse = await fetch('http://localhost:3000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');
    
    // Test GET prompts
    console.log('\n2. Testing GET /api/daive/prompts...');
    const getResponse = await fetch('http://localhost:3000/api/daive/prompts', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log(`GET Response Status: ${getResponse.status}`);
    const getText = await getResponse.text();
    console.log(`GET Response: ${getText}`);
    
    if (getResponse.ok) {
      const getData = JSON.parse(getText);
      console.log('✅ GET prompts successful');
      console.log('Prompts:', Object.keys(getData.data));
    } else {
      console.log('❌ GET prompts failed');
    }
    
    // Test POST prompts
    console.log('\n3. Testing POST /api/daive/prompts...');
    const postData = {
      promptType: 'greeting',
      promptText: 'Hi! I\'m D.A.I.V.E., your AI sales assistant. How can I help you today?'
    };
    
    const postResponse = await fetch('http://localhost:3000/api/daive/prompts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(postData)
    });
    
    console.log(`POST Response Status: ${postResponse.status}`);
    const postText = await postResponse.text();
    console.log(`POST Response: ${postText}`);
    
    if (postResponse.ok) {
      const postData = JSON.parse(postText);
      console.log('✅ POST prompts successful');
    } else {
      console.log('❌ POST prompts failed');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error('Stack:', error.stack);
  }
}

testDAIVEPrompts(); 