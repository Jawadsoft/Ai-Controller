const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

async function testGPT4oVoice() {
  console.log('🧪 Testing GPT-4o Real-time Voice...\n');
  
  try {
    // Create a simple test audio file (1 second of silence)
    const testAudioPath = './test-gpt4o-audio.wav';
    const testAudioBuffer = Buffer.alloc(44 + 16000 * 2); // 1 second of 16kHz audio
    
    // Write WAV header
    testAudioBuffer.write('RIFF', 0);
    testAudioBuffer.writeUInt32LE(36 + 16000 * 2, 4);
    testAudioBuffer.write('WAVE', 8);
    testAudioBuffer.write('fmt ', 12);
    testAudioBuffer.writeUInt32LE(16, 16);
    testAudioBuffer.writeUInt16LE(1, 20);
    testAudioBuffer.writeUInt16LE(1, 22);
    testAudioBuffer.writeUInt32LE(16000, 24);
    testAudioBuffer.writeUInt32LE(32000, 28);
    testAudioBuffer.writeUInt16LE(2, 32);
    testAudioBuffer.writeUInt16LE(16, 34);
    testAudioBuffer.write('data', 36);
    testAudioBuffer.writeUInt32LE(16000 * 2, 40);
    
    fs.writeFileSync(testAudioPath, testAudioBuffer);

    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath), 'test-gpt4o-audio.wav');
    formData.append('vehicleId', 'test-vehicle-id');
    formData.append('sessionId', 'gpt4o-test-session-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'GPT-4o Test User',
      email: 'gpt4o-test@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }));

    console.log('📤 Sending request to GPT-4o voice endpoint...');
    const response = await fetch('http://localhost:3000/api/daive/gpt4o-voice', {
      method: 'POST',
      body: formData
    });

    const data = await response.json();
    console.log('📥 Response Status:', response.status);
    console.log('📥 Response Data:', {
      success: data.success,
      hasTranscription: !!data.data?.transcription,
      hasResponse: !!data.data?.response,
      hasAudioUrl: !!data.data?.audioResponseUrl,
      model: data.data?.model,
      audioUrl: data.data?.audioResponseUrl,
      transcription: data.data?.transcription,
      responseLength: data.data?.response?.length || 0
    });

    if (data.success) {
      console.log('✅ GPT-4o voice processing successful!');
      console.log('🎤 Model:', data.data?.model);
      console.log('📝 Transcription:', data.data?.transcription);
      console.log('🤖 Response:', data.data?.response?.substring(0, 100) + '...');
      console.log('🔊 Audio URL:', data.data?.audioResponseUrl);
      
      if (data.data?.audioResponseUrl) {
        console.log('🎵 Audio response generated successfully');
        console.log('📁 Audio file saved at:', data.data.audioResponseUrl);
      }
    } else {
      console.log('❌ GPT-4o voice processing failed');
      console.log('🔍 Error:', data.error);
    }

    // Clean up test file
    fs.unlinkSync(testAudioPath);
    
  } catch (error) {
    console.error('❌ Error testing GPT-4o voice:', error);
  }
}

// Run the test
testGPT4oVoice().catch(console.error); 