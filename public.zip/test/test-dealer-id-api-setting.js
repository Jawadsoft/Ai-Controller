import { pool } from './src/database/connection.js';

async function testDealerIdApiSetting() {
  try {
    console.log('🧪 Testing Dealer ID API Setting Integration...\n');
    
    // Test 1: Check if dealer_id is accepted as a valid setting type
    console.log('📝 Test 1: Validating dealer_id setting type');
    
    const testDealerId = 'TEST_DEALER_12345';
    
    // Insert a test dealer_id setting
    const insertQuery = `
      INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
      VALUES (NULL, $1, $2)
      ON CONFLICT (dealer_id, setting_type) 
      DO UPDATE SET setting_value = $2, updated_at = NOW()
      RETURNING *
    `;
    
    const insertResult = await pool.query(insertQuery, ['dealer_id', testDealerId]);
    
    if (insertResult.rows.length > 0) {
      console.log('✅ Successfully inserted dealer_id setting');
      console.log(`   Setting ID: ${insertResult.rows[0].id}`);
      console.log(`   Setting Type: ${insertResult.rows[0].setting_type}`);
      console.log(`   Setting Value: ${insertResult.rows[0].setting_value}`);
    } else {
      console.log('❌ Failed to insert dealer_id setting');
      return;
    }
    
    // Test 2: Retrieve the dealer_id setting
    console.log('\n📋 Test 2: Retrieving dealer_id setting');
    
    const selectQuery = `
      SELECT setting_type, setting_value, is_active, created_at, updated_at
      FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type = 'dealer_id'
    `;
    
    const selectResult = await pool.query(selectQuery);
    
    if (selectResult.rows.length > 0) {
      const setting = selectResult.rows[0];
      console.log('✅ Successfully retrieved dealer_id setting');
      console.log(`   Setting Type: ${setting.setting_type}`);
      console.log(`   Setting Value: ${setting.setting_value}`);
      console.log(`   Is Active: ${setting.is_active}`);
      console.log(`   Created At: ${setting.created_at}`);
      console.log(`   Updated At: ${setting.updated_at}`);
    } else {
      console.log('❌ Failed to retrieve dealer_id setting');
      return;
    }
    
    // Test 3: Update the dealer_id setting
    console.log('\n🔄 Test 3: Updating dealer_id setting');
    
    const updatedDealerId = 'UPDATED_DEALER_67890';
    const updateResult = await pool.query(insertQuery, ['dealer_id', updatedDealerId]);
    
    if (updateResult.rows.length > 0) {
      console.log('✅ Successfully updated dealer_id setting');
      console.log(`   New Value: ${updateResult.rows[0].setting_value}`);
    } else {
      console.log('❌ Failed to update dealer_id setting');
    }
    
    // Test 4: Test API endpoint simulation
    console.log('\n🌐 Test 4: Simulating API endpoint validation');
    
    const validSettingTypes = ['openai_key', 'elevenlabs_key', 'azure_speech_key', 'deepgram_key', 'voice_provider', 'voice_speech_provider', 'voice_tts_provider', 'openai_tts', 'dealer_id'];
    
    if (validSettingTypes.includes('dealer_id')) {
      console.log('✅ dealer_id is included in valid setting types');
    } else {
      console.log('❌ dealer_id is NOT included in valid setting types');
    }
    
    // Test 5: Retrieve all API settings to see dealer_id in context
    console.log('\n📊 Test 5: Retrieving all API settings');
    
    const allSettingsQuery = `
      SELECT setting_type, setting_value, is_active
      FROM daive_api_settings
      WHERE dealer_id IS NULL
      ORDER BY setting_type
    `;
    
    const allSettingsResult = await pool.query(allSettingsQuery);
    
    console.log('📋 All Global API Settings:');
    allSettingsResult.rows.forEach(row => {
      const maskedValue = row.setting_value && row.setting_value.length > 10 ? 
        row.setting_value.substring(0, 8) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
        row.setting_value || 'Not set';
      console.log(`   ${row.setting_type}: ${maskedValue} (Active: ${row.is_active})`);
    });
    
    // Test 6: Test deletion
    console.log('\n🗑️ Test 6: Testing dealer_id setting deletion');
    
    const deleteQuery = `
      DELETE FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type = 'dealer_id'
      RETURNING *
    `;
    
    const deleteResult = await pool.query(deleteQuery);
    
    if (deleteResult.rows.length > 0) {
      console.log('✅ Successfully deleted dealer_id setting');
      console.log(`   Deleted Value: ${deleteResult.rows[0].setting_value}`);
    } else {
      console.log('❌ Failed to delete dealer_id setting (or setting not found)');
    }
    
    // Test 7: Verify deletion
    console.log('\n🔍 Test 7: Verifying deletion');
    
    const verifyResult = await pool.query(selectQuery);
    
    if (verifyResult.rows.length === 0) {
      console.log('✅ Confirmed: dealer_id setting has been deleted');
    } else {
      console.log('❌ Error: dealer_id setting still exists after deletion');
    }
    
    console.log('\n🎉 All tests completed successfully!');
    console.log('\n📝 Summary:');
    console.log('   ✅ dealer_id can be stored as an API setting');
    console.log('   ✅ dealer_id can be retrieved from the database');
    console.log('   ✅ dealer_id can be updated');
    console.log('   ✅ dealer_id is included in valid setting types');
    console.log('   ✅ dealer_id can be deleted');
    console.log('   ✅ Integration with existing API settings works correctly');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

// Run the test
testDealerIdApiSetting();