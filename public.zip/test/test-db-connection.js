import pg from 'pg';
import dotenv from 'dotenv';

const { Pool } = pg;
dotenv.config();

async function testDatabaseConnection() {
  console.log('Testing database connection...');
  console.log('Environment:', process.env.NODE_ENV || 'development');
  
  // Check if DATABASE_URL is set
  if (!process.env.DATABASE_URL) {
    console.error('❌ DATABASE_URL environment variable is not set');
    console.log('Please create a .env file with your DATABASE_URL');
    console.log('Example: DATABASE_URL=postgresql://username:password@localhost:5432/database_name');
    return;
  }

  // Create a new pool for testing
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
  });

  try {
    console.log('🔌 Attempting to connect to PostgreSQL...');
    
    // Test the connection
    const client = await pool.connect();
    console.log('✅ Successfully connected to PostgreSQL!');
    
    // Get database info
    const result = await client.query('SELECT version(), current_database(), current_user');
    console.log('\n📊 Database Information:');
    console.log('Version:', result.rows[0].version.split(' ')[0] + ' ' + result.rows[0].version.split(' ')[1]);
    console.log('Database:', result.rows[0].current_database);
    console.log('User:', result.rows[0].current_user);
    
    // Test a simple query
    const tableResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);
    
    console.log('\n📋 Tables in database:');
    if (tableResult.rows.length === 0) {
      console.log('   No tables found (database might be empty)');
    } else {
      tableResult.rows.forEach(row => {
        console.log(`   - ${row.table_name}`);
      });
    }
    
    client.release();
    console.log('\n✅ Database connection test completed successfully!');
    
  } catch (error) {
    console.error('❌ Database connection failed:');
    console.error('Error:', error.message);
    
    if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Troubleshooting tips:');
      console.log('1. Make sure PostgreSQL is running');
      console.log('2. Check if the port (usually 5432) is correct');
      console.log('3. Verify the host address');
    } else if (error.code === '28P01') {
      console.log('\n💡 Authentication failed. Check your username and password.');
    } else if (error.code === '3D000') {
      console.log('\n💡 Database does not exist. Create the database first.');
    }
    
  } finally {
    await pool.end();
  }
}

// Run the test
testDatabaseConnection(); 