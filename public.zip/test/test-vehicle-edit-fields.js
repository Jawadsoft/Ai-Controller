// Test script to verify vehicle edit functionality with all new fields
import fetch from 'node-fetch';

const API_BASE_URL = 'http://localhost:3000/api';

// Test data with all new fields
const testVehicleData = {
  vin: '1HGBH41JXMN109186',
  make: 'Honda',
  model: 'Civic',
  year: 2024,
  status: 'available',
  stock_number: 'H0102718',
  series: 'Grand Touring',
  trim: 'EX-L',
  body_style: '4D Sedan',
  color: 'Crystal Black Pearl',
  interior_color: 'Black',
  mileage: 15000.5,
  odometer: 15000,
  price: 25000.00,
  msrp: 28000.00,
  engine_type: 'I4',
  displacement: '2.0L',
  transmission: 'CVT',
  certified: true,
  dealer_discount: 2000.00,
  consumer_rebate: 1000.00,
  dealer_accessories: 500.00,
  total_customer_savings: 3000.00,
  total_dealer_rebate: 1500.00,
  other_price: 24000.00,
  description: 'Excellent condition, one owner, full service history',
  features: ['Bluetooth', 'Backup Camera', 'Apple CarPlay', 'Android Auto']
};

async function testVehicleEditFields() {
  try {
    console.log('🧪 Testing Vehicle Edit Functionality with All New Fields');
    console.log('=' .repeat(60));

    // Step 1: Create a test vehicle with all fields
    console.log('\n1️⃣ Creating test vehicle with all new fields...');
    const createResponse = await fetch(`${API_BASE_URL}/vehicles`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_TEST_TOKEN' // Replace with actual token
      },
      body: JSON.stringify(testVehicleData)
    });

    if (!createResponse.ok) {
      console.log('❌ Failed to create test vehicle');
      console.log('Status:', createResponse.status);
      const error = await createResponse.text();
      console.log('Error:', error);
      return;
    }

    const createdVehicle = await createResponse.json();
    console.log('✅ Test vehicle created successfully');
    console.log('Vehicle ID:', createdVehicle.id);

    // Step 2: Fetch the vehicle to verify all fields are saved
    console.log('\n2️⃣ Fetching vehicle to verify all fields are saved...');
    const fetchResponse = await fetch(`${API_BASE_URL}/vehicles/${createdVehicle.id}`, {
      headers: {
        'Authorization': 'Bearer YOUR_TEST_TOKEN' // Replace with actual token
      }
    });

    if (!fetchResponse.ok) {
      console.log('❌ Failed to fetch vehicle');
      return;
    }

    const fetchedVehicle = await fetchResponse.json();
    console.log('✅ Vehicle fetched successfully');

    // Step 3: Verify all new fields are present
    console.log('\n3️⃣ Verifying all new fields are present...');
    const newFields = [
      'stock_number', 'series', 'body_style', 'certified', 'interior_color',
      'engine_type', 'displacement', 'transmission', 'msrp', 'dealer_discount',
      'consumer_rebate', 'dealer_accessories', 'total_customer_savings',
      'total_dealer_rebate', 'other_price', 'odometer'
    ];

    let allFieldsPresent = true;
    for (const field of newFields) {
      if (fetchedVehicle[field] !== undefined) {
        console.log(`✅ ${field}: ${fetchedVehicle[field]}`);
      } else {
        console.log(`❌ ${field}: Missing`);
        allFieldsPresent = false;
      }
    }

    // Step 4: Test updating the vehicle with new values
    console.log('\n4️⃣ Testing vehicle update with modified values...');
    const updateData = {
      ...testVehicleData,
      price: 24500.00,
      msrp: 27500.00,
      dealer_discount: 2500.00,
      certified: false,
      body_style: '4D Sedan Sport'
    };

    const updateResponse = await fetch(`${API_BASE_URL}/vehicles/${createdVehicle.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_TEST_TOKEN' // Replace with actual token
      },
      body: JSON.stringify(updateData)
    });

    if (!updateResponse.ok) {
      console.log('❌ Failed to update vehicle');
      return;
    }

    const updatedVehicle = await updateResponse.json();
    console.log('✅ Vehicle updated successfully');

    // Step 5: Verify the updated values
    console.log('\n5️⃣ Verifying updated values...');
    console.log(`✅ Updated price: $${updatedVehicle.price}`);
    console.log(`✅ Updated MSRP: $${updatedVehicle.msrp}`);
    console.log(`✅ Updated dealer discount: $${updatedVehicle.dealer_discount}`);
    console.log(`✅ Updated certified: ${updatedVehicle.certified}`);
    console.log(`✅ Updated body style: ${updatedVehicle.body_style}`);

    // Step 6: Clean up - delete the test vehicle
    console.log('\n6️⃣ Cleaning up test vehicle...');
    const deleteResponse = await fetch(`${API_BASE_URL}/vehicles/${createdVehicle.id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': 'Bearer YOUR_TEST_TOKEN' // Replace with actual token
      }
    });

    if (deleteResponse.ok) {
      console.log('✅ Test vehicle deleted successfully');
    } else {
      console.log('⚠️ Failed to delete test vehicle (may need manual cleanup)');
    }

    console.log('\n🎉 Test completed successfully!');
    console.log('All new vehicle fields are properly integrated in the edit functionality.');

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

// Run the test
testVehicleEditFields(); 