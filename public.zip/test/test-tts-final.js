import { pool } from './src/database/connection.js';

async function testTTSFinal() {
  try {
    console.log('🎉 Final TTS Test - Verifying Complete Fix...\n');
    
    // Test with actual dealer that has voice settings
    const dealerQuery = `
      SELECT DISTINCT dealer_id 
      FROM daive_api_settings 
      WHERE dealer_id IS NOT NULL AND setting_type = 'voice_enabled' AND setting_value = 'true'
      LIMIT 1
    `;
    
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length > 0) {
      const dealerId = dealerResult.rows[0].dealer_id;
      console.log(`🏢 Testing with dealer: ${dealerId}`);
      
      // Test 1: Voice enabled query (same as TTS code now uses)
      console.log('\n📋 Test 1: Voice Enabled Check');
      const voiceEnabledQuery = `
        WITH dealer_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id = $1 AND setting_type = 'voice_enabled'
        ),
        global_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
        )
        SELECT setting_value FROM dealer_setting
        UNION ALL
        SELECT setting_value FROM global_setting
        WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
        LIMIT 1
      `;
      
      const voiceResult = await pool.query(voiceEnabledQuery, [dealerId]);
      
      if (voiceResult.rows.length > 0 && voiceResult.rows[0].setting_value === 'true') {
        console.log('   ✅ Voice enabled: true');
        
        // Test 2: TTS Provider
        console.log('\n🎤 Test 2: TTS Provider Check');
        const ttsProviderQuery = `
          WITH dealer_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id = $1 AND setting_type = 'voice_tts_provider'
          ),
          global_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id IS NULL AND setting_type = 'voice_tts_provider'
          )
          SELECT setting_value FROM dealer_setting
          UNION ALL
          SELECT setting_value FROM global_setting
          WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
          LIMIT 1
        `;
        
        const ttsResult = await pool.query(ttsProviderQuery, [dealerId]);
        
        if (ttsResult.rows.length > 0) {
          const provider = ttsResult.rows[0].setting_value;
          console.log(`   ✅ TTS Provider: ${provider}`);
          
          // Test 3: API Key for the provider
          console.log('\n🔑 Test 3: API Key Check');
          let keyType = '';
          if (provider === 'elevenlabs') keyType = 'elevenlabs_key';
          else if (provider === 'openai') keyType = 'openai_key';
          else if (provider === 'deepgram') keyType = 'deepgram_key';
          
          if (keyType) {
            const keyQuery = `
              WITH dealer_setting AS (
                SELECT setting_value FROM daive_api_settings 
                WHERE dealer_id = $1 AND setting_type = $2
              ),
              global_setting AS (
                SELECT setting_value FROM daive_api_settings 
                WHERE dealer_id IS NULL AND setting_type = $2
              )
              SELECT setting_value FROM dealer_setting
              UNION ALL
              SELECT setting_value FROM global_setting
              WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
              LIMIT 1
            `;
            
            const keyResult = await pool.query(keyQuery, [dealerId, keyType]);
            
            if (keyResult.rows.length > 0 && keyResult.rows[0].setting_value) {
              const maskedKey = keyResult.rows[0].setting_value.substring(0, 8) + '...' + 
                              keyResult.rows[0].setting_value.substring(keyResult.rows[0].setting_value.length - 4);
              console.log(`   ✅ ${keyType}: ${maskedKey}`);
              
              // Test 4: Additional settings based on provider
              console.log('\n⚙️ Test 4: Provider-Specific Settings');
              
              if (provider === 'openai') {
                const voiceSettingQuery = `
                  WITH dealer_setting AS (
                    SELECT setting_value FROM daive_api_settings 
                    WHERE dealer_id = $1 AND setting_type = 'voice_openai_voice'
                  ),
                  global_setting AS (
                    SELECT setting_value FROM daive_api_settings 
                    WHERE dealer_id IS NULL AND setting_type = 'voice_openai_voice'
                  )
                  SELECT setting_value FROM dealer_setting
                  UNION ALL
                  SELECT setting_value FROM global_setting
                  WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
                  LIMIT 1
                `;
                
                const voiceSettingResult = await pool.query(voiceSettingQuery, [dealerId]);
                const voice = voiceSettingResult.rows.length > 0 ? voiceSettingResult.rows[0].setting_value : 'alloy';
                console.log(`   ✅ OpenAI Voice: ${voice}`);
              }
              
              console.log('\n🎉 TTS CONFIGURATION COMPLETE!');
              console.log('   ✅ Voice is enabled');
              console.log(`   ✅ TTS provider: ${provider}`);
              console.log(`   ✅ API key: Present`);
              console.log(`   ✅ All queries use dealer-specific with global fallback`);
              
              console.log('\n🧪 Testing Instructions:');
              console.log('   1. Go to AI bot page: http://localhost:8080');
              console.log('   2. Send a text message to the AI');
              console.log('   3. Look for audio button in AI response');
              console.log('   4. Click audio button to hear TTS');
              console.log('   5. Check browser console for any errors');
              
              console.log('\n💡 If still no audio:');
              console.log('   - Check browser allows audio autoplay');
              console.log('   - Check uploads/daive-audio/ for generated files');
              console.log('   - Check backend console for TTS generation logs');
              console.log('   - Verify network requests in browser dev tools');
              
            } else {
              console.log(`   ❌ Missing ${keyType} - TTS will not work`);
            }
          }
        } else {
          console.log('   ❌ No TTS provider configured');
        }
      } else {
        console.log('   ❌ Voice is not enabled');
      }
    } else {
      console.log('❌ No dealers with voice enabled found');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testTTSFinal();