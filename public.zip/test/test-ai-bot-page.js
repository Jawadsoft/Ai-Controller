import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { pool } from './src/database/connection.js';
import FormData from 'form-data';

const BASE_URL = 'http://localhost:3000';

async function testAIBotPage() {
  console.log('🤖 Testing AI Bot Page Functionality...\n');
  
  try {
    // Get a real vehicle ID from the database
    console.log('1. Getting real vehicle ID from database...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id = '0aa94346-ed1d-420e-8823-bcd97bf6456f'
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for dealer with API settings');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    console.log(`🏢 Dealer ID: ${vehicle.dealer_id}`);
    
    // Test 1: AI Bot Text Chat
    console.log('\n2. Testing AI Bot text chat...');
    
    const textResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: vehicle.id,
        sessionId: 'aibot-test-' + Date.now(),
        message: 'Hello, I want to learn about vehicles',
        customerInfo: {
          name: 'AI Bot User',
          email: 'aibot@example.com',
          dealerId: vehicle.dealer_id
        }
      }),
    });
    
    console.log('📤 AI Bot text request details:');
    console.log('  - vehicleId:', vehicle.id);
    console.log('  - sessionId: aibot-test-*');
    console.log('  - dealerId:', vehicle.dealer_id);
    console.log('  - message: Hello, I want to learn about vehicles');
    
    console.log('\n📥 AI Bot text response:');
    console.log('  - Status:', textResponse.status);
    console.log('  - OK:', textResponse.ok);
    
    if (textResponse.ok) {
      const textData = await textResponse.json();
      console.log('✅ AI Bot text chat is working');
      console.log('📝 Response:', textData.data?.response?.substring(0, 100) + '...');
      console.log('📊 Lead Score:', textData.data?.leadScore);
      console.log('🔄 Should Handoff:', textData.data?.shouldHandoff);
    } else {
      const errorText = await textResponse.text();
      console.log('❌ AI Bot text chat error:', errorText);
    }
    
    // Test 2: AI Bot Voice Chat
    console.log('\n3. Testing AI Bot voice chat...');
    
    // Create test audio file
    const audioFilePath = path.join(process.cwd(), 'test-ai-bot-voice.wav');
    
    // Create a simple WAV file
    const sampleRate = 16000;
    const duration = 3; // 3 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate speech-like audio
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      const time = i / sampleRate;
      const frequency = 440 + Math.sin(time * 2) * 100;
      const sample = Math.sin(2 * Math.PI * frequency * time) * 0.3;
      audioData.writeInt16LE(Math.floor(sample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(audioFilePath, wavFile);
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(audioFilePath), {
      filename: 'ai-bot-voice-test.wav',
      contentType: 'audio/wav'
    });
    formData.append('vehicleId', vehicle.id);
    formData.append('sessionId', 'aibot-voice-test-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'AI Bot User',
      email: 'aibot@example.com',
      dealerId: vehicle.dealer_id
    }));
    
    console.log('📤 AI Bot voice request details:');
    console.log('  - vehicleId:', vehicle.id);
    console.log('  - sessionId: aibot-voice-test-*');
    console.log('  - dealerId:', vehicle.dealer_id);
    console.log('  - audio file:', audioFilePath);
    console.log('  - file size:', formatFileSize(fs.statSync(audioFilePath).size));
    
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      body: formData,
      headers: {
        ...formData.getHeaders()
      }
    });
    
    console.log('\n📥 AI Bot voice response:');
    console.log('  - Status:', voiceResponse.status);
    console.log('  - OK:', voiceResponse.ok);
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ AI Bot voice chat is working');
      console.log('📝 Transcription:', voiceData.data?.transcription);
      console.log('🤖 AI Response:', voiceData.data?.response?.substring(0, 100) + '...');
      console.log('📊 Lead Score:', voiceData.data?.leadScore);
      console.log('🔊 Audio Response:', voiceData.data?.audioResponseUrl ? 'Generated' : 'None');
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ AI Bot voice chat error:', errorData);
    }
    
    // Clean up
    if (fs.existsSync(audioFilePath)) {
      fs.unlinkSync(audioFilePath);
      console.log('\n🧹 Cleaned up test audio file');
    }
    
    console.log('\n🎯 AI Bot Page Test Summary:');
    console.log('✅ AI Bot page functionality is working');
    console.log('✅ Text chat with proper dealerId');
    console.log('✅ Voice chat with proper dealerId');
    console.log('✅ Both endpoints responding correctly');
    console.log('✅ Ready for React component integration');
    
  } catch (error) {
    console.error('❌ Error testing AI Bot page:', error.message);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

testAIBotPage(); 