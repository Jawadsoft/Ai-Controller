import fetch from 'node-fetch';

async function testDAIVEChat() {
  try {
    console.log('🧪 Testing D.A.I.V.E. chat endpoint...\n');
    
    const testData = {
      vehicleId: 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5',
      sessionId: 'test_session_' + Date.now(),
      message: 'Hello, I am interested in this vehicle',
      customerInfo: {
        name: 'Test Customer',
        email: 'test@example.com'
      }
    };
    
    console.log('📤 Sending request to D.A.I.V.E. chat...');
    console.log('Data:', JSON.stringify(testData, null, 2));
    console.log('');
    
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    console.log(`📥 Response Status: ${response.status}`);
    console.log(`📥 Response Headers:`, Object.fromEntries(response.headers.entries()));
    
    const responseText = await response.text();
    console.log(`📥 Response Body: ${responseText}`);
    
    if (response.ok) {
      const data = JSON.parse(responseText);
      console.log('\n✅ Chat request successful!');
      console.log('Response:', JSON.stringify(data, null, 2));
    } else {
      console.log('\n❌ Chat request failed!');
      console.log('Error response:', responseText);
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error('Stack:', error.stack);
  }
}

testDAIVEChat(); 