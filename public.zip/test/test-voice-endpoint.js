import fs from 'fs';
import path from 'path';

console.log('🧪 Testing voice endpoint end-to-end...');

const testVoiceEndpoint = async () => {
  try {
    // Create a simple test audio file (1 second of silence)
    const testAudioPath = './test-audio.wav';
    
    // Create a minimal WAV file (44 bytes header + 1 second of silence)
    const wavHeader = Buffer.from([
      0x52, 0x49, 0x46, 0x46, // RIFF
      0x24, 0x00, 0x00, 0x00, // File size - 8
      0x57, 0x41, 0x56, 0x45, // WAVE
      0x66, 0x6D, 0x74, 0x20, // fmt 
      0x10, 0x00, 0x00, 0x00, // Chunk size
      0x01, 0x00, // Audio format (PCM)
      0x01, 0x00, // Channels
      0x44, 0xAC, 0x00, 0x00, // Sample rate (44100)
      0x88, 0x58, 0x01, 0x00, // Byte rate
      0x02, 0x00, // Block align
      0x10, 0x00, // Bits per sample
      0x64, 0x61, 0x74, 0x61, // data
      0x00, 0x00, 0x00, 0x00  // Data size (0 for silence)
    ]);
    
    fs.writeFileSync(testAudioPath, wavHeader);
    console.log('✅ Created test audio file');
    
    // Test the voice endpoint
    console.log('📤 Testing voice endpoint...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath), 'test-audio.wav');
    formData.append('vehicleId', '');
    formData.append('sessionId', `test_${Date.now()}`);
    formData.append('customerInfo', JSON.stringify({
      name: 'Test User',
      email: 'test@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }));
    
    const response = await fetch('http://localhost:3000/api/daive/voice', {
      method: 'POST',
      body: formData
    });
    
    console.log(`📥 Voice response status: ${response.status}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Voice endpoint working!');
      console.log(`📝 Transcription: "${data.data?.transcription || 'None'}"`);
      console.log(`🤖 AI Response: "${data.data?.response?.substring(0, 100) || 'None'}..."`);
      console.log(`🔊 Audio Response: ${data.data?.audioResponseUrl ? 'Generated' : 'None'}`);
      
      if (data.data?.audioResponseUrl) {
        console.log('🎉 TTS is working! Audio response generated successfully.');
      } else {
        console.log('⚠️ TTS failed - no audio response generated.');
      }
    } else {
      const errorText = await response.text();
      console.log('❌ Voice endpoint failed:', errorText);
    }
    
    // Clean up test file
    fs.unlinkSync(testAudioPath);
    console.log('🧹 Cleaned up test audio file');
    
  } catch (error) {
    console.error('❌ Error testing voice endpoint:', error);
  }
};

testVoiceEndpoint(); 