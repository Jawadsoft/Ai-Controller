import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';
const DEALER_ID = '0aa94346-ed1d-420e-8823-bcd97bf6456f';

async function testCrewAI() {
  console.log('🧪 Testing Crew AI functionality...\n');

  try {
    // Test 1: Check if backend is running
    console.log('1️⃣ Testing backend connectivity...');
    try {
      const healthResponse = await fetch(`${BASE_URL}/api/daive/crew-ai-settings?dealerId=${DEALER_ID}`);
      if (healthResponse.ok) {
        console.log('✅ Backend is running and responding');
      } else {
        console.log('❌ Backend responded with error:', healthResponse.status);
        return;
      }
    } catch (error) {
      console.log('❌ Backend is not accessible:', error.message);
      return;
    }

    // Test 2: Check Crew AI settings
    console.log('\n2️⃣ Testing Crew AI settings...');
    try {
      const settingsResponse = await fetch(`${BASE_URL}/api/daive/crew-ai-settings?dealerId=${DEALER_ID}`);
      const settingsData = await settingsResponse.json();
      
      if (settingsData.success) {
        console.log('✅ Crew AI settings loaded successfully');
        console.log('📋 Settings:', {
          enabled: settingsData.data.enabled,
          autoRouting: settingsData.data.autoRouting,
          enableSalesCrew: settingsData.data.enableSalesCrew,
          enableCustomerServiceCrew: settingsData.data.enableCustomerServiceCrew,
          enableInventoryCrew: settingsData.data.enableInventoryCrew
        });
      } else {
        console.log('❌ Failed to load Crew AI settings:', settingsData.error);
      }
    } catch (error) {
      console.log('❌ Error loading Crew AI settings:', error.message);
    }

    // Test 3: Test regular chat endpoint
    console.log('\n3️⃣ Testing regular chat endpoint...');
    try {
      const chatPayload = {
        vehicleId: null,
        sessionId: 'test-session-' + Date.now(),
        message: 'Hello, this is a test message. Can you help me find a family car?',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: DEALER_ID
        }
      };

      const chatResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(chatPayload)
      });

      if (chatResponse.ok) {
        const chatData = await chatResponse.json();
        console.log('✅ Chat endpoint responded successfully');
        console.log('📋 Response structure:', {
          success: chatData.success,
          hasData: !!chatData.data,
          dataKeys: chatData.data ? Object.keys(chatData.data) : 'No data',
          hasResponse: !!chatData.data?.response,
          responseLength: chatData.data?.response?.length || 0,
          responsePreview: chatData.data?.response?.substring(0, 100) + '...'
        });
        
        if (chatData.success && chatData.data?.response) {
          console.log('🎉 AI response generated successfully!');
          console.log('🤖 Response preview:', chatData.data.response.substring(0, 200) + '...');
        } else {
          console.log('⚠️ Chat endpoint worked but no AI response generated');
          console.log('🔍 Full response data:', JSON.stringify(chatData, null, 2));
        }
      } else {
        const errorText = await chatResponse.text();
        console.log('❌ Chat endpoint failed:', chatResponse.status, errorText);
      }
    } catch (error) {
      console.log('❌ Error testing chat endpoint:', error.message);
    }

    // Test 4: Test Crew AI endpoint (if enabled)
    console.log('\n4️⃣ Testing Crew AI endpoint...');
    try {
      const crewAIPayload = {
        vehicleId: null,
        sessionId: 'test-crew-ai-' + Date.now(),
        message: 'I need help with financing options for a new vehicle',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: DEALER_ID
        }
      };

      const crewAIResponse = await fetch(`${BASE_URL}/api/daive/crew-ai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(crewAIPayload)
      });

      if (crewAIResponse.ok) {
        const crewAIData = await crewAIResponse.json();
        console.log('✅ Crew AI endpoint responded successfully');
        console.log('📋 Crew AI response structure:', {
          success: crewAIData.success,
          hasData: !!crewAIData.data,
          dataKeys: crewAIData.data ? Object.keys(crewAIData.data) : 'No data',
          hasResponse: !!crewAIData.data?.response,
          responseLength: crewAIData.data?.response?.length || 0,
          crewUsed: crewAIData.data?.crewUsed,
          crewType: crewAIData.data?.crewType
        });
        
        if (crewAIData.success && crewAIData.data?.response) {
          console.log('🎉 Crew AI response generated successfully!');
          console.log('🤖 Response preview:', crewAIData.data.response.substring(0, 200) + '...');
        } else {
          console.log('⚠️ Crew AI endpoint worked but no AI response generated');
          console.log('🔍 Full response data:', JSON.stringify(crewAIData, null, 2));
        }
      } else {
        const errorText = await crewAIResponse.text();
        console.log('❌ Crew AI endpoint failed:', crewAIResponse.status, errorText);
      }
    } catch (error) {
      console.log('❌ Error testing Crew AI endpoint:', error.message);
    }

    // Test 5: Check backend logs for any errors
    console.log('\n5️⃣ Checking for common issues...');
    console.log('📝 Check your backend console for any error messages');
    console.log('🔑 Verify that your OpenAI API key is configured');
    console.log('🗄️ Check if your database is running and accessible');
    console.log('⚙️ Verify that Crew AI services are properly initialized');

  } catch (error) {
    console.error('❌ Test failed with error:', error);
  }
}

// Run the test
testCrewAI().then(() => {
  console.log('\n🏁 Crew AI testing completed!');
  console.log('📊 Check the results above to identify any issues.');
}).catch(error => {
  console.error('💥 Test execution failed:', error);
}); 