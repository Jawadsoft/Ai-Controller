import { pool } from './src/database/connection.js';

async function testCurrentAuth() {
  console.log('🔐 Testing Current Authentication Status...\n');
  
  try {
    // Check if Clay Cooley exists in the database
    console.log('1. Checking Clay Cooley in database...');
    
    const clayCooleyQuery = `
      SELECT u.id as user_id, u.email, ur.role, d.id as dealer_id, d.business_name, d.contact_name
      FROM users u
      LEFT JOIN user_roles ur ON u.id = ur.user_id
      LEFT JOIN dealers d ON u.id = d.user_id
      WHERE d.business_name ILIKE '%clay cooley%'
      OR d.business_name ILIKE '%clay%cooley%'
      LIMIT 1
    `;
    
    const clayCooleyResult = await pool.query(clayCooleyQuery);
    
    if (clayCooleyResult.rows.length === 0) {
      console.log('❌ Clay Cooley not found in database');
      
      // Check if there are any dealers at all
      const allDealersQuery = `
        SELECT d.business_name, u.email, d.id as dealer_id
        FROM dealers d
        LEFT JOIN users u ON d.user_id = u.id
        LIMIT 5
      `;
      
      const allDealersResult = await pool.query(allDealersQuery);
      console.log('\n📊 Available dealers:');
      allDealersResult.rows.forEach((dealer, index) => {
        console.log(`  ${index + 1}. ${dealer.business_name} (${dealer.email})`);
      });
      
      return;
    }
    
    const clayCooley = clayCooleyResult.rows[0];
    console.log('✅ Clay Cooley found:');
    console.log('  - User ID:', clayCooley.user_id);
    console.log('  - Email:', clayCooley.email);
    console.log('  - Role:', clayCooley.role);
    console.log('  - Dealer ID:', clayCooley.dealer_id);
    console.log('  - Business Name:', clayCooley.business_name);
    
    // Check if there are any vehicles for Clay Cooley
    console.log('\n2. Checking Clay Cooley vehicles...');
    
    const vehiclesQuery = `
      SELECT id, make, model, year, dealer_id
      FROM vehicles
      WHERE dealer_id = $1
      LIMIT 5
    `;
    
    const vehiclesResult = await pool.query(vehiclesQuery, [clayCooley.dealer_id]);
    
    console.log(`📊 Found ${vehiclesResult.rows.length} vehicles for Clay Cooley:`);
    vehiclesResult.rows.forEach((vehicle, index) => {
      console.log(`  ${index + 1}. ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    });
    
    // Check authentication token format
    console.log('\n3. Testing JWT token generation...');
    
    const jwt = await import('jsonwebtoken');
    
    // Generate a test token for Clay Cooley
    const testToken = jwt.default.sign(
      { userId: clayCooley.user_id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );
    
    console.log('✅ Test token generated for Clay Cooley');
    console.log('  - Token length:', testToken.length);
    console.log('  - Token preview:', testToken.substring(0, 20) + '...');
    
    // Test the token
    try {
      const decoded = jwt.default.verify(testToken, process.env.JWT_SECRET || 'your-secret-key');
      console.log('✅ Token verification successful');
      console.log('  - Decoded user ID:', decoded.userId);
      console.log('  - Matches Clay Cooley:', decoded.userId === clayCooley.user_id);
    } catch (error) {
      console.log('❌ Token verification failed:', error.message);
    }
    
    // Check if there are any other dealers that might be causing confusion
    console.log('\n4. Checking for other dealers...');
    
    const otherDealersQuery = `
      SELECT d.business_name, u.email, d.id as dealer_id
      FROM dealers d
      LEFT JOIN users u ON d.user_id = u.id
      WHERE d.id != $1
      LIMIT 5
    `;
    
    const otherDealersResult = await pool.query(otherDealersQuery, [clayCooley.dealer_id]);
    
    console.log(`📊 Found ${otherDealersResult.rows.length} other dealers:`);
    otherDealersResult.rows.forEach((dealer, index) => {
      console.log(`  ${index + 1}. ${dealer.business_name} (${dealer.email})`);
    });
    
    console.log('\n✅ Authentication status testing completed!');
    console.log('\n📋 Summary:');
    console.log('  - Clay Cooley exists in database');
    console.log('  - JWT token generation works');
    console.log('  - Check browser localStorage for auth_token');
    console.log('  - Verify the token is valid and not expired');
    
  } catch (error) {
    console.error('❌ Error testing authentication status:', error);
  } finally {
    await pool.end();
  }
}

testCurrentAuth(); 