import fetch from 'node-fetch';

async function testApiSettingsUpdate() {
  try {
    console.log('🧪 Testing API settings update...\n');
    
    const BASE_URL = 'http://localhost:3000';
    
    // Test 1: Check current settings
    console.log('1. Checking current API settings...');
    const getResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer public'
      }
    });
    
    if (getResponse.ok) {
      const currentData = await getResponse.json();
      console.log('✅ Current settings retrieved');
      console.log('📋 Current deepgram_key:', currentData.data?.deepgram_key?.value?.substring(0, 20) + '...');
    } else {
      console.log('❌ Failed to get current settings:', getResponse.status);
    }
    
    // Test 2: Try to update with public token (should fail)
    console.log('\n2. Testing update with public token (should fail)...');
    const testKey = 'test-deepgram-key-' + Date.now();
    
    const updateResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer public'
      },
      body: JSON.stringify({
        settingType: 'deepgram_key',
        settingValue: testKey
      })
    });
    
    console.log('📥 Update response status:', updateResponse.status);
    
    if (updateResponse.ok) {
      const updateData = await updateResponse.json();
      console.log('✅ Update successful (unexpected):', updateData);
    } else {
      const errorText = await updateResponse.text();
      console.log('❌ Update failed (expected):', updateResponse.status, errorText);
    }
    
    // Test 3: Check if settings changed
    console.log('\n3. Checking if settings changed...');
    const getResponse2 = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer public'
      }
    });
    
    if (getResponse2.ok) {
      const data2 = await getResponse2.json();
      console.log('📋 Deepgram key after update attempt:', data2.data?.deepgram_key?.value?.substring(0, 20) + '...');
      
      if (data2.data?.deepgram_key?.value === testKey) {
        console.log('❌ ERROR: Settings were updated despite authentication failure');
      } else {
        console.log('✅ Settings were NOT updated (correct behavior)');
      }
    }
    
    // Test 4: Check what happens with invalid token
    console.log('\n4. Testing with invalid token...');
    const invalidResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer invalid-token'
      },
      body: JSON.stringify({
        settingType: 'deepgram_key',
        settingValue: 'invalid-test-key'
      })
    });
    
    console.log('📥 Invalid token response status:', invalidResponse.status);
    
    if (invalidResponse.ok) {
      console.log('❌ ERROR: Invalid token was accepted');
    } else {
      console.log('✅ Invalid token was rejected (correct behavior)');
    }
    
    console.log('\n💡 Analysis:');
    console.log('   - If updates are failing, it might be due to authentication issues');
    console.log('   - The frontend needs a valid auth token to update settings');
    console.log('   - Check if the user is logged in and has a valid token');
    
  } catch (error) {
    console.error('❌ Error testing API settings update:', error);
  }
}

testApiSettingsUpdate(); 