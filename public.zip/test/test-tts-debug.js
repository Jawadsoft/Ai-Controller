import { pool } from './src/database/connection.js';

async function testTTSDebug() {
  try {
    console.log('🔍 Debugging TTS Issues on AI Bot Page...\n');
    
    // Test 1: Check current voice settings
    console.log('📋 Test 1: Current Voice Settings in Database');
    
    const voiceSettingsQuery = `
      SELECT setting_type, setting_value, dealer_id,
             CASE 
               WHEN dealer_id IS NULL THEN 'Global'
               ELSE 'Dealer-Specific'
             END as scope
      FROM daive_api_settings
      WHERE setting_type LIKE 'voice_%' OR setting_type IN ('openai_key', 'elevenlabs_key', 'deepgram_key')
      ORDER BY scope, setting_type
    `;
    
    const voiceResult = await pool.query(voiceSettingsQuery);
    
    let currentScope = '';
    voiceResult.rows.forEach(row => {
      if (row.scope !== currentScope) {
        currentScope = row.scope;
        console.log(`\n   ${currentScope} Settings:`);
      }
      const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
        row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
        row.setting_value;
      console.log(`     ${row.setting_type}: ${maskedValue}`);
    });
    
    // Test 2: Check if voice is enabled
    console.log('\n🔊 Test 2: Voice Enabled Status');
    
    const voiceEnabledQuery = `
      SELECT setting_value, dealer_id
      FROM daive_api_settings
      WHERE setting_type = 'voice_enabled'
      ORDER BY dealer_id NULLS FIRST
    `;
    
    const enabledResult = await pool.query(voiceEnabledQuery);
    
    if (enabledResult.rows.length > 0) {
      enabledResult.rows.forEach(row => {
        const scope = row.dealer_id ? `Dealer ${row.dealer_id}` : 'Global';
        console.log(`   ${scope}: ${row.setting_value}`);
      });
    } else {
      console.log('   ❌ No voice_enabled settings found');
    }
    
    // Test 3: Check TTS provider
    console.log('\n🎤 Test 3: TTS Provider Configuration');
    
    const ttsProviderQuery = `
      SELECT setting_value, dealer_id
      FROM daive_api_settings
      WHERE setting_type = 'voice_tts_provider'
      ORDER BY dealer_id NULLS FIRST
    `;
    
    const ttsResult = await pool.query(ttsProviderQuery);
    
    if (ttsResult.rows.length > 0) {
      ttsResult.rows.forEach(row => {
        const scope = row.dealer_id ? `Dealer ${row.dealer_id}` : 'Global';
        console.log(`   ${scope}: ${row.setting_value}`);
      });
    } else {
      console.log('   ❌ No TTS provider settings found');
    }
    
    // Test 4: Check API keys for TTS providers
    console.log('\n🔑 Test 4: API Keys Status');
    
    const apiKeysQuery = `
      SELECT setting_type, setting_value, dealer_id
      FROM daive_api_settings
      WHERE setting_type IN ('openai_key', 'elevenlabs_key', 'deepgram_key')
      ORDER BY dealer_id NULLS FIRST, setting_type
    `;
    
    const keysResult = await pool.query(apiKeysQuery);
    
    if (keysResult.rows.length > 0) {
      keysResult.rows.forEach(row => {
        const scope = row.dealer_id ? `Dealer ${row.dealer_id}` : 'Global';
        const hasKey = row.setting_value ? '✅ Present' : '❌ Missing';
        const keyPreview = row.setting_value ? 
          row.setting_value.substring(0, 8) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          'None';
        console.log(`   ${scope} ${row.setting_type}: ${hasKey} (${keyPreview})`);
      });
    } else {
      console.log('   ❌ No API keys found');
    }
    
    // Test 5: Check recent conversation logs
    console.log('\n📝 Test 5: Recent DAIVE Conversations (checking for audio generation)');
    
    const conversationsQuery = `
      SELECT id, vehicle_id, dealer_id, conversation_log, created_at
      FROM daive_conversations
      ORDER BY created_at DESC
      LIMIT 5
    `;
    
    const conversationsResult = await pool.query(conversationsQuery);
    
    if (conversationsResult.rows.length > 0) {
      conversationsResult.rows.forEach((row, index) => {
        console.log(`\n   Conversation ${index + 1}:`);
        console.log(`     ID: ${row.id}`);
        console.log(`     Vehicle: ${row.vehicle_id}`);
        console.log(`     Dealer: ${row.dealer_id}`);
        console.log(`     Created: ${row.created_at}`);
        
        try {
          const log = JSON.parse(row.conversation_log);
          const hasAudio = log.some(msg => msg.audioResponseUrl || msg.audioUrl);
          console.log(`     Has Audio: ${hasAudio ? '✅ Yes' : '❌ No'}`);
          
          if (hasAudio) {
            const audioMessages = log.filter(msg => msg.audioResponseUrl || msg.audioUrl);
            console.log(`     Audio Messages: ${audioMessages.length}`);
          }
        } catch (e) {
          console.log('     Conversation Log: Could not parse');
        }
      });
    } else {
      console.log('   ❌ No recent conversations found');
    }
    
    // Test 6: Check uploads directory for audio files
    console.log('\n📁 Test 6: Check for Generated Audio Files');
    
    const fs = await import('fs');
    const path = await import('path');
    
    try {
      const uploadsDir = './uploads';
      if (fs.existsSync(uploadsDir)) {
        const files = fs.readdirSync(uploadsDir);
        const audioFiles = files.filter(file => 
          file.endsWith('.mp3') || file.endsWith('.wav') || file.endsWith('.webm')
        );
        
        console.log(`   Total files in uploads: ${files.length}`);
        console.log(`   Audio files: ${audioFiles.length}`);
        
        if (audioFiles.length > 0) {
          console.log('   Recent audio files:');
          audioFiles.slice(0, 5).forEach(file => {
            const filePath = path.join(uploadsDir, file);
            const stats = fs.statSync(filePath);
            console.log(`     ${file} (${(stats.size / 1024).toFixed(1)}KB, ${stats.mtime.toISOString()})`);
          });
        }
      } else {
        console.log('   ❌ Uploads directory not found');
      }
    } catch (error) {
      console.log('   ❌ Error checking uploads directory:', error.message);
    }
    
    // Test 7: Diagnostic Summary
    console.log('\n🔍 Test 7: TTS Issue Diagnosis');
    
    const issues = [];
    const recommendations = [];
    
    // Check if voice is enabled
    const globalVoiceEnabled = enabledResult.rows.find(row => row.dealer_id === null);
    if (!globalVoiceEnabled || globalVoiceEnabled.setting_value !== 'true') {
      issues.push('Voice/TTS is not enabled globally');
      recommendations.push('Enable voice in DAIVE Settings');
    }
    
    // Check TTS provider
    const globalTTSProvider = ttsResult.rows.find(row => row.dealer_id === null);
    if (!globalTTSProvider) {
      issues.push('No TTS provider configured');
      recommendations.push('Set TTS provider in DAIVE Settings');
    }
    
    // Check API keys based on provider
    if (globalTTSProvider) {
      const provider = globalTTSProvider.setting_value;
      let requiredKey = '';
      
      if (provider === 'openai') requiredKey = 'openai_key';
      else if (provider === 'elevenlabs') requiredKey = 'elevenlabs_key';
      else if (provider === 'deepgram') requiredKey = 'deepgram_key';
      
      if (requiredKey) {
        const hasKey = keysResult.rows.find(row => 
          row.setting_type === requiredKey && row.setting_value && row.dealer_id === null
        );
        
        if (!hasKey) {
          issues.push(`Missing ${requiredKey} for ${provider} TTS`);
          recommendations.push(`Add ${requiredKey} in DAIVE Settings`);
        }
      }
    }
    
    // Check dealer-specific settings conflict
    const dealerVoiceSettings = voiceResult.rows.filter(row => row.dealer_id !== null);
    if (dealerVoiceSettings.length > 0) {
      issues.push('Dealer-specific voice settings might override global settings');
      recommendations.push('Check dealer-specific voice settings in DAIVE Settings');
    }
    
    console.log('\n   Issues Found:');
    if (issues.length > 0) {
      issues.forEach(issue => console.log(`     ❌ ${issue}`));
    } else {
      console.log('     ✅ No obvious configuration issues found');
    }
    
    console.log('\n   Recommendations:');
    if (recommendations.length > 0) {
      recommendations.forEach(rec => console.log(`     💡 ${rec}`));
    } else {
      console.log('     ✅ Configuration looks good');
    }
    
    // Additional troubleshooting steps
    console.log('\n🛠️ Additional Troubleshooting Steps:');
    console.log('   1. Check browser console for audio playback errors');
    console.log('   2. Verify browser allows audio autoplay');
    console.log('   3. Check if audio files are being generated in /uploads');
    console.log('   4. Test TTS providers individually in DAIVE Settings');
    console.log('   5. Check network requests in browser dev tools');
    console.log('   6. Verify backend logs for TTS generation errors');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

// Run the test
testTTSDebug();