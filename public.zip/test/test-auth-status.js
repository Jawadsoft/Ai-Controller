import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testAuthStatus() {
  console.log('🔐 Testing Authentication Status...\n');
  
  try {
    // Test 1: Check if we can access the dealer profile endpoint
    console.log('1. Testing dealer profile endpoint...');
    
    const profileResponse = await fetch(`${BASE_URL}/api/dealers/profile`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.AUTH_TOKEN || 'test-token'}`
      }
    });
    
    console.log('📥 Profile response:');
    console.log('  - Status:', profileResponse.status);
    console.log('  - OK:', profileResponse.ok);
    
    if (profileResponse.ok) {
      const profileData = await profileResponse.json();
      console.log('  - Dealer ID:', profileData.id);
      console.log('  - Business Name:', profileData.business_name);
    } else {
      const errorText = await profileResponse.text();
      console.log('  - Error:', errorText);
    }
    
    // Test 2: Check authentication middleware
    console.log('\n2. Testing authentication middleware...');
    
    const authResponse = await fetch(`${BASE_URL}/api/auth/me`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.AUTH_TOKEN || 'test-token'}`
      }
    });
    
    console.log('📥 Auth response:');
    console.log('  - Status:', authResponse.status);
    console.log('  - OK:', authResponse.ok);
    
    if (authResponse.ok) {
      const authData = await authResponse.json();
      console.log('  - User ID:', authData.id);
      console.log('  - Email:', authData.email);
    } else {
      const errorText = await authResponse.text();
      console.log('  - Error:', errorText);
    }
    
    // Test 3: Check if Clay Cooley exists in database
    console.log('\n3. Checking Clay Cooley in database...');
    
    // This would require database access, but we can test the API
    const dealersResponse = await fetch(`${BASE_URL}/api/dealers`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.AUTH_TOKEN || 'test-token'}`
      }
    });
    
    console.log('📥 Dealers response:');
    console.log('  - Status:', dealersResponse.status);
    console.log('  - OK:', dealersResponse.ok);
    
    if (dealersResponse.ok) {
      const dealersData = await dealersResponse.json();
      console.log('  - Total dealers:', dealersData.length);
      const clayCooley = dealersData.find(d => 
        d.business_name.toLowerCase().includes('clay cooley')
      );
      if (clayCooley) {
        console.log('  - Clay Cooley found:', clayCooley.business_name);
        console.log('  - Clay Cooley ID:', clayCooley.id);
      } else {
        console.log('  - Clay Cooley not found in dealers list');
      }
    } else {
      const errorText = await dealersResponse.text();
      console.log('  - Error:', errorText);
    }
    
    console.log('\n✅ Authentication status testing completed!');
    console.log('\n📋 Summary:');
    console.log('  - Check if the auth token is valid');
    console.log('  - Verify Clay Cooley exists in database');
    console.log('  - Ensure dealer profile endpoint is accessible');
    
  } catch (error) {
    console.error('❌ Error testing authentication status:', error);
  }
}

testAuthStatus(); 