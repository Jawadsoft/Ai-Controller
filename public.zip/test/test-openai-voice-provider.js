import fetch from 'node-fetch';

async function testOpenAIVoiceProvider() {
  try {
    console.log('🎤 Testing OpenAI TTS with Voice Provider settings...\n');
    
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      console.error('❌ OPENAI_API_KEY environment variable is required');
      process.exit(1);
    }
    
    // Test 1: Test basic OpenAI TTS functionality
    console.log('1. Testing OpenAI TTS API with tts-1-hd model...');
    
    const testText = "Hello! I'm D.A.I.V.E., your AI vehicle assistant. This is a test of OpenAI TTS with the tts-1-hd model.";
    
    const response = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'tts-1-hd',
        input: testText,
        voice: 'alloy',
        response_format: 'mp3',
        speed: 1.0
      })
    });
    
    if (response.ok) {
      console.log('✅ OpenAI TTS API connection successful');
      const audioBuffer = await response.arrayBuffer();
      console.log(`📁 Audio file size: ${(audioBuffer.byteLength / 1024).toFixed(2)} KB`);
    } else {
      const errorText = await response.text();
      console.error('❌ OpenAI TTS API failed:', response.status, errorText);
      return;
    }
    
    // Test 2: Test different voices
    console.log('\n2. Testing different OpenAI voices...');
    
    const voices = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'];
    
    for (const voice of voices) {
      console.log(`   Testing voice: ${voice}`);
      
      const voiceResponse = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'tts-1-hd',
          input: `This is a test of the ${voice} voice using OpenAI TTS.`,
          voice: voice,
          response_format: 'mp3',
          speed: 1.0
        })
      });
      
      if (voiceResponse.ok) {
        console.log(`   ✅ ${voice} voice working`);
      } else {
        console.log(`   ❌ ${voice} voice failed`);
      }
    }
    
    // Test 3: Test speed variations
    console.log('\n3. Testing different speeds...');
    
    const speeds = [0.5, 1.0, 1.5, 2.0];
    
    for (const speed of speeds) {
      console.log(`   Testing speed: ${speed}x`);
      
      const speedResponse = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'tts-1-hd',
          input: `This is a test at ${speed}x speed.`,
          voice: 'alloy',
          response_format: 'mp3',
          speed: speed
        })
      });
      
      if (speedResponse.ok) {
        console.log(`   ✅ ${speed}x speed working`);
      } else {
        console.log(`   ❌ ${speed}x speed failed`);
      }
    }
    
    console.log('\n✅ OpenAI TTS Voice Provider testing completed successfully!');
    console.log('🎤 OpenAI TTS is now available in both Voice Provider and TTS Provider dropdowns.');
    console.log('📝 Configure it in DAIVE Settings → Voice Settings');
    
  } catch (error) {
    console.error('❌ OpenAI TTS Voice Provider test error:', error);
  }
}

testOpenAIVoiceProvider(); 