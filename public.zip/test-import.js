// Test import of unifiedAI.js
import unifiedAIService from './src/lib/unifiedAI.js';

console.log('🔍 Imported unifiedAIService:', typeof unifiedAIService);
console.log('🔍 unifiedAIService methods:', Object.getOwnPropertyNames(unifiedAIService));

if (unifiedAIService && typeof unifiedAIService === 'object') {
  console.log('🔍 unifiedAIService.processConversation:', typeof unifiedAIService.processConversation);
}

// Test creating an instance
try {
  const service = new unifiedAIService();
  console.log('✅ Service instance created successfully');
  console.log('🔍 processConversation method:', typeof service.processConversation);
} catch (error) {
  console.error('❌ Error creating service instance:', error.message);
} 