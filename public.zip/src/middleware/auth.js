import jwt from 'jsonwebtoken';
import { query } from '../database/connection.js';

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Verify user still exists
    const userResult = await query(
      'SELECT u.*, ur.role, d.id as dealer_id FROM users u LEFT JOIN user_roles ur ON u.id = ur.user_id LEFT JOIN dealers d ON u.id = d.user_id WHERE u.id = $1',
      [decoded.userId]
    );

    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = userResult.rows[0];
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid token' });
  }
};

const requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
};

const requireSuperAdmin = requireRole(['super_admin']);

export {
  authenticateToken,
  requireRole,
  requireSuperAdmin
};