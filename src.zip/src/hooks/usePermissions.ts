import { useState, useEffect, useCallback } from "react";
import { useAuth } from "./useAuth";

export type FeaturePermission = 
  | 'qr_code_generation'
  | 'lead_management' 
  | 'vehicle_import'
  | 'analytics_dashboard'
  | 'bulk_actions'
  | 'custom_branding'
  | 'api_access'
  | 'priority_support'
  | 'staff_management'
  | 'user_management';

export type UserRole = 'super_admin' | 'dealer' | 'client';

export type SubscriptionPlan = 'basic' | 'premium' | 'enterprise';

export const usePermissions = () => {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<FeaturePermission[]>([]);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [staffRole, setStaffRole] = useState<string | null>(null);
  const [subscriptionPlan, setSubscriptionPlan] = useState<SubscriptionPlan | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setPermissions([]);
      setUserRole(null);
      setStaffRole(null);
      setSubscriptionPlan(null);
      setLoading(false);
      return;
    }

    fetchUserPermissions();
  }, [user]);

  const fetchUserPermissions = async () => {
    if (!user) return;

    try {
      const role = user.role as UserRole;
      const staffRole = user.staffRole;
      
      setUserRole(role || 'dealer');
      setStaffRole(staffRole || null);

      // Super admin gets all permissions
      if (role === 'super_admin') {
        setPermissions([
          'qr_code_generation',
          'lead_management',
          'vehicle_import',
          'analytics_dashboard',
          'bulk_actions',
          'custom_branding',
          'api_access',
          'priority_support',
          'staff_management',
          'user_management'
        ]);
        setLoading(false);
        return;
      }

      // Staff-specific permissions
      if (staffRole) {
        const staffPermissions = getStaffPermissions(staffRole, (user.staffPermissions || []) as FeaturePermission[]);
        setPermissions(staffPermissions);
      } else {
        // Default dealer permissions
        setPermissions([
          'qr_code_generation',
          'lead_management',
          'vehicle_import'
        ]);
      }

      setSubscriptionPlan('basic');
    } catch (error) {
      console.error('Error fetching permissions:', error);
      setPermissions([]);
    } finally {
      setLoading(false);
    }
  };

  const getStaffPermissions = (staffRole: string, customPermissions: FeaturePermission[]): FeaturePermission[] => {
    const rolePermissions: Record<string, FeaturePermission[]> = {
      'admin': [
        'qr_code_generation',
        'lead_management',
        'vehicle_import',
        'analytics_dashboard',
        'bulk_actions',
        'staff_management',
        'user_management',
        'custom_branding',
        'api_access',
        'priority_support'
      ],
      'sales': [
        'qr_code_generation',
        'lead_management',
        'vehicle_import',
        'staff_management'
      ],
      'finance': [
        'lead_management',
        'analytics_dashboard'
      ],
      'service': [
        'lead_management'
      ],
      'inventory': [
        'vehicle_import',
        'qr_code_generation'
      ]
    };

    const basePermissions = rolePermissions[staffRole] || [];
    return [...basePermissions, ...customPermissions];
  };

  const hasPermission = useCallback((permission: FeaturePermission): boolean => {
    return permissions.includes(permission);
  }, [permissions]);

  const isSuperAdmin = useCallback((): boolean => {
    return userRole === 'super_admin';
  }, [userRole]);

  const isDealerAdmin = useCallback((): boolean => {
    return staffRole === 'admin';
  }, [staffRole]);

  const canAccessFeature = useCallback((feature: FeaturePermission): boolean => {
    // Super admin has all permissions
    if (isSuperAdmin()) {
      return true;
    }
    
    // Admin staff role has all permissions (consistent with backend)
    if (isDealerAdmin()) {
      return true;
    }
    
    // Check specific permissions for other roles
    return hasPermission(feature);
  }, [isSuperAdmin, isDealerAdmin, hasPermission]);

  return {
    permissions,
    userRole,
    staffRole,
    subscriptionPlan,
    loading,
    hasPermission,
    isSuperAdmin,
    isDealerAdmin,
    canAccessFeature,
    refreshPermissions: fetchUserPermissions
  };
};