import { pool } from './connection.js';
import fs from 'fs';

async function runMigration() {
  try {
    console.log('🔧 Running conversation_messages foreign key fix migration...');
    
    // Read the migration file
    const migrationSQL = fs.readFileSync('./fix-conversation-messages-fk.sql', 'utf8');
    
    // Execute the migration
    await pool.query(migrationSQL);
    
    console.log('✅ Migration completed successfully!');
    console.log('📊 conversation_messages table now properly references daive_conversations');
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await pool.end();
  }
}

runMigration();
