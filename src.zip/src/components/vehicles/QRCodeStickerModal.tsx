import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, Download, Printer, Settings, Car, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { vehiclesAPI } from "@/lib/api";
import { buildBackendAssetUrl } from "@/lib/config";
import { useAuth } from "@/hooks/useAuth";

// Import the actual DEALERIQ logo
import dealerIqLogo from "../../assets/dealeriq-logo.png";

interface Vehicle {
  id: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  stock_number?: string;
  trim?: string;
  color?: string;
  mileage?: number;
  price?: number;
  status: string;
  qr_code_url?: string;
  dealer_name?: string;
  sticker_generation_status?: string;
  sticker_generated_at?: string;
  sticker_printed_at?: string;
}

interface QRCodeStickerModalProps {
  vehicles: Vehicle[];
  onGenerateQR?: (vehicleId: string) => void;
  onRefresh?: () => void;
}

interface StickerTemplate {
  id: string;
  name: string;
  width: number;
  height: number;
  qrSize: number;
  showVehicleInfo: boolean;
  showDealerInfo: boolean;
  showPrice: boolean;
  backgroundColor: string;
  textColor: string;
}

const STICKER_TEMPLATES: StickerTemplate[] = [
  {
    id: "letter-size-6pack",
    name: "Letter Size - 6 Pack (Auto Width x 3-1/2\" each)",
    width: 350, // Auto width - will adjust to page
    height: 336, // 3.5" at 96 DPI
    qrSize: 100,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "dealeriq-classic",
    name: "DEALERIQ Classic",
    width: 300,
    height: 400,
    qrSize: 120,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "dealeriq-minimal",
    name: "DEALERIQ Minimal",
    width: 280,
    height: 380,
    qrSize: 100,
    showVehicleInfo: true,
    showDealerInfo: false,
    showPrice: false,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "dealeriq-premium",
    name: "DEALERIQ Premium",
    width: 350,
    height: 450,
    qrSize: 140,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "small",
    name: "Small Sticker (2\" x 1.5\")",
    width: 200,
    height: 150,
    qrSize: 80,
    showVehicleInfo: true,
    showDealerInfo: false,
    showPrice: false,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "medium",
    name: "Medium Sticker (3\" x 2\")",
    width: 300,
    height: 200,
    qrSize: 120,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: false,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "large",
    name: "Large Sticker (4\" x 3\")",
    width: 400,
    height: 300,
    qrSize: 160,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "window",
    name: "Window Sticker (3\" x 4\")",
    width: 300,
    height: 400,
    qrSize: 140,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  },
  {
    id: "custom",
    name: "Custom Size",
    width: 300,
    height: 200,
    qrSize: 120,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  }
];

export const QRCodeStickerModal = ({ vehicles, onGenerateQR, onRefresh }: QRCodeStickerModalProps) => {
  const { user } = useAuth();
  const [selectedVehicles, setSelectedVehicles] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<StickerTemplate>(STICKER_TEMPLATES[0]); // Letter Size - 6 Pack template
  const [customSettings, setCustomSettings] = useState({
    width: 300,
    height: 200,
    qrSize: 120,
    showVehicleInfo: true,
    showDealerInfo: true,
    showPrice: true,
    backgroundColor: "#ffffff",
    textColor: "#000000"
  });
  const [loading, setLoading] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [logoLoaded, setLogoLoaded] = useState(false);
  const [showPrintedVehicles, setShowPrintedVehicles] = useState(false);
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([]);
  const [fetchingVehicles, setFetchingVehicles] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Check if user can print labels (all roles except sales)
  const canPrintLabels = user?.staffRole !== 'sales';

  // Fetch vehicles from backend with sticker status filter
  const fetchVehiclesWithFilter = async (stickerStatus: string = 'generated', search: string = '') => {
    setFetchingVehicles(true);
    try {
      console.log('Fetching vehicles with filter:', { stickerStatus, search });
      
      const response = await vehiclesAPI.getAll({
        sticker_status: stickerStatus,
        search: search,
        limit: -1, // Get all vehicles
        inventory_status: 'available' // Only available vehicles
      });
      
      console.log('API response:', response);
      console.log('Response data length:', response.data?.length || 0);
      
      // Filter vehicles that have both price and stock number set
      const eligibleVehicles = response.data.filter((vehicle: Vehicle) => 
        vehicle.price && 
        vehicle.price > 0 && 
        vehicle.stock_number && 
        vehicle.stock_number.trim() !== ''
      );
      
      console.log('Eligible vehicles after filtering:', eligibleVehicles.length);
      console.log('Sample eligible vehicles:', eligibleVehicles.slice(0, 3));
      
      setFilteredVehicles(eligibleVehicles);
    } catch (error) {
      console.error('Error fetching vehicles:', error);
      toast({
        title: "Error",
        description: "Failed to fetch vehicles",
        variant: "destructive",
      });
    } finally {
      setFetchingVehicles(false);
    }
  };

  // Initial load - fetch generated vehicles
  useEffect(() => {
    fetchVehiclesWithFilter('generated');
  }, []);

  // Filter by sticker status - show generated only by default, or include printed if toggled
  const getStickerStatusFilter = () => {
    if (showPrintedVehicles) {
      return 'generated,printed'; // Show both generated and printed vehicles
    } else {
      return 'generated'; // Show only generated vehicles (default)
    }
  };

  // Preload the logo image
  useEffect(() => {
    const img = new Image();
    img.onload = () => setLogoLoaded(true);
    img.src = dealerIqLogo;
  }, []);

  const formatPrice = (price?: number) => {
    if (!price) return "Price not set";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const handleSelectVehicle = (vehicleId: string, checked: boolean) => {
    if (checked) {
      setSelectedVehicles([...selectedVehicles, vehicleId]);
    } else {
      setSelectedVehicles(selectedVehicles.filter(id => id !== vehicleId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedVehicles(filteredVehicles.map(v => v.id));
    } else {
      setSelectedVehicles([]);
    }
  };

  const generateQRCodeForVehicle = async (vehicleId: string) => {
    try {
      await vehiclesAPI.generateQRCode(vehicleId);
      toast({
        title: "QR Code Generated",
        description: "QR code has been generated successfully",
      });
      // Refresh the vehicle list after generating QR code
      fetchVehiclesWithFilter(getStickerStatusFilter(), searchTerm);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    }
  };

  const togglePrintedVehicles = () => {
    const newShowPrintedVehicles = !showPrintedVehicles;
    setShowPrintedVehicles(newShowPrintedVehicles);
    setSelectedVehicles([]); // Clear selections when changing filter
    
    // Determine the filter based on the new state
    const newFilter = newShowPrintedVehicles ? 'generated,printed' : 'generated';
    
    // Fetch vehicles with new filter
    fetchVehiclesWithFilter(newFilter, searchTerm);
  };

  const refreshVehicles = () => {
    setSelectedVehicles([]); // Clear selections when refreshing
    fetchVehiclesWithFilter(getStickerStatusFilter(), searchTerm);
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    // Clear previous timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    
    // Set new timeout for debounced search
    const timeout = setTimeout(() => {
      fetchVehiclesWithFilter(getStickerStatusFilter(), value);
    }, 500);
    
    setSearchTimeout(timeout);
  };

  const generateStickers = async () => {
    if (selectedVehicles.length === 0) {
      toast({
        title: "No Vehicles Selected",
        description: "Please select at least one vehicle to generate stickers",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Generate QR codes for vehicles that don't have them
      const vehiclesWithoutQR = selectedVehicles.filter(id => {
        const vehicle = filteredVehicles.find(v => v.id === id);
        return vehicle && !vehicle.qr_code_url;
      });

      if (vehiclesWithoutQR.length > 0) {
        toast({
          title: "Generating QR Codes",
          description: `Generating QR codes for ${vehiclesWithoutQR.length} vehicle(s) that don't have them...`,
        });

        // Use bulk QR generation for better performance
        try {
          const bulkResult = await vehiclesAPI.generateBulkQRCodes(vehiclesWithoutQR);
          
          if (bulkResult.success) {
            toast({
              title: "QR Codes Generated",
              description: `Successfully generated QR codes for ${bulkResult.results.filter(r => r.success).length} vehicle(s)`,
            });
          } else {
            throw new Error("Bulk QR generation failed");
          }
        } catch (error) {
          console.error("Bulk QR generation failed, falling back to individual generation:", error);
          
          // Fallback to individual generation
          let successCount = 0;
          for (const vehicleId of vehiclesWithoutQR) {
            try {
              await generateQRCodeForVehicle(vehicleId);
              successCount++;
            } catch (error) {
              console.error(`Failed to generate QR code for vehicle ${vehicleId}:`, error);
            }
          }
          
          if (successCount > 0) {
            toast({
              title: "QR Codes Generated",
              description: `Generated QR codes for ${successCount} vehicle(s)`,
            });
          }
        }
      }

      // Refresh the vehicles list to get updated QR codes before creating stickers
      if (onRefresh) {
        await onRefresh();
      }

      // Create printable sticker layout
      const stickerHTML = createStickerHTML();
      
      // Open in new window for printing
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        // Check if using letter-size template
        const isLetterSize = selectedTemplate.id === 'letter-size-6pack';
        
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>QR Code Stickers</title>
              <style>
                body { 
                  margin: 0; 
                  padding: ${isLetterSize ? '0.05in' : '5px'}; 
                  padding-top: 0.7in; 
                  font-family: Arial, sans-serif; 
                  background-color: #f5f5f5;
                }
                .sticker-page { 
                  page-break-after: always; 
                  margin-bottom: 0;
                  padding: 0;
                  width: 8.5in;
                  height: 11in;
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  align-items: center;
                }
                .sticker-grid { 
                  display: grid; 
                  ${isLetterSize ? 
                    `grid-template-columns: repeat(2, 1fr);
                     grid-template-rows: repeat(3, 3.4in);
                     gap: 0.66in;
                     row-gap: 0.4in;
                     width: 99%;
                     height: 11in;
                     padding: 0;
                     box-sizing: border-box;` :
                    `grid-template-columns: repeat(auto-fit, minmax(${selectedTemplate.width + 40}px, 1fr));
                     gap: 40px;`
                  }
                  justify-items: center;
                  align-items: center;
                  justify-content: center;
                  align-content: center;
                }
                @media print {
                  body { 
                    margin: 0; 
                    background-color: white;
                    padding: 0;
                  }
                  .sticker-page { 
                    page-break-after: always; 
                    margin-bottom: 0;
                    padding: 0;
                    width: 8.5in;
                    height: 11in;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                  }
                  .sticker-grid { 
                    gap: 0.66in;
                    row-gap: 0.4in;
                    padding: 0;
                    ${isLetterSize ? 
                      `grid-template-columns: repeat(2, 1fr);
                       grid-template-rows: repeat(3, 3.4in);
                       width: 99%;
                       height: 11in;
                       justify-content: center;
                       align-content: center;` : ''
                    }
                  }
                }
              </style>
            </head>
            <body>
              ${stickerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
      }

      // Mark stickers as printed after generating them
      await markStickersAsPrinted(selectedVehicles);

      toast({
        title: "Stickers Generated",
        description: `Generated stickers for ${selectedVehicles.length} vehicle(s) and marked as printed`,
      });
    } catch (error) {
      console.error("Error generating stickers:", error);
      toast({
        title: "Error",
        description: "Failed to generate stickers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const markStickersAsPrinted = async (vehicleIds: string[]) => {
    try {
      console.log('Marking stickers as printed for vehicles:', vehicleIds);
      
      // Mark each vehicle as printed using vehiclesAPI
      const results = await Promise.allSettled(
        vehicleIds.map(async (vehicleId) => {
          try {
            const result = await vehiclesAPI.markStickerPrinted(vehicleId);
            console.log(`Successfully marked vehicle ${vehicleId} as printed:`, result);
            return { vehicleId, success: true, result };
          } catch (error) {
            console.error(`Error marking vehicle ${vehicleId} as printed:`, error);
            return { vehicleId, success: false, error: error.message };
          }
        })
      );

      // Count successes and failures
      const successful = results.filter(r => r.status === 'fulfilled' && r.value.success).length;
      const failed = results.filter(r => r.status === 'rejected' || (r.status === 'fulfilled' && !r.value.success)).length;

      console.log(`Mark stickers as printed results: ${successful} successful, ${failed} failed`);

      if (failed > 0) {
        toast({
          title: "Partial Success",
          description: `Marked ${successful} stickers as printed, ${failed} failed`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: `Marked ${successful} stickers as printed`,
        });
      }
      
      // Refresh the vehicle list to show updated status
      fetchVehiclesWithFilter(getStickerStatusFilter(), searchTerm);
      
    } catch (error) {
      console.error("Error marking stickers as printed:", error);
      toast({
        title: "Error",
        description: "Failed to mark stickers as printed",
        variant: "destructive",
      });
    }
  };

    const createStickerHTML = () => {
    const selectedVehicleData = filteredVehicles.filter(v => selectedVehicles.includes(v.id));
    const isLetterSize = selectedTemplate.id === 'letter-size-6pack';
    
    if (isLetterSize) {
      // Group vehicles into pages of 6 for letter-size layout
      const pages = [];
      for (let i = 0; i < selectedVehicleData.length; i += 6) {
        pages.push(selectedVehicleData.slice(i, i + 6));
      }
      
      return pages.map((pageVehicles, pageIndex) => {
        const template = selectedTemplate.id === 'custom' ? customSettings : selectedTemplate;
        
        const stickersHTML = pageVehicles.map((vehicle) => {
          return `
            <div style="
              width: 80%; 
              height: 3.4in; 
              background-color: ${template.backgroundColor}; 
               border: 2px solid #1e40af; 
              padding: 0.03in; 
              display: flex; 
              flex-direction: column; 
              align-items: center; 
              justify-content: space-between;
              font-family: Arial, sans-serif;
              color: #000000;
              border-radius: 8px;
              border-top-right-radius: 32px;   /* increased */
              border-bottom-left-radius: 32px; /* increased */
              position: relative;
              overflow: hidden;
              box-sizing: border-box;
              transform: rotate(90deg);
            ">
              <!-- DEALERIQ Logo at Top -->
              <div style="text-align: center; margin-bottom: 0.01in;margin-top: 0.2in;">
                <img 
                  src="${dealerIqLogo}" 
                  alt="DEALERIQ Logo" 
                  style="width: 1.1in; height: 0.9in; margin-bottom: 0.01in;"
                />
              </div>
              
              <!-- D.A.I.V.E Call to Action -->
              <div style="text-align: center; margin-bottom: 0.015in;">
                <div style="font-size: 16px; font-weight: bold; color: #1e40af;">
                  LET D.A.I.V.E. HELP YOU
                </div>
              </div>
              
              <!-- Stock Number -->
              <div style="text-align: center; margin-bottom: 0.015in;">
                <div style="font-size: 11px; color: #000000;">
                  STK# ${vehicle.stock_number || vehicle.id.slice(-4)}
                </div>
              </div>
              
              <!-- QR Code Section -->
              <div style="text-align: center; margin-bottom: 0.02in;">
                ${vehicle.qr_code_url ? `
                  <img 
                      crossOrigin="anonymous" 
                       src="${buildBackendAssetUrl(vehicle.qr_code_url)}?t=${Date.now()}" 
                       style="width: 1in; height: 1in; border: 1px solid #e5e7eb;" 
                       alt="QR Code" />
                ` : `
                  <div style="
                    width: 1.0in; 
                    height: 1.0in; 
                    background-color: #f3f4f6; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center; 
                    border: 1px solid #d1d5db;
                    border-radius: 4px;
                  ">
                    <span style="font-size: 9px; color: #6b7280; text-align: center;">No QR Code<br/>Available</span>
                  </div>
                `}
              </div>
              
              <!-- Scan Here Text -->
              <div style="text-align: center; margin-bottom: 0.015in;">
                <div style="font-size: 11px; font-weight: bold; color: #000000;">
                  SCAN HERE
                </div>
              </div>
              
              <!-- Vehicle Information Section -->
              ${template.showVehicleInfo ? `
                <div style="text-align: center; margin-bottom: 0.008in;">
                  <div style="font-weight: bold; font-size: 14px; margin-bottom: 0.008in; color: #000000;">
                    ${vehicle.year} ${vehicle.make} ${vehicle.model}
                  </div>
                </div>
              ` : ''}
              
              <!-- Dealer Information Section -->
              ${template.showDealerInfo && vehicle.dealer_name ? `
                <div style="text-align: center; margin-bottom: 0.008in;">
                  <div style="font-weight: bold; font-size: 9px; color: #000000;">${vehicle.dealer_name}</div>
                </div>
              ` : ''}
              
              <!-- Price Section -->
              ${template.showPrice && vehicle.price ? `
                <div style="text-align: center; margin-bottom: 0.008in;">
                  <div style="font-size: 13px; font-weight: bold; color: #dc2626; margin-bottom: 0.008in;">
                    ${formatPrice(vehicle.price)}
                  </div>
                </div>
              ` : ''}
              
              <!-- Footer -->
              <div style="text-align: center; margin-top: auto;">
                <div style="font-size: 9px; color: #000000;">
                  Dealer A.I. Virtual Expert
                </div>
              </div>
            </div>
          `;
        }).join('');
        
        return `
          <div class="sticker-page">
            <div class="sticker-grid">
              ${stickersHTML}
            </div>
          </div>
        `;
      }).join('');
    } else {
      // Original layout for other templates
      return selectedVehicleData.map((vehicle, index) => {
        const template = selectedTemplate.id === 'custom' ? customSettings : selectedTemplate;
        
        return `
          <div class="sticker-page">
            <div class="sticker-grid">
              <div style="
                width: ${template.width}px; 
                height: ${template.height}px; 
                background-color: ${template.backgroundColor}; 
                border: 3px solid #1e40af; 
                padding: 20px; 
                display: flex; 
                flex-direction: column; 
                align-items: center; 
                justify-content: space-between;
                font-family: Arial, sans-serif;
                color: #000000;
                border-radius: 15px;
                margin: 20px;
                position: relative;
                overflow: hidden;
                transform: rotate(90deg);
              ">
                <!-- DEALERIQ Logo at Top -->
                <div style="text-align: center; margin-bottom: 8px;">
                  <img 
                    src="${dealerIqLogo}" 
                    alt="DEALERIQ Logo" 
                    style="width: 144px; height: 115px; margin-bottom: 8px;"
                  />
                </div>
                
                <!-- D.A.I.V.E Call to Action -->
                <div style="text-align: center; margin-bottom: 8px;">
                  <div style="font-size: 18px; font-weight: bold; color: #1e40af;">
                    LET D.A.I.V.E. HELP YOU
                  </div>
                </div>
                
                <!-- Stock Number -->
                <div style="text-align: center; margin-bottom: 8px;">
                  <div style="font-size: 12px; color: #000000;">
                    STK# ${vehicle.stock_number || vehicle.id.slice(-4)}
                  </div>
                </div>
                
                <!-- QR Code Section -->
                <div style="text-align: center; margin-bottom: 16px;">
                  ${vehicle.qr_code_url ? `
                    <img 
                        crossOrigin="anonymous" 
                         src="${buildBackendAssetUrl(vehicle.qr_code_url)}?t=${Date.now()}" 
                         style="width: ${template.qrSize}px; height: ${template.qrSize}px; border: 1px solid #e5e7eb;" 
                         alt="QR Code" />
                  ` : `
                    <div style="
                      width: ${template.qrSize}px; 
                      height: ${template.qrSize}px; 
                      background-color: #f3f4f6; 
                      display: flex; 
                      align-items: center; 
                      justify-content: center; 
                      border: 1px solid #d1d5db;
                      border-radius: 4px;
                    ">
                      <span style="font-size: 10px; color: #6b7280; text-align: center;">No QR Code<br/>Available</span>
                    </div>
                  `}
                </div>
                
                <!-- Scan Here Text -->
                <div style="text-align: center; margin-bottom: 6px;">
                  <div style="font-size: 12px; font-weight: bold; color: #000000;">
                    SCAN HERE
                  </div>
                </div>
                
                <!-- Vehicle Information Section -->
                ${template.showVehicleInfo ? `
                  <div style="text-align: center; margin-bottom: 6px;">
                    <div style="font-weight: bold; font-size: 16px; margin-bottom: 2px; color: #000000;">
                      ${vehicle.year} ${vehicle.make} ${vehicle.model}
                    </div>
                    ${vehicle.trim ? `<div style="font-size: 10px; color: #6b7280; margin-bottom: 1px;">${vehicle.trim}</div>` : ''}
                    ${vehicle.mileage ? `<div style="font-size: 9px; color: #6b7280; margin-bottom: 1px;">Mileage: ${vehicle.mileage.toLocaleString()} miles</div>` : ''}
                  </div>
                ` : ''}
                
                <!-- Dealer Information Section -->
                ${template.showDealerInfo && vehicle.dealer_name ? `
                  <div style="text-align: center; margin-bottom: 4px;">
                    <div style="font-weight: bold; font-size: 10px; color: #000000;">${vehicle.dealer_name}</div>
                  </div>
                ` : ''}
                
                <!-- Price Section -->
                ${template.showPrice && vehicle.price ? `
                  <div style="text-align: center; margin-bottom: 4px;">
                    <div style="font-size: 14px; font-weight: bold; color: #dc2626; margin-bottom: 2px;">
                      ${formatPrice(vehicle.price)}
                    </div>
                  </div>
                ` : ''}
                
                <!-- Footer -->
                <div style="text-align: center; margin-top: auto;">
                  <div style="font-size: 10px; color: #000000;">
                    Dealer A.I. Virtual Expert
                  </div>
                </div>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }
  };

  const getVehiclesNeedingQR = () => {
    return selectedVehicles.filter(id => {
      const vehicle = filteredVehicles.find(v => v.id === id);
      return vehicle && !vehicle.qr_code_url;
    });
  };

  const downloadStickers = () => {
    const stickerHTML = createStickerHTML();
    const isLetterSize = selectedTemplate.id === 'letter-size-6pack';
    
    const blob = new Blob([`
      <!DOCTYPE html>
      <html>
        <head>
          <title>QR Code Stickers</title>
          <style>
            body { 
              margin: 0; 
              padding: ${isLetterSize ? '0.05in' : '5px'};
              padding-top: 0.75in; 
              font-family: Arial, sans-serif; 
              background-color: #f5f5f5;
            }
            .sticker-page { 
              page-break-after: always; 
              margin-bottom: 0;
              padding: 0;
              width: 8.5in;
              height: 11in;
              display: flex;
              flex-direction: column;
              justify-content: center;
              align-items: center;
            }
            .sticker-grid { 
              display: grid; 
              ${isLetterSize ? 
                `grid-template-columns: repeat(2, 1fr);
                 grid-template-rows: repeat(3, 3.4in);
                 gap: 0.44in;
                 row-gap: 0.4in;
                 width: 99%;
                 height: 11in;
                 padding: 0;
                 box-sizing: border-box;` :
                `grid-template-columns: repeat(auto-fit, minmax(${selectedTemplate.width + 40}px, 1fr));
                 gap: 40px;`
              }
              justify-items: center;
              align-items: center;
              justify-content: center;
              align-content: center;
            }
            @media print {
              body { 
                margin: 0; 
                background-color: white;
                padding: 0;
              }
              .sticker-page { 
                page-break-after: always; 
                margin-bottom: 0;
                padding: 0;
                width: 8.5in;
                height: 11in;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              }
              .sticker-grid { 
                gap: 0.66in;
                row-gap: 0.4in;
                padding: 0;
                ${isLetterSize ? 
                  `grid-template-columns: repeat(2, 1fr);
                   grid-template-rows: repeat(3, 3.4n);
                   width: 99%;
                   height: 11in;
                   justify-content: center;
                   align-content: center;` : ''
                }
              }
            }
          </style>
        </head>
        <body>
          ${stickerHTML}
        </body>
      </html>
    `], { type: 'text/html' });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qr-code-stickers.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Stickers Downloaded",
      description: "QR code stickers have been downloaded",
    });
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="flex items-center space-x-2"
          disabled={!canPrintLabels}
          title={!canPrintLabels ? "Label printing is restricted for sales staff" : "Generate QR code stickers for vehicles"}
        >
          <QrCode className="h-4 w-4" />
          <span>Generate QR Stickers</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <QrCode className="h-5 w-5" />
            <span>QR Code Sticker Generator</span>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Vehicle Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span>Select Vehicles ({filteredVehicles.length} available)</span>
                  <div className="flex items-center space-x-2 mt-1">
                    <Input
                      placeholder="Search vehicles..."
                      value={searchTerm}
                      onChange={(e) => handleSearch(e.target.value)}
                      className="h-6 px-2 text-xs w-40"
                    />
                    <Button
                      variant={showPrintedVehicles ? "default" : "outline"}
                      size="sm"
                      onClick={togglePrintedVehicles}
                      disabled={fetchingVehicles}
                      className="h-6 px-2 text-xs"
                    >
                      {showPrintedVehicles ? "Generated Only" : "Include Printed"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={refreshVehicles}
                      disabled={fetchingVehicles}
                      className="h-6 px-2 text-xs flex items-center space-x-1"
                    >
                      <RefreshCw className={`h-3 w-3 ${fetchingVehicles ? 'animate-spin' : ''}`} />
                      <span>Refresh</span>
                    </Button>
                    {fetchingVehicles && (
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <div className="animate-spin h-3 w-3 border-b border-current rounded-full" />
                        <span>Loading...</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    checked={selectedVehicles.length === filteredVehicles.length && filteredVehicles.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                  <span className="text-sm text-muted-foreground">Select All</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-96 overflow-y-auto">
              {filteredVehicles.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {fetchingVehicles ? (
                    <div className="flex items-center justify-center space-x-2">
                      <div className="animate-spin h-5 w-5 border-b-2 border-primary rounded-full" />
                      <span>Loading vehicles...</span>
                    </div>
                  ) : (
                    <>
                      <p>No vehicles found with QR codes ready for printing.</p>
                      <p className="text-sm mt-2">
                        {showPrintedVehicles 
                          ? "No vehicles have generated or printed QR codes." 
                          : "No vehicles have generated QR codes. Try including printed vehicles or generate QR codes first."
                        }
                      </p>
                    </>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredVehicles.map((vehicle) => (
                  <div key={vehicle.id} className="flex items-center space-x-3 p-2 border rounded">
                    <Checkbox
                      checked={selectedVehicles.includes(vehicle.id)}
                      onCheckedChange={(checked) => handleSelectVehicle(vehicle.id, checked as boolean)}
                    />
                    <div className="flex-1">
                      <div className="font-medium">
                        {vehicle.year} {vehicle.make} {vehicle.model}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        VIN: {vehicle.vin}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {vehicle.sticker_generation_status === 'printed' && (
                        <Badge variant="default" className="text-xs bg-green-600 hover:bg-green-700">
                          ✓ Printed
                        </Badge>
                      )}
                      {vehicle.sticker_generation_status === 'generated' && (
                        <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                          QR Ready
                        </Badge>
                      )}
                      {vehicle.sticker_generation_status === 'not_generated' && (
                        <Badge variant="destructive" className="text-xs">
                          Needs QR
                        </Badge>
                      )}
                      <Badge variant={vehicle.status === 'available' ? 'default' : 'secondary'}>
                        {vehicle.status}
                      </Badge>
                    </div>
                  </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Template Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Sticker Template</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Template Size</Label>
                <Select
                  value={selectedTemplate.id}
                  onValueChange={(value) => {
                    const template = STICKER_TEMPLATES.find(t => t.id === value);
                    if (template) {
                      setSelectedTemplate(template);
                      if (value === 'custom') {
                        setCustomSettings({
                          width: template.width,
                          height: template.height,
                          qrSize: template.qrSize,
                          showVehicleInfo: template.showVehicleInfo,
                          showDealerInfo: template.showDealerInfo,
                          showPrice: template.showPrice,
                          backgroundColor: template.backgroundColor,
                          textColor: template.textColor
                        });
                      }
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STICKER_TEMPLATES.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedTemplate.id === 'custom' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Width (px)</Label>
                      <Input
                        type="number"
                        value={customSettings.width}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, width: parseInt(e.target.value) || 300 }))}
                      />
                    </div>
                    <div>
                      <Label>Height (px)</Label>
                      <Input
                        type="number"
                        value={customSettings.height}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, height: parseInt(e.target.value) || 200 }))}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>QR Code Size (px)</Label>
                    <Input
                      type="number"
                      value={customSettings.qrSize}
                      onChange={(e) => setCustomSettings(prev => ({ ...prev, qrSize: parseInt(e.target.value) || 120 }))}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Background Color</Label>
                      <Input
                        type="color"
                        value={customSettings.backgroundColor}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, backgroundColor: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>Text Color</Label>
                      <Input
                        type="color"
                        value={customSettings.textColor}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, textColor: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        checked={customSettings.showVehicleInfo}
                        onCheckedChange={(checked) => setCustomSettings(prev => ({ ...prev, showVehicleInfo: checked as boolean }))}
                      />
                      <Label>Show Vehicle Information</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        checked={customSettings.showDealerInfo}
                        onCheckedChange={(checked) => setCustomSettings(prev => ({ ...prev, showDealerInfo: checked as boolean }))}
                      />
                      <Label>Show Dealer Information</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        checked={customSettings.showPrice}
                        onCheckedChange={(checked) => setCustomSettings(prev => ({ ...prev, showPrice: checked as boolean }))}
                      />
                      <Label>Show Price</Label>
                    </div>
                  </div>
                </div>
              )}

              {/* Preview */}
              <div className="border rounded p-4">
                <Label>Preview</Label>
                <div className="mt-2 flex justify-center">
                  <div
                    style={{
                      width: Math.min(selectedTemplate.width, 200),
                      height: Math.min(selectedTemplate.height, 150),
                      backgroundColor: selectedTemplate.backgroundColor,
                      border: '1px solid #ccc',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '8px'
                    }}
                  >
                    {/* Show DEALERIQ logo preview */}
                    <img 
                      src={dealerIqLogo} 
                      alt="DEALERIQ Logo Preview" 
                      style={{ 
                        width: Math.min(60, selectedTemplate.width * 0.22), 
                        height: Math.min(48, selectedTemplate.height * 0.14),
                        marginBottom: '5px'
                      }} 
                    />
                    
                    {/* Show actual QR code if a vehicle is selected and has QR code */}
                    {selectedVehicles.length > 0 ? (() => {
                      const selectedVehicle = filteredVehicles.find(v => v.id === selectedVehicles[0]);
                      return selectedVehicle?.qr_code_url ? (
                        <img 
                          crossOrigin="anonymous"
                          src={`${buildBackendAssetUrl(selectedVehicle.qr_code_url)}?t=${Date.now()}`} 
                          alt="QR Code Preview" 
                          style={{ 
                            width: Math.min(selectedTemplate.qrSize, 80), 
                            height: Math.min(selectedTemplate.qrSize, 80),
                            border: '1px solid #ccc'
                          }} 
                        />
                      ) : (
                        <div style={{ 
                          width: Math.min(selectedTemplate.qrSize, 80), 
                          height: Math.min(selectedTemplate.qrSize, 80), 
                          backgroundColor: '#f0f0f0', 
                          border: '1px solid #ccc',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '7px',
                          textAlign: 'center'
                        }}>
                          No QR Code
                        </div>
                      );
                    })() : (
                      <div style={{ 
                        width: Math.min(selectedTemplate.qrSize, 80), 
                        height: Math.min(selectedTemplate.qrSize, 80), 
                        backgroundColor: '#f0f0f0', 
                        border: '1px solid #ccc',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '7px',
                        textAlign: 'center'
                      }}>
                        Select Vehicle
                      </div>
                    )}
                    
                    {selectedTemplate.showVehicleInfo && selectedVehicles.length > 0 && (() => {
                      const selectedVehicle = filteredVehicles.find(v => v.id === selectedVehicles[0]);
                      return selectedVehicle ? (
                        <div style={{ textAlign: 'center', marginTop: '5px' }}>
                          <div style={{ fontWeight: 'bold' }}>{selectedVehicle.year} {selectedVehicle.make} {selectedVehicle.model}</div>
                          <div style={{ fontSize: '6px' }}>VIN: {selectedVehicle.vin}</div>
                        </div>
                      ) : null;
                    })()}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

                 {/* Warning for vehicles without QR codes */}
         {getVehiclesNeedingQR().length > 0 && (
           <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mb-4">
             <div className="flex items-center">
               <div className="flex-shrink-0">
                 <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                   <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                 </svg>
               </div>
               <div className="ml-3">
                 <p className="text-sm text-yellow-800">
                   <strong>Note:</strong> {getVehiclesNeedingQR().length} selected vehicle(s) don't have QR codes. 
                   QR codes will be automatically generated when you print stickers.
                 </p>
               </div>
             </div>
           </div>
         )}

         {/* Action Buttons */}
         <div className="flex justify-between items-center pt-4 border-t">
           <div className="text-sm text-muted-foreground">
             {selectedVehicles.length} vehicle(s) selected
             {(() => {
               const vehiclesNeedingQR = getVehiclesNeedingQR();
               return vehiclesNeedingQR.length > 0 ? (
                 <span className="ml-2 text-destructive">
                   • {vehiclesNeedingQR.length} need QR codes
                 </span>
               ) : null;
             })()}
           </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={downloadStickers}
              disabled={selectedVehicles.length === 0 || loading}
            >
              <Download className="h-4 w-4 mr-2" />
              Download HTML
            </Button>
                                     <Button
              variant="accent"
              onClick={generateStickers}
              disabled={selectedVehicles.length === 0 || loading}
            >
              <Printer className="h-4 w-4 mr-2" />
              {loading ? "Generating..." : (() => {
                const vehiclesNeedingQR = getVehiclesNeedingQR();
                return vehiclesNeedingQR.length > 0 ? "Generate QR & Print" : "Print Stickers";
              })()}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}; 
