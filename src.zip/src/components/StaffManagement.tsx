import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';
import { getToken } from '@/lib/api';
import { API_BASE_URL } from '@/lib/config';
import { Plus, Edit, Trash2, Users, Shield, DollarSign, Wrench, Package, LogOut, RefreshCw } from 'lucide-react';

interface StaffMember {
  id: string;
  email: string;
  name: string;
  staff_role: string;
  permissions: string[];
  is_active: boolean;
  created_at: string;
  created_by_email?: string;
}

interface Permission {
  permission_name: string;
  permission_value: boolean;
}

const StaffManagement = () => {
  const { user, signOut } = useAuth();
  const { canAccessFeature } = usePermissions();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [newStaff, setNewStaff] = useState({
    email: '',
    password: '',
    name: '',
    staff_role: 'sales',
    permissions: [] as string[]
  });

  useEffect(() => {
    fetchStaff();
  }, []);

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/auth');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  const fetchStaff = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/staff`, {
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch staff members');
      }
      
      const data = await response.json();
      setStaff(data.staff);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch staff members",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchStaffPermissions = async (staffId: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/staff/${staffId}/permissions`, {
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setPermissions(data.permissions);
      }
    } catch (error) {
      console.error('Failed to fetch permissions:', error);
    }
  };

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`${API_BASE_URL}/staff`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(newStaff)
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Staff member added successfully"
        });
        setShowAddForm(false);
        setNewStaff({ email: '', password: '', name: '', staff_role: 'sales', permissions: [] });
        fetchStaff();
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to add staff member",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add staff member",
        variant: "destructive"
      });
    }
  };

  const handleUpdateStaff = async (staffId: string, updates: Partial<StaffMember>) => {
    try {
      const response = await fetch(`${API_BASE_URL}/staff/${staffId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(updates)
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Staff member updated successfully"
        });
        fetchStaff();
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to update staff member",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update staff member",
        variant: "destructive"
      });
    }
  };

  const handleDeleteStaff = async (staffId: string) => {
    if (!confirm('Are you sure you want to delete this staff member?')) {
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/staff/${staffId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Staff member deleted successfully"
        });
        fetchStaff();
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to delete staff member",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete staff member",
        variant: "destructive"
      });
    }
  };

  const handleUpdatePermissions = async (staffId: string, newPermissions: Permission[]) => {
    try {
      const response = await fetch(`${API_BASE_URL}/staff/${staffId}/permissions`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify({ permissions: newPermissions })
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Permissions updated successfully"
        });
        fetchStaffPermissions(staffId);
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to update permissions",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update permissions",
        variant: "destructive"
      });
    }
  };

  const getRoleIcon = (role: string) => {
    const icons = {
      'admin': Shield,
      'sales': Users,
      'finance': DollarSign,
      'service': Wrench,
      'inventory': Package
    };
    return icons[role as keyof typeof icons] || Users;
  };

  const getRoleBadgeColor = (role: string) => {
    const colors: Record<string, string> = {
      'admin': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
      'sales': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      'finance': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      'service': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      'inventory': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
    };
    return colors[role] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  const getRoleDisplayName = (role: string) => {
    const names: Record<string, string> = {
      'admin': 'Admin',
      'sales': 'Sales Agent',
      'finance': 'Finance Manager',
      'service': 'Service Advisor',
      'inventory': 'Inventory Manager'
    };
    return names[role] || role;
  };

  if (!canAccessFeature('staff_management')) {
    return (
      <Card className="border-destructive/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-destructive" />
            Access Denied
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p>You don't have permission to access staff management.</p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary">
              <Users className="h-4 w-4 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-bold text-foreground">DealerIQ</h1>
            <span className="text-muted-foreground text-sm">/ Staff Management</span>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm" onClick={() => navigate("/dashboard")}>
              Dashboard
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("/vehicles")}>
              Vehicles
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("/leads")}>
              Leads
            </Button>
            <span className="text-xs text-muted-foreground">
              {user?.email}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              className="flex items-center space-x-1"
            >
              <LogOut className="h-3 w-3" />
              <span>Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1">Staff Management</h2>
            <p className="text-sm text-muted-foreground">
              Manage your dealership staff members and their permissions
            </p>
          </div>
          <div className="flex space-x-3">
            <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
              <DialogTrigger asChild>
                <Button className="flex items-center space-x-2">
                  <Plus className="h-4 w-4" />
                  <span>Add Staff Member</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Staff Member</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddStaff} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={newStaff.name}
                      onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newStaff.email}
                      onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={newStaff.password}
                      onChange={(e) => setNewStaff({ ...newStaff, password: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="role">Role</Label>
                    <Select
                      value={newStaff.staff_role}
                      onValueChange={(value) => setNewStaff({ ...newStaff, staff_role: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sales">Sales Agent</SelectItem>
                        <SelectItem value="finance">Finance Manager</SelectItem>
                        <SelectItem value="service">Service Advisor</SelectItem>
                        <SelectItem value="inventory">Inventory Manager</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit">Add Staff</Button>
                    <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Staff Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Staff Members ({staff.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {staff.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No staff members yet</h3>
                <p className="text-muted-foreground mb-4">Add your first staff member to get started</p>
                <Button onClick={() => setShowAddForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Staff Member
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {staff.map((member) => {
                    const RoleIcon = getRoleIcon(member.staff_role);
                    return (
                      <TableRow key={member.id}>
                        <TableCell className="font-medium">{member.name}</TableCell>
                        <TableCell>{member.email}</TableCell>
                        <TableCell>
                          <Badge className={getRoleBadgeColor(member.staff_role)}>
                            <RoleIcon className="h-3 w-3 mr-1" />
                            {getRoleDisplayName(member.staff_role)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={member.is_active}
                              onCheckedChange={(checked) => 
                                handleUpdateStaff(member.id, { is_active: checked })
                              }
                            />
                            <span className={member.is_active ? 'text-green-600' : 'text-red-600'}>
                              {member.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {new Date(member.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setEditingStaff(member);
                                    fetchStaffPermissions(member.id);
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle>Edit Staff Member</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label htmlFor="edit-name">Name</Label>
                                      <Input
                                        id="edit-name"
                                        value={editingStaff?.name || ''}
                                        onChange={(e) => 
                                          setEditingStaff({ ...editingStaff!, name: e.target.value })
                                        }
                                      />
                                    </div>
                                    <div>
                                      <Label htmlFor="edit-role">Role</Label>
                                      <Select
                                        value={editingStaff?.staff_role || ''}
                                        onValueChange={(value) => 
                                          setEditingStaff({ ...editingStaff!, staff_role: value })
                                        }
                                      >
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="sales">Sales Agent</SelectItem>
                                          <SelectItem value="finance">Finance Manager</SelectItem>
                                          <SelectItem value="service">Service Advisor</SelectItem>
                                          <SelectItem value="inventory">Inventory Manager</SelectItem>
                                          <SelectItem value="admin">Admin</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <Label>Permissions</Label>
                                    <div className="space-y-2 mt-2">
                                      {permissions.map((permission) => (
                                        <div key={permission.permission_name} className="flex items-center justify-between">
                                          <span className="text-sm">{permission.permission_name}</span>
                                          <Switch
                                            checked={permission.permission_value}
                                            onCheckedChange={(checked) => {
                                              const updatedPermissions = permissions.map(p =>
                                                p.permission_name === permission.permission_name
                                                  ? { ...p, permission_value: checked }
                                                  : p
                                              );
                                              setPermissions(updatedPermissions);
                                            }}
                                          />
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                  
                                  <div className="flex gap-2">
                                    <Button
                                      onClick={() => {
                                        if (editingStaff) {
                                          handleUpdateStaff(editingStaff.id, {
                                            name: editingStaff.name,
                                            staff_role: editingStaff.staff_role
                                          });
                                          handleUpdatePermissions(editingStaff.id, permissions);
                                          setEditingStaff(null);
                                        }
                                      }}
                                    >
                                      Save Changes
                                    </Button>
                                    <Button
                                      variant="outline"
                                      onClick={() => setEditingStaff(null)}
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteStaff(member.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default StaffManagement;
