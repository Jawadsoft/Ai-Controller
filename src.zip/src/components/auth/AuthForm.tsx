import { useState } from "react";
import { authAPI } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Car } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface AuthFormProps {
  mode: "login" | "signup";
  onModeChange: (mode: "login" | "signup") => void;
}

export const AuthForm = ({ mode, onModeChange }: AuthFormProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [contactName, setContactName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showVerificationMessage, setShowVerificationMessage] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const { toast } = useToast();
  const navigate = useNavigate();

  // Clear error message when inputs change
  const clearError = () => {
    if (errorMessage) setErrorMessage("");
  };

  // Reset form fields
  const resetForm = () => {
    setEmail("");
    setPassword("");
    setBusinessName("");
    setContactName("");
    setErrorMessage("");
    // Don't clear showVerificationMessage here - it should be preserved for signup success
  };

  // Reset form completely (including verification message)
  const resetFormCompletely = () => {
    setEmail("");
    setPassword("");
    setBusinessName("");
    setContactName("");
    setErrorMessage("");
    setShowVerificationMessage(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(""); // Clear any previous error messages

    try {
      if (mode === "signup") {
        const response = await authAPI.register({
          email,
          password,
          businessName,
          contactName,
        });

        if (response.requiresVerification) {
          toast({
            title: "Account created successfully!",
            description: "Please check your email to verify your account before logging in.",
          });
          
          // Show verification message instead of redirecting
          setShowVerificationMessage(true);
          setErrorMessage(""); // Clear any error messages
          resetForm(); // Clear form fields
        } else {
          toast({
            title: "Account created successfully!",
            description: "Your dealer profile has been created. You can update your business details in your profile.",
          });
          
          resetForm(); // Clear form fields
          navigate("/dashboard");
        }
      } else {
        await authAPI.login({ email, password });

        toast({
          title: "Welcome back!",
          description: "You have successfully signed in.",
        });
        
        resetForm(); // Clear form fields
        navigate("/dashboard");
      }
    } catch (error: any) {
      console.error("Auth error:", error);
      
      // Handle email verification requirement
      if (error.requiresVerification) {
        toast({
          title: "Email Verification Required",
          description: "Please check your email and verify your account before logging in.",
          variant: "destructive",
        });
        return;
      }
      
      // Handle specific error cases
      let errorTitle = "Authentication Error";
      let errorDescription = "An error occurred during authentication.";
      let showSwitchToLogin = false;
      
      if (error.message) {
        if (error.message.includes("User already exists") || error.message.includes("already exists")) {
          errorTitle = "Account Already Exists";
          errorDescription = "An account with this email address already exists. Please try logging in instead.";
          showSwitchToLogin = true;
          // Set error message for form display
          setErrorMessage("An account with this email address already exists. Please try logging in instead.");
        } else if (error.message.includes("Invalid credentials")) {
          errorTitle = "Invalid Credentials";
          errorDescription = "The email or password you entered is incorrect. Please try again.";
          setErrorMessage("The email or password you entered is incorrect. Please try again.");
        } else if (error.message.includes("Email not verified")) {
          errorTitle = "Email Not Verified";
          errorDescription = "Please check your email and verify your account before logging in.";
          setErrorMessage("Please check your email and verify your account before logging in.");
        } else {
          errorDescription = error.message;
          setErrorMessage(error.message);
        }
      }
      
      toast({
        title: errorTitle,
        description: errorDescription,
        variant: "destructive",
        action: showSwitchToLogin ? {
          label: "Switch to Login",
          onClick: () => onModeChange("login")
        } : undefined
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
          <Car className="h-6 w-6 text-primary-foreground" />
        </div>
        <CardTitle className="text-2xl font-bold">
          {mode === "login" ? "Welcome back" : "Create dealer account"}
        </CardTitle>
        <CardDescription>
          {mode === "login"
            ? "Sign in to your DealerIQ account"
            : "Start managing your inventory with AI"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Error Message Display */}
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-red-700">{errorMessage}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setErrorMessage("")}
                  className="text-red-400 hover:text-red-600"
                >
                  <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          )}
          
          {mode === "signup" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="businessName">Business Name</Label>
                <Input
                  id="businessName"
                  type="text"
                  placeholder="Your Dealership Name"
                  value={businessName}
                  onChange={(e) => {
                    setBusinessName(e.target.value);
                    clearError();
                  }}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactName">Your Name</Label>
                <Input
                  id="contactName"
                  type="text"
                  placeholder="John Doe"
                  value={contactName}
                  onChange={(e) => {
                    setContactName(e.target.value);
                    clearError();
                  }}
                  required
                />
              </div>
            </>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="dealer@example.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                clearError();
              }}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                clearError();
              }}
              required
              minLength={6}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {mode === "login" ? "Sign In" : "Create Account"}
          </Button>
        </form>

        {showVerificationMessage && (
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-blue-800 mb-2">
                Check Your Email
              </h3>
              <p className="text-sm text-blue-700 mb-4">
                We've sent a verification email to <strong>{email}</strong>. 
                Please click the link in the email to verify your account.
              </p>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowVerificationMessage(false)}
                  className="w-full"
                >
                  Back to Sign Up
                </Button>
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => onModeChange("login")}
                  className="w-full"
                >
                  Go to Login
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            {mode === "login" ? "Don't have an account?" : "Already have an account?"}{" "}
            <Button
              variant="link"
              className="p-0 h-auto font-normal"
              onClick={() => {
                onModeChange(mode === "login" ? "signup" : "login");
                resetFormCompletely(); // Clear all form fields and messages when switching modes
              }}
            >
              {mode === "login" ? "Sign up" : "Sign in"}
            </Button>
          </p>
        </div>
      </CardContent>
    </Card>
  );
};