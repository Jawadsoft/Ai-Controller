// Configuration file for the application

// Get API base URL from environment variables or use defaults
export const getApiBaseUrl = () => {
  // Check for explicit API URL first
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL;
  }
  
  // Fallback to environment-based logic
  if (import.meta.env.MODE === 'production') {
    // In production, try to use the current origin or fallback
    return window.location.origin + '/api';
  }
  
  // Development default
  return 'http://localhost:3000/api';
};

// Export the base URL
export const API_BASE_URL = getApiBaseUrl();

// Get base URL for assets and files (without /api)
export const getBaseUrl = () => {
  // Check for explicit base URL first
  if (import.meta.env.VITE_BASE_URL) {
    return import.meta.env.VITE_BASE_URL;
  }
  
  // Fallback to environment-based logic
  if (import.meta.env.MODE === 'production') {
    // In production, use the current origin
    return window.location.origin;
  }
  
  // Development default
  return 'http://localhost:3000';
};

// Export the base URL for assets
export const BASE_URL = getBaseUrl();

// Get WebSocket base URL (ws:// or wss://)
export const getWebSocketBaseUrl = () => {
  // Check for explicit WebSocket URL first
  if (import.meta.env.VITE_WEBSOCKET_URL) {
    return import.meta.env.VITE_WEBSOCKET_URL;
  }
  
  // Fallback to environment-based logic
  if (import.meta.env.MODE === 'production') {
    // In production, use secure WebSocket if HTTPS, regular if HTTP
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}`;
  }
  
  // Development default
  return 'ws://localhost:3000';
};

// Export the WebSocket base URL
export const WEBSOCKET_BASE_URL = getWebSocketBaseUrl();

// Environment configuration
export const config = {
  isDevelopment: import.meta.env.MODE === 'development',
  isProduction: import.meta.env.MODE === 'production',
  apiBaseUrl: API_BASE_URL,
  baseUrl: BASE_URL,
  websocketBaseUrl: WEBSOCKET_BASE_URL,
  frontendUrl: import.meta.env.VITE_FRONTEND_URL || 'http://localhost:8080',
  backendUrl: import.meta.env.VITE_BACKEND_URL || 'http://localhost:3000',
};

// Helper function to build full API URLs
export const buildApiUrl = (endpoint: string) => {
  // Remove leading slash if present to avoid double slashes
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  return `${API_BASE_URL}/${cleanEndpoint}`;
};

// Helper function to build full asset URLs
export const buildAssetUrl = (path: string) => {
  // Remove leading slash if present to avoid double slashes
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return `${BASE_URL}/${cleanPath}`;
};

// Helper function to build backend asset URLs (for files served from backend)
export const buildBackendAssetUrl = (path: string) => {
  // Remove leading slash if present to avoid double slashes
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  
  // In production, use the backend URL from environment or construct it
  if (import.meta.env.MODE === 'production') {
    const backendUrl = import.meta.env.VITE_BACKEND_URL || 'https://vehicle-management-backend-ypsa.onrender.com';
    return `${backendUrl}/${cleanPath}`;
  }
  
  // Development default (backend runs on port 3000)
  return `http://localhost:3000/${cleanPath}`;
};

// Helper function to build WebSocket URLs
export const buildWebSocketUrl = (endpoint: string) => {
  // Remove leading slash if present to avoid double slashes
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  return `${WEBSOCKET_BASE_URL}/${cleanEndpoint}`;
};

export default config;
