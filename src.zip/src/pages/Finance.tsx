/**
 * Finance & Lease Management Page
 * Manage finance programs, deals, and credit applications
 */

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';
import { financeAPI, lendersAPI } from '@/lib/api';
import { API_BASE_URL } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { DollarSign, CreditCard, FileText, TrendingUp, Plus, Eye, Search, Filter, Check, X, Clock, Calculator, Edit, Send, PenTool, Download, CheckCircle } from 'lucide-react';
import { vehiclesAPI } from '@/lib/api';

interface FinanceProgram {
  id: string;
  program_name: string;
  type: 'finance' | 'lease';
  term_months: number;
  tier_min_score: number;
  tier_max_score: number;
  interest_rate?: number;
  money_factor?: number;
  residual_value_pct?: number;
  program_source: string;
  is_active: boolean;
  dealer_id?: string;
}

interface FinanceDeal {
  id: string;
  deal_type: 'finance' | 'lease';
  monthly_payment: number;
  down_payment: number;
  term_months: number;
  vehicle_price: number;
  total_amount: number;
  status: string;
  make?: string;
  model?: string;
  year?: number;
  apr?: number;
  customer_name?: string;
  customer_email?: string;
  customer_phone?: string;
  latest_deal_sheet_id?: string;
  pdf_url?: string;
  signature_request_id?: string;
  signature_status?: string;
  created_at: string;
}

interface CreditApplication {
  id: string;
  customer_name: string;
  customer_email: string;
  customer_phone?: string;
  credit_score?: number;
  application_status: string;
  submitted_at: string;
  preferred_lender_id?: string;
  approved_lender_id?: string;
  preferred_lender_name?: string;
  approved_lender_name?: string;
  lender_approval_date?: string;
  notes?: string;
}

interface LenderSubmission {
  id: string;
  lender_id: string;
  lender_name: string;
  lender_type: string;
  submission_status: 'pending' | 'submitted' | 'approved' | 'rejected' | 'countered' | 'withdrawn';
  submitted_at: string;
  responded_at?: string;
  submitted_by_name?: string;
  approved_amount?: number;
  approved_apr?: number;
  approved_term_months?: number;
  rejection_reason?: string;
  lender_reference_number?: string;
  notes?: string;
  counter_offer?: any;
}

const Finance = () => {
  const { user, loading: authLoading } = useAuth();
  const { canAccessFeature } = usePermissions();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<'deals' | 'programs' | 'applications'>('deals');
  const [loading, setLoading] = useState(true);
  
  // Deals
  const [deals, setDeals] = useState<FinanceDeal[]>([]);
  const [dealFilters, setDealFilters] = useState({ status: '', deal_type: '' });
  
  // Programs
  const [programs, setPrograms] = useState<FinanceProgram[]>([]);
  const [programFilters, setProgramFilters] = useState({ type: '', is_active: '' });
  const [showProgramDialog, setShowProgramDialog] = useState(false);
  
  // Applications
  const [applications, setApplications] = useState<CreditApplication[]>([]);
  const [applicationFilters, setApplicationFilters] = useState({ status: '' });
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);
  const [selectedAppForView, setSelectedAppForView] = useState<CreditApplication | null>(null);
  const [showAppViewDialog, setShowAppViewDialog] = useState(false);
  const [appDetails, setAppDetails] = useState<any>(null);
  const [loadingAppDetails, setLoadingAppDetails] = useState(false);
  const [showAppEditDialog, setShowAppEditDialog] = useState(false);
  const [editingApplication, setEditingApplication] = useState<CreditApplication | null>(null);
  const [appEditForm, setAppEditForm] = useState({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    credit_score: '',
    preferred_lender_id: '',
    notes: ''
  });
  const [lenders, setLenders] = useState<any[]>([]);
  
  // Deal actions
  const [showSubmitLenderDialog, setShowSubmitLenderDialog] = useState(false);
  const [selectedDealForAction, setSelectedDealForAction] = useState<FinanceDeal | null>(null);
  const [selectedLendersForSubmit, setSelectedLendersForSubmit] = useState<string[]>([]);
  const [submittingToLenders, setSubmittingToLenders] = useState(false);
  const [generatingPDF, setGeneratingPDF] = useState(false);
  const [requestingSignature, setRequestingSignature] = useState(false);
  
  // Deal viewing and submissions
  const [showDealDetailsDialog, setShowDealDetailsDialog] = useState(false);
  const [selectedDealForView, setSelectedDealForView] = useState<FinanceDeal | null>(null);
  const [dealSubmissions, setDealSubmissions] = useState<LenderSubmission[]>([]);
  const [loadingSubmissions, setLoadingSubmissions] = useState(false);
  
  // Deal editing
  const [showEditDealDialog, setShowEditDealDialog] = useState(false);
  const [editingDeal, setEditingDeal] = useState<FinanceDeal | null>(null);
  const [updatingDeal, setUpdatingDeal] = useState(false);
  const [editDealForm, setEditDealForm] = useState({
    vehicle_id: '',
    price: '',
    down_payment: '',
    credit_score: '',
    term_months: '60',
    deal_type: 'finance' as 'finance' | 'lease',
    // Lease-specific fields
    msrp: '',
    cap_cost_reductions: '',
    capitalized_fees: '',
    tax_rate: '',
    annual_mileage: '',
    excess_mileage_rate: '0.25',
    // Government fees (TTL)
    sales_tax_rate: '',
    title_fee: '',
    license_fee: '',
    registration_fee: '',
    inspection_fee: '',
    processing_fee: '',
    // Trade-in
    trade_in_acv: '',
    trade_in_payoff: '',
    // Add-ons
    add_ons: '',
    protection_products: ''
  });
  
  // Submission update
  const [showUpdateSubmissionDialog, setShowUpdateSubmissionDialog] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<LenderSubmission | null>(null);
  const [updatingSubmission, setUpdatingSubmission] = useState(false);
  const [submissionUpdateForm, setSubmissionUpdateForm] = useState({
    submission_status: '',
    approved_amount: '',
    approved_apr: '',
    approved_term_months: '',
    rejection_reason: '',
    lender_reference_number: ''
  });
  
  // Load lenders when dialog opens
  useEffect(() => {
    if ((showAppEditDialog || showSubmitLenderDialog) && lenders.length === 0) {
      loadLenders();
    }
  }, [showAppEditDialog, showSubmitLenderDialog]);
  
  const loadLenders = async () => {
    try {
      const response = await lendersAPI.getAll({ is_active: true });
      setLenders(response.data || []);
    } catch (error) {
      console.error('Error loading lenders:', error);
    }
  };
  
  // Generate PDF Deal Sheet
  const handleGeneratePDF = async (deal: FinanceDeal) => {
    try {
      setGeneratingPDF(true);
      const response = await fetch(`${API_BASE_URL}/finance/deals/${deal.id}/generate-sheet`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "PDF Generated",
          description: "Deal sheet PDF has been created successfully",
        });
        
        // Optionally download PDF
        if (result.data?.pdf_url) {
          window.open(result.data.pdf_url, '_blank');
        }
        
        loadData();
      } else {
        throw new Error(result.message || 'Failed to generate PDF');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate PDF deal sheet",
        variant: "destructive",
      });
    } finally {
      setGeneratingPDF(false);
    }
  };
  
  // Request E-Signature
  const handleRequestSignature = async (deal: FinanceDeal) => {
    try {
      setRequestingSignature(true);
      const response = await fetch(`${API_BASE_URL}/signatures/request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          deal_id: deal.id,
          deal_sheet_id: deal.latest_deal_sheet_id,
          signer_name: deal.customer_name || 'Customer',
          // signer_email: deal.customer_email || '',
          signer_email: 'info@mitiesoft.com',
          signer_phone: deal.customer_phone,
          document_url: deal.pdf_url || '',
          document_name: `Finance Agreement - ${deal.id}.pdf`,
          message: 'Please review and sign your finance agreement',
          expires_in_days: 7
        })
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Signature Request Sent",
          description: `Email sent to ${deal.customer_email}`,
        });
        loadData();
      } else {
        throw new Error(result.message || 'Failed to send signature request');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send signature request",
        variant: "destructive",
      });
    } finally {
      setRequestingSignature(false);
    }
  };
  
  // Quick status update (for testing)
  const handleQuickStatusUpdate = async (dealId: string, newStatus: string) => {
    try {
      const result = await financeAPI.updateDealStatus(dealId, newStatus);
      
      if (result.success) {
        toast({
          title: "Status Updated",
          description: `Deal status changed to ${newStatus}`,
        });
        loadData();
      } else {
        throw new Error(result.error || result.message || 'Failed to update status');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update deal status",
        variant: "destructive",
      });
    }
  };
  
  // Load Deal Submissions
  const loadDealSubmissions = async (dealId: string) => {
    try {
      setLoadingSubmissions(true);
      const response = await lendersAPI.getDealSubmissions(dealId);
      setDealSubmissions(response.data || []);
    } catch (error: any) {
      console.error('Error loading submissions:', error);
      toast({
        title: "Error",
        description: "Failed to load lender submissions",
        variant: "destructive",
      });
    } finally {
      setLoadingSubmissions(false);
    }
  };
  
  // Update Submission Status
  const handleUpdateSubmission = async () => {
    if (!selectedSubmission) return;
    
    try {
      setUpdatingSubmission(true);
      
      const updateData: any = {
        submission_status: submissionUpdateForm.submission_status
      };
      
      if (submissionUpdateForm.approved_amount) {
        updateData.approved_amount = parseFloat(submissionUpdateForm.approved_amount);
      }
      if (submissionUpdateForm.approved_apr) {
        updateData.approved_apr = parseFloat(submissionUpdateForm.approved_apr);
      }
      if (submissionUpdateForm.approved_term_months) {
        updateData.approved_term_months = parseInt(submissionUpdateForm.approved_term_months);
      }
      if (submissionUpdateForm.rejection_reason) {
        updateData.rejection_reason = submissionUpdateForm.rejection_reason;
      }
      if (submissionUpdateForm.lender_reference_number) {
        updateData.lender_reference_number = submissionUpdateForm.lender_reference_number;
      }
      
      const result = await lendersAPI.updateSubmission(selectedSubmission.id, updateData);
      
      if (result.success) {
        toast({
          title: "Submission Updated",
          description: "Lender submission status has been updated",
        });
        
        // Reload submissions
        if (selectedDealForView) {
          await loadDealSubmissions(selectedDealForView.id);
        }
        
        setShowUpdateSubmissionDialog(false);
        setSelectedSubmission(null);
        setSubmissionUpdateForm({
          submission_status: '',
          approved_amount: '',
          approved_apr: '',
          approved_term_months: '',
          rejection_reason: '',
          lender_reference_number: ''
        });
      } else {
        throw new Error(result.error || 'Failed to update submission');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update submission",
        variant: "destructive",
      });
    } finally {
      setUpdatingSubmission(false);
    }
  };
  
  // Handle Edit Deal
  const handleEditDeal = async () => {
    if (!editingDeal) return;
    
    try {
      setUpdatingDeal(true);
      
      // Build update data based on deal type
      const updateData: any = {
        down_payment: parseFloat(editDealForm.down_payment) || 0,
        term_months: parseInt(editDealForm.term_months)
      };
      
      if (editDealForm.deal_type === 'finance') {
        // Finance deal updates
        updateData.vehicle_price = parseFloat(editDealForm.price);
        
        // Optional fields
        if (editDealForm.sales_tax_rate) updateData.sales_tax_rate = parseFloat(editDealForm.sales_tax_rate);
        if (editDealForm.title_fee) updateData.title_fee = parseFloat(editDealForm.title_fee);
        if (editDealForm.license_fee) updateData.license_fee = parseFloat(editDealForm.license_fee);
        if (editDealForm.registration_fee) updateData.registration_fee = parseFloat(editDealForm.registration_fee);
        if (editDealForm.inspection_fee) updateData.inspection_fee = parseFloat(editDealForm.inspection_fee);
        if (editDealForm.processing_fee) updateData.processing_fee = parseFloat(editDealForm.processing_fee);
        if (editDealForm.trade_in_acv) updateData.trade_in_acv = parseFloat(editDealForm.trade_in_acv);
        if (editDealForm.trade_in_payoff) updateData.trade_in_payoff = parseFloat(editDealForm.trade_in_payoff);
        if (editDealForm.add_ons) updateData.add_ons = parseFloat(editDealForm.add_ons);
        if (editDealForm.protection_products) updateData.protection_products = parseFloat(editDealForm.protection_products);
      } else {
        // Lease deal updates
        updateData.cap_cost = parseFloat(editDealForm.price);
        
        if (editDealForm.msrp) updateData.msrp = parseFloat(editDealForm.msrp);
        if (editDealForm.cap_cost_reductions) updateData.cap_cost_reductions = parseFloat(editDealForm.cap_cost_reductions);
        if (editDealForm.capitalized_fees) updateData.capitalized_fees = parseFloat(editDealForm.capitalized_fees);
        if (editDealForm.tax_rate) updateData.tax_rate = parseFloat(editDealForm.tax_rate);
        if (editDealForm.annual_mileage) updateData.annual_mileage = parseInt(editDealForm.annual_mileage);
        if (editDealForm.excess_mileage_rate) updateData.excess_mileage_rate = parseFloat(editDealForm.excess_mileage_rate);
      }
      
      const result = await financeAPI.updateDeal(editingDeal.id, updateData);
      
      if (result.success) {
        toast({
          title: "Deal Updated",
          description: "Deal has been updated successfully",
        });
        
        setShowEditDealDialog(false);
        setEditingDeal(null);
        loadData();
      } else {
        throw new Error(result.error || result.message || 'Failed to update deal');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update deal",
        variant: "destructive",
      });
    } finally {
      setUpdatingDeal(false);
    }
  };
  
  // Submit to Lenders
  const handleSubmitToLenders = async () => {
    if (!selectedDealForAction || selectedLendersForSubmit.length === 0) {
      toast({
        title: "No Lenders Selected",
        description: "Please select at least one lender",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setSubmittingToLenders(true);
      let successCount = 0;
      let errorCount = 0;
      
      for (const lenderId of selectedLendersForSubmit) {
        try {
          await lendersAPI.submitDeal(lenderId, {
            deal_id: selectedDealForAction.id,
            submission_method: 'api',
            notes: 'Submitted from finance dashboard'
          });
          successCount++;
        } catch (error) {
          console.error(`Failed to submit to lender ${lenderId}:`, error);
          errorCount++;
        }
      }
      
      toast({
        title: "Submission Complete",
        description: `Successfully submitted to ${successCount} lender(s)${errorCount > 0 ? `. ${errorCount} failed.` : ''}`,
        variant: errorCount > 0 ? "destructive" : "default",
      });
      
      setShowSubmitLenderDialog(false);
      setSelectedLendersForSubmit([]);
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit to lenders",
        variant: "destructive",
      });
    } finally {
      setSubmittingToLenders(false);
    }
  };
  
  // Deal creation
  const [showCreateDealDialog, setShowCreateDealDialog] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<CreditApplication | null>(null);
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [creatingDeal, setCreatingDeal] = useState(false);
  const [dealForm, setDealForm] = useState({
    vehicle_id: '',
    price: '',
    down_payment: '',
    credit_score: '',
    term_months: '60',
    deal_type: 'finance' as 'finance' | 'lease',
    // Lease-specific fields
    msrp: '',
    cap_cost_reductions: '',
    capitalized_fees: '',
    tax_rate: '',
    annual_mileage: '',
    excess_mileage_rate: '0.25',
    // Government fees (TTL)
    sales_tax_rate: '',
    title_fee: '',
    license_fee: '',
    registration_fee: '',
    inspection_fee: '',
    processing_fee: '',
    // Trade-in
    trade_in_acv: '',
    trade_in_payoff: '',
    // Other
    add_ons: '',
    protection_products: ''
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadData();
      if (activeTab === 'applications' || showCreateDealDialog) {
        loadVehicles();
      }
    }
  }, [user, activeTab, dealFilters, programFilters, applicationFilters, showCreateDealDialog]);
  
  const loadVehicles = async () => {
    try {
      const response = await vehiclesAPI.getAll({ limit: 100 });
      setVehicles(response.data || []);
    } catch (error: any) {
      console.error('Error loading vehicles:', error);
    }
  };

  const loadData = async () => {
    try {
      setLoading(true);

      if (activeTab === 'deals') {
        const response = await financeAPI.getDeals({
          ...(dealFilters.status && { status: dealFilters.status }),
          ...(dealFilters.deal_type && { deal_type: dealFilters.deal_type as 'finance' | 'lease' }),
        });
        setDeals(response.data || []);
      } else if (activeTab === 'programs') {
        const response = await financeAPI.getPrograms({
          ...(programFilters.type && { type: programFilters.type as 'finance' | 'lease' }),
          ...(programFilters.is_active !== '' && { is_active: programFilters.is_active === 'true' }),
        });
        setPrograms(response.data || []);
      } else if (activeTab === 'applications') {
        const response = await financeAPI.getCreditApplications({
          ...(applicationFilters.status && { status: applicationFilters.status }),
        });
        setApplications(response.data || []);
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load finance data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      'draft': 'outline',
      'pending': 'secondary',
      'approved': 'default',
      'signed': 'default',
      'completed': 'default',
      'rejected': 'destructive',
      'cancelled': 'outline',
      'reviewing': 'secondary',
    };
    return <Badge variant={variants[status] || 'outline'}>{status}</Badge>;
  };

  // Update application status
  const handleUpdateApplicationStatus = async (applicationId: string, newStatus: string) => {
    try {
      setUpdatingStatus(applicationId);
      await financeAPI.updateCreditApplicationStatus(applicationId, newStatus);
      toast({
        title: "Success",
        description: `Application status updated to ${newStatus}`,
      });
      loadData(); // Reload data
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update application status",
        variant: "destructive",
      });
    } finally {
      setUpdatingStatus(null);
    }
  };

  // Create finance deal
  const handleCreateDeal = async () => {
    if (!dealForm.vehicle_id || !dealForm.price || !dealForm.credit_score || !dealForm.term_months) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      setCreatingDeal(true);
      
      if (dealForm.deal_type === 'finance') {
        await financeAPI.createFinanceDeal({
          vehicle_id: dealForm.vehicle_id,
          price: parseFloat(dealForm.price),
          down_payment: parseFloat(dealForm.down_payment) || 0,
          credit_score: parseInt(dealForm.credit_score),
          term_months: parseInt(dealForm.term_months),
          application_id: selectedApplication?.id,
          // Government fees
          sales_tax_rate: dealForm.sales_tax_rate ? parseFloat(dealForm.sales_tax_rate) : undefined,
          title_fee: dealForm.title_fee ? parseFloat(dealForm.title_fee) : undefined,
          license_fee: dealForm.license_fee ? parseFloat(dealForm.license_fee) : undefined,
          registration_fee: dealForm.registration_fee ? parseFloat(dealForm.registration_fee) : undefined,
          inspection_fee: dealForm.inspection_fee ? parseFloat(dealForm.inspection_fee) : undefined,
          processing_fee: dealForm.processing_fee ? parseFloat(dealForm.processing_fee) : undefined,
          // Trade-in
          trade_in_acv: dealForm.trade_in_acv ? parseFloat(dealForm.trade_in_acv) : undefined,
          trade_in_payoff: dealForm.trade_in_payoff ? parseFloat(dealForm.trade_in_payoff) : undefined,
          // Other
          add_ons: dealForm.add_ons ? parseFloat(dealForm.add_ons) : undefined,
          protection_products: dealForm.protection_products ? parseFloat(dealForm.protection_products) : undefined
        });
      } else {
        await financeAPI.createLeaseDeal({
          vehicle_id: dealForm.vehicle_id,
          cap_cost: parseFloat(dealForm.price),
          credit_score: parseInt(dealForm.credit_score),
          term_months: parseInt(dealForm.term_months),
          application_id: selectedApplication?.id,
          msrp: dealForm.msrp ? parseFloat(dealForm.msrp) : undefined,
          cap_cost_reductions: dealForm.cap_cost_reductions ? parseFloat(dealForm.cap_cost_reductions) : 0,
          capitalized_fees: dealForm.capitalized_fees ? parseFloat(dealForm.capitalized_fees) : 0,
          tax_rate: dealForm.tax_rate ? parseFloat(dealForm.tax_rate) : 0,
          annual_mileage: dealForm.annual_mileage ? parseInt(dealForm.annual_mileage) : undefined,
          excess_mileage_rate: dealForm.excess_mileage_rate ? parseFloat(dealForm.excess_mileage_rate) : 0.25,
        });
      }

      toast({
        title: "Success",
        description: `${dealForm.deal_type === 'finance' ? 'Finance' : 'Lease'} deal created successfully!`,
      });

      setShowCreateDealDialog(false);
      setSelectedApplication(null);
      setDealForm({
        vehicle_id: '',
        price: '',
        down_payment: '',
        credit_score: '',
        term_months: '60',
        deal_type: 'finance',
        msrp: '',
        cap_cost_reductions: '',
        capitalized_fees: '',
        tax_rate: '',
        annual_mileage: '',
        excess_mileage_rate: '0.25',
        sales_tax_rate: '',
        title_fee: '',
        license_fee: '',
        registration_fee: '',
        inspection_fee: '',
        processing_fee: '',
        trade_in_acv: '',
        trade_in_payoff: '',
        add_ons: '',
        protection_products: ''
      });
      
      // Reload deals tab
      if (activeTab !== 'deals') {
        setActiveTab('deals');
      } else {
        loadData();
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create deal",
        variant: "destructive",
      });
    } finally {
      setCreatingDeal(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <DollarSign className="h-8 w-8" />
              Finance & Lease Management
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage finance programs, deals, and credit applications
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate('/finance/applications')}
            >
              <FileText className="h-4 w-4 mr-2" />
              Applications
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/finance/analytics')}
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Analytics
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
          <TabsList>
            <TabsTrigger value="deals">
              <CreditCard className="h-4 w-4 mr-2" />
              Deals
            </TabsTrigger>
            <TabsTrigger value="programs">
              <TrendingUp className="h-4 w-4 mr-2" />
              Programs
            </TabsTrigger>
            <TabsTrigger value="applications">
              <FileText className="h-4 w-4 mr-2" />
              Credit Applications
            </TabsTrigger>
          </TabsList>

          {/* Deals Tab */}
          <TabsContent value="deals" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Finance & Lease Deals</CardTitle>
                    <CardDescription>View and manage all finance and lease deals</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Select value={dealFilters.status || "all"} onValueChange={(v) => setDealFilters({ ...dealFilters, status: v === "all" ? "" : v })}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="signed">Signed</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={dealFilters.deal_type || "all"} onValueChange={(v) => setDealFilters({ ...dealFilters, deal_type: v === "all" ? "" : v })}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="lease">Lease</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-8">Loading...</div>
                ) : deals.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No deals found
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Vehicle</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Monthly Payment</TableHead>
                        <TableHead>Down Payment</TableHead>
                        <TableHead>Term</TableHead>
                        <TableHead>Total Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deals.map((deal) => (
                        <TableRow key={deal.id}>
                          <TableCell>
                            {deal.year} {deal.make} {deal.model || 'N/A'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={deal.deal_type === 'finance' ? 'default' : 'secondary'}>
                              {deal.deal_type}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-semibold">
                            ${deal.monthly_payment.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}/mo
                          </TableCell>
                          <TableCell>${deal.down_payment.toLocaleString('en-US', { minimumFractionDigits: 2 })}</TableCell>
                          <TableCell>{deal.term_months} months</TableCell>
                          <TableCell>${deal.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</TableCell>
                          <TableCell>{getStatusBadge(deal.status)}</TableCell>
                          <TableCell>
                            {new Date(deal.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2 flex-wrap">
                              {/* View Details with Submissions */}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setSelectedDealForView(deal);
                                  loadDealSubmissions(deal.id);
                                  setShowDealDetailsDialog(true);
                                }}
                                title="View Deal Details & Submissions"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              
                              {/* Edit Deal */}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingDeal(deal);
                                  // Pre-populate edit form with deal data
                                  setEditDealForm({
                                    vehicle_id: '', // Vehicle can't be changed
                                    price: deal.vehicle_price?.toString() || '',
                                    down_payment: deal.down_payment?.toString() || '',
                                    credit_score: '', // From application
                                    term_months: deal.term_months?.toString() || '60',
                                    deal_type: deal.deal_type,
                                    // Lease-specific (we don't have these in the deal object, so leave empty)
                                    msrp: '',
                                    cap_cost_reductions: '',
                                    capitalized_fees: '',
                                    tax_rate: '',
                                    annual_mileage: '',
                                    excess_mileage_rate: '0.25',
                                    // Government fees (we don't have these in current deal object)
                                    sales_tax_rate: '',
                                    title_fee: '',
                                    license_fee: '',
                                    registration_fee: '',
                                    inspection_fee: '',
                                    processing_fee: '',
                                    // Trade-in
                                    trade_in_acv: '',
                                    trade_in_payoff: '',
                                    // Add-ons
                                    add_ons: '',
                                    protection_products: ''
                                  });
                                  setShowEditDealDialog(true);
                                }}
                                title="Edit Deal"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              
                              {/* Submit to Lender (if status = 'draft' or 'pending') */}
                              {(deal.status === 'draft' || deal.status === 'pending') && (
                                <>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedDealForAction(deal);
                                      setSelectedLendersForSubmit([]);
                                      setShowSubmitLenderDialog(true);
                                    }}
                                    title="Submit to Lender"
                                  >
                                    <Send className="h-4 w-4 mr-1" />
                                    Submit
                                  </Button>
                                  
                                  {/* Quick Test: Set to Approved */}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleQuickStatusUpdate(deal.id, 'approved')}
                                    title="[TEST] Mark as Approved"
                                    className="text-xs text-green-600 hover:text-green-700"
                                  >
                                    ✓ Approve
                                  </Button>
                                </>
                              )}
                              
                              {/* Generate PDF Deal Sheet (if status = 'approved' and no PDF) */}
                              {deal.status === 'approved' && !deal.latest_deal_sheet_id && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleGeneratePDF(deal)}
                                  disabled={generatingPDF}
                                  title="Generate PDF Deal Sheet"
                                >
                                  <FileText className="h-4 w-4 mr-1" />
                                  {generatingPDF ? 'Generating...' : 'Generate PDF'}
                                </Button>
                              )}
                              
                              {/* Download PDF (if exists) */}
                              {deal.latest_deal_sheet_id && deal.pdf_url && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => window.open(deal.pdf_url, '_blank')}
                                  title="Download PDF"
                                >
                                  <Download className="h-4 w-4" />
                                </Button>
                              )}
                              
                              {/* Request E-Signature (if PDF exists and no signature request) */}
                              {deal.latest_deal_sheet_id && !deal.signature_request_id && (
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => handleRequestSignature(deal)}
                                  disabled={requestingSignature}
                                  title="Request E-Signature"
                                >
                                  <PenTool className="h-4 w-4 mr-1" />
                                  {requestingSignature ? 'Sending...' : 'Request Signature'}
                                </Button>
                              )}
                              
                              {/* Signature Status (if signature requested) */}
                              {deal.signature_request_id && (
                                <Badge 
                                  variant={deal.signature_status === 'signed' ? 'default' : 'secondary'}
                                  className="flex items-center gap-1"
                                >
                                  {deal.signature_status === 'signed' ? (
                                    <><CheckCircle className="h-3 w-3" /> Signed</>
                                  ) : deal.signature_status === 'viewed' ? (
                                    <><Eye className="h-3 w-3" /> Viewed</>
                                  ) : (
                                    <><Clock className="h-3 w-3" /> Pending</>
                                  )}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Programs Tab */}
          <TabsContent value="programs" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Finance Programs</CardTitle>
                    <CardDescription>Manage finance and lease programs</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {canAccessFeature('finance_management' as any) && (
                      <Dialog open={showProgramDialog} onOpenChange={setShowProgramDialog}>
                        <DialogTrigger asChild>
                          <Button>
                            <Plus className="h-4 w-4 mr-2" />
                            Add Program
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Create Finance Program</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <p className="text-sm text-muted-foreground">
                              Program creation form would go here. This requires finance_management permission.
                            </p>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                    <Select value={programFilters.type || "all"} onValueChange={(v) => setProgramFilters({ ...programFilters, type: v === "all" ? "" : v })}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="lease">Lease</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-8">Loading...</div>
                ) : programs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No programs found
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Program Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Term</TableHead>
                        <TableHead>Credit Score Range</TableHead>
                        <TableHead>Rate/Factor</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {programs.map((program) => (
                        <TableRow key={program.id}>
                          <TableCell className="font-medium">{program.program_name}</TableCell>
                          <TableCell>
                            <Badge variant={program.type === 'finance' ? 'default' : 'secondary'}>
                              {program.type}
                            </Badge>
                          </TableCell>
                          <TableCell>{program.term_months} months</TableCell>
                          <TableCell>{program.tier_min_score} - {program.tier_max_score}</TableCell>
                          <TableCell>
                            {program.type === 'finance' 
                              ? `${program.interest_rate}% APR`
                              : `MF: ${program.money_factor} | Residual: ${program.residual_value_pct}%`
                            }
                          </TableCell>
                          <TableCell>{program.program_source}</TableCell>
                          <TableCell>
                            <Badge variant={program.is_active ? 'default' : 'outline'}>
                              {program.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {canAccessFeature('finance_management' as any) && (
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => {
                                  toast({
                                    title: "Program Details",
                                    description: `${program.program_name} | ${program.type} | ${program.term_months} months | ${program.tier_min_score}-${program.tier_max_score} credit range`,
                                  });
                                }}
                                title="View Program Details"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Applications Tab */}
          <TabsContent value="applications" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Credit Applications</CardTitle>
                    <CardDescription>View and manage credit applications</CardDescription>
                  </div>
                  <Select value={applicationFilters.status || "all"} onValueChange={(v) => setApplicationFilters({ ...applicationFilters, status: v === "all" ? "" : v })}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                      <SelectItem value="reviewing">Reviewing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-8">Loading...</div>
                ) : applications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No credit applications found
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Credit Score</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Lender</TableHead>
                        <TableHead>Submitted</TableHead>
                        <TableHead className="w-[300px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {applications.map((app) => (
                        <TableRow key={app.id}>
                          <TableCell className="font-medium">{app.customer_name}</TableCell>
                          <TableCell>{app.customer_email}</TableCell>
                          <TableCell>
                            {app.credit_score ? (
                              <Badge variant={app.credit_score >= 700 ? 'default' : app.credit_score >= 600 ? 'secondary' : 'destructive'}>
                                {app.credit_score}
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground">N/A</span>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(app.application_status)}</TableCell>
                          <TableCell>
                            {app.approved_lender_name ? (
                              <div className="space-y-1">
                                <Badge variant="default" className="bg-green-600">
                                  ✓ {app.approved_lender_name}
                                </Badge>
                                {app.lender_approval_date && (
                                  <div className="text-xs text-muted-foreground">
                                    {new Date(app.lender_approval_date).toLocaleDateString()}
                                  </div>
                                )}
                              </div>
                            ) : app.preferred_lender_name ? (
                              <Badge variant="secondary">
                                ⏳ {app.preferred_lender_name}
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground text-sm">No lender</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {new Date(app.submitted_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {app.application_status === 'pending' && (
                                <>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleUpdateApplicationStatus(app.id, 'approved')}
                                    disabled={updatingStatus === app.id}
                                    className="text-green-600 hover:text-green-700"
                                  >
                                    <Check className="h-3 w-3 mr-1" />
                                    Approve
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleUpdateApplicationStatus(app.id, 'reviewing')}
                                    disabled={updatingStatus === app.id}
                                    className="text-blue-600 hover:text-blue-700"
                                  >
                                    <Clock className="h-3 w-3 mr-1" />
                                    Review
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleUpdateApplicationStatus(app.id, 'rejected')}
                                    disabled={updatingStatus === app.id}
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <X className="h-3 w-3 mr-1" />
                                    Reject
                                  </Button>
                                </>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setEditingApplication(app);
                                  setAppEditForm({
                                    customer_name: app.customer_name,
                                    customer_email: app.customer_email,
                                    customer_phone: app.customer_phone || '',
                                    credit_score: app.credit_score?.toString() || '',
                                    preferred_lender_id: app.preferred_lender_id || '',
                                    notes: app.notes || ''
                                  });
                                  setShowAppEditDialog(true);
                                }}
                                title="Edit Application"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              {(app.application_status === 'approved' || app.application_status === 'pending') && (
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedApplication(app);
                                    setDealForm({
                                      vehicle_id: '',
                                      price: '',
                                      down_payment: '',
                                      credit_score: app.credit_score?.toString() || '700',
                                      term_months: '60',
                                      deal_type: 'finance',
                                      msrp: '',
                                      cap_cost_reductions: '',
                                      capitalized_fees: '',
                                      tax_rate: '',
                                      annual_mileage: '',
                                      excess_mileage_rate: '0.25',
                                      sales_tax_rate: '',
                                      title_fee: '',
                                      license_fee: '',
                                      registration_fee: '',
                                      inspection_fee: '',
                                      processing_fee: '',
                                      trade_in_acv: '',
                                      trade_in_payoff: '',
                                      add_ons: '',
                                      protection_products: ''
                                    });
                                    setShowCreateDealDialog(true);
                                  }}
                                  title="Create Finance Deal"
                                >
                                  <Calculator className="h-3 w-3 mr-1" />
                                  Create Deal
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={async () => {
                                  try {
                                    setLoadingAppDetails(true);
                                    setSelectedAppForView(app);
                                    const response = await financeAPI.getCreditApplication(app.id);
                                    const application = response.data || response;
                                    setAppDetails(application);
                                    setShowAppViewDialog(true);
                                  } catch (error: any) {
                                    toast({
                                      title: "Error",
                                      description: error.message || "Failed to load application details",
                                      variant: "destructive",
                                    });
                                  } finally {
                                    setLoadingAppDetails(false);
                                  }
                                }}
                                title="View Application Details"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Application Details Dialog */}
        <Dialog open={showAppViewDialog} onOpenChange={setShowAppViewDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Credit Application Details</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {loadingAppDetails ? (
                <div className="text-center py-8">Loading application details...</div>
              ) : appDetails ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Customer Name</Label>
                      <p className="font-medium">{appDetails.customer_name}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Email</Label>
                      <p className="font-medium">{appDetails.customer_email}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Phone</Label>
                      <p className="font-medium">{appDetails.customer_phone || 'N/A'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Credit Score</Label>
                      <p className="font-medium">
                        {appDetails.credit_score ? (
                          <Badge variant={appDetails.credit_score >= 700 ? 'default' : appDetails.credit_score >= 600 ? 'secondary' : 'destructive'}>
                            {appDetails.credit_score}
                          </Badge>
                        ) : (
                          'N/A'
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Status</Label>
                      <p>{getStatusBadge(appDetails.application_status)}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Submitted At</Label>
                      <p className="font-medium">
                        {new Date(appDetails.submitted_at).toLocaleString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                  {appDetails.reviewed_at && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-muted-foreground">Reviewed At</Label>
                        <p className="font-medium">
                          {new Date(appDetails.reviewed_at).toLocaleString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  )}
                  {appDetails.notes && (
                    <div>
                      <Label className="text-muted-foreground">Notes</Label>
                      <p className="font-medium">{appDetails.notes}</p>
                    </div>
                  )}
                  {(appDetails.ssn_masked || appDetails.dl_masked) && (
                    <div className="grid grid-cols-2 gap-4">
                      {appDetails.ssn_masked && (
                        <div>
                          <Label className="text-muted-foreground">SSN</Label>
                          <p className="font-mono">{appDetails.ssn_masked}</p>
                        </div>
                      )}
                      {appDetails.dl_masked && (
                        <div>
                          <Label className="text-muted-foreground">Driver's License</Label>
                          <p className="font-mono">{appDetails.dl_masked}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">No application details available</div>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Application Dialog */}
        <Dialog open={showAppEditDialog} onOpenChange={setShowAppEditDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Credit Application</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_customer_name">Customer Name *</Label>
                  <Input
                    id="edit_customer_name"
                    value={appEditForm.customer_name}
                    onChange={(e) => setAppEditForm({ ...appEditForm, customer_name: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_customer_email">Email *</Label>
                  <Input
                    id="edit_customer_email"
                    type="email"
                    value={appEditForm.customer_email}
                    onChange={(e) => setAppEditForm({ ...appEditForm, customer_email: e.target.value })}
                    placeholder="john@example.com"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_customer_phone">Phone</Label>
                  <Input
                    id="edit_customer_phone"
                    value={appEditForm.customer_phone}
                    onChange={(e) => setAppEditForm({ ...appEditForm, customer_phone: e.target.value })}
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_credit_score">Credit Score</Label>
                  <Input
                    id="edit_credit_score"
                    type="number"
                    value={appEditForm.credit_score}
                    onChange={(e) => setAppEditForm({ ...appEditForm, credit_score: e.target.value })}
                    placeholder="700"
                    min="300"
                    max="850"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="edit_preferred_lender">Preferred Lender</Label>
                <Select 
                  value={appEditForm.preferred_lender_id || 'none'} 
                  onValueChange={(value) => setAppEditForm({ ...appEditForm, preferred_lender_id: value === 'none' ? '' : value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a lender (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Lender</SelectItem>
                    {lenders.map((lender) => (
                      <SelectItem key={lender.id} value={lender.id}>
                        {lender.lender_name} ({lender.lender_type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Select the lender you want to process this application
                </p>
              </div>
              
              <div>
                <Label htmlFor="edit_notes">Notes</Label>
                <textarea
                  id="edit_notes"
                  className="w-full min-h-[100px] px-3 py-2 border rounded-md"
                  value={appEditForm.notes}
                  onChange={(e) => setAppEditForm({ ...appEditForm, notes: e.target.value })}
                  placeholder="Add any notes about this application..."
                />
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowAppEditDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={async () => {
                    try {
                      await financeAPI.updateCreditApplication(editingApplication!.id, {
                        customer_name: appEditForm.customer_name,
                        customer_email: appEditForm.customer_email,
                        customer_phone: appEditForm.customer_phone || null,
                        credit_score: appEditForm.credit_score ? parseInt(appEditForm.credit_score) : null,
                        preferred_lender_id: appEditForm.preferred_lender_id || null,
                        notes: appEditForm.notes || null
                      });
                      
                      toast({
                        title: "Success",
                        description: "Application updated successfully",
                      });
                      
                      setShowAppEditDialog(false);
                      loadData();
                    } catch (error: any) {
                      toast({
                        title: "Error",
                        description: error.message || "Failed to update application",
                        variant: "destructive",
                      });
                    }
                  }}
                  disabled={!appEditForm.customer_name || !appEditForm.customer_email}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Submit to Lender Dialog */}
        <Dialog open={showSubmitLenderDialog} onOpenChange={setShowSubmitLenderDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Submit Deal to Lender(s)</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {selectedDealForAction && (
                <div className="bg-muted p-4 rounded-md mb-4">
                  <h3 className="font-semibold mb-2">Deal Information</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Vehicle:</span>{' '}
                      <span className="font-medium">
                        {selectedDealForAction.year} {selectedDealForAction.make} {selectedDealForAction.model}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Monthly Payment:</span>{' '}
                      <span className="font-medium">
                        ${selectedDealForAction.monthly_payment.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Down Payment:</span>{' '}
                      <span className="font-medium">
                        ${selectedDealForAction.down_payment.toLocaleString('en-US')}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Term:</span>{' '}
                      <span className="font-medium">{selectedDealForAction.term_months} months</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div>
                <Label>Select Lender(s) to Submit To</Label>
                <p className="text-xs text-muted-foreground mb-3">
                  You can select multiple lenders. The deal will be submitted to all selected lenders.
                </p>
                <div className="border rounded-md p-4 max-h-[300px] overflow-y-auto space-y-2">
                  {lenders.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No active lenders found. Please add lenders first.
                    </div>
                  ) : (
                    lenders.map((lender) => (
                      <label 
                        key={lender.id} 
                        className="flex items-start space-x-3 p-3 hover:bg-muted rounded-md cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={selectedLendersForSubmit.includes(lender.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedLendersForSubmit([...selectedLendersForSubmit, lender.id]);
                            } else {
                              setSelectedLendersForSubmit(selectedLendersForSubmit.filter(id => id !== lender.id));
                            }
                          }}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <div className="font-medium">{lender.lender_name}</div>
                          <div className="text-sm text-muted-foreground">
                            {lender.lender_type}
                            {lender.min_credit_score && ` • Min Credit Score: ${lender.min_credit_score}`}
                            {lender.max_ltv && ` • Max LTV: ${lender.max_ltv}%`}
                          </div>
                        </div>
                        {lender.is_preferred && (
                          <Badge variant="secondary">Preferred</Badge>
                        )}
                      </label>
                    ))
                  )}
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowSubmitLenderDialog(false);
                    setSelectedLendersForSubmit([]);
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmitToLenders}
                  disabled={submittingToLenders || selectedLendersForSubmit.length === 0}
                >
                  {submittingToLenders ? 'Submitting...' : `Submit to ${selectedLendersForSubmit.length} Lender(s)`}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Deal Details & Submissions Dialog */}
        <Dialog open={showDealDetailsDialog} onOpenChange={setShowDealDetailsDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Deal Details & Lender Submissions</DialogTitle>
            </DialogHeader>
            
            {selectedDealForView && (
              <div className="space-y-6">
                {/* Deal Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Deal Information</CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Vehicle</Label>
                      <p className="font-semibold">
                        {selectedDealForView.year} {selectedDealForView.make} {selectedDealForView.model}
                      </p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Type</Label>
                      <p><Badge>{selectedDealForView.deal_type}</Badge></p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Monthly Payment</Label>
                      <p className="font-semibold text-lg">
                        ${selectedDealForView.monthly_payment.toLocaleString('en-US', { minimumFractionDigits: 2 })}/mo
                      </p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Down Payment</Label>
                      <p>${selectedDealForView.down_payment.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Term</Label>
                      <p>{selectedDealForView.term_months} months</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">APR</Label>
                      <p>{selectedDealForView.apr}%</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Vehicle Price</Label>
                      <p>${selectedDealForView.vehicle_price.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Total Amount</Label>
                      <p className="font-semibold">
                        ${selectedDealForView.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Status</Label>
                      <p>{getStatusBadge(selectedDealForView.status)}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Created</Label>
                      <p>{new Date(selectedDealForView.created_at).toLocaleString()}</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Lender Submissions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>Lender Submissions ({dealSubmissions.length})</span>
                      {dealSubmissions.length > 0 && (
                        <Badge variant="outline">
                          {dealSubmissions.filter(s => s.submission_status === 'approved').length} Approved
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {loadingSubmissions ? (
                      <div className="text-center py-4">Loading submissions...</div>
                    ) : dealSubmissions.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Send className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>No lender submissions yet</p>
                        <p className="text-sm mt-1">Submit this deal to lenders to track their responses</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {dealSubmissions.map((submission) => (
                          <Card key={submission.id} className="border">
                            <CardContent className="pt-4">
                              <div className="flex items-start justify-between mb-3">
                                <div>
                                  <h4 className="font-semibold text-lg">{submission.lender_name}</h4>
                                  <Badge variant="outline" className="mt-1">{submission.lender_type}</Badge>
                                </div>
                                <Badge 
                                  variant={
                                    submission.submission_status === 'approved' ? 'default' :
                                    submission.submission_status === 'rejected' ? 'destructive' :
                                    submission.submission_status === 'countered' ? 'secondary' :
                                    'outline'
                                  }
                                  className="text-sm"
                                >
                                  {submission.submission_status === 'approved' && <CheckCircle className="h-3 w-3 mr-1" />}
                                  {submission.submission_status === 'rejected' && <X className="h-3 w-3 mr-1" />}
                                  {submission.submission_status === 'pending' && <Clock className="h-3 w-3 mr-1" />}
                                  {submission.submission_status.toUpperCase()}
                                </Badge>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-3 text-sm">
                                <div>
                                  <span className="text-muted-foreground">Submitted:</span>
                                  <p>{new Date(submission.submitted_at).toLocaleString()}</p>
                                </div>
                                {submission.responded_at && (
                                  <div>
                                    <span className="text-muted-foreground">Responded:</span>
                                    <p>{new Date(submission.responded_at).toLocaleString()}</p>
                                  </div>
                                )}
                                {submission.submitted_by_name && (
                                  <div>
                                    <span className="text-muted-foreground">Submitted By:</span>
                                    <p>{submission.submitted_by_name}</p>
                                  </div>
                                )}
                                {submission.lender_reference_number && (
                                  <div>
                                    <span className="text-muted-foreground">Reference #:</span>
                                    <p className="font-mono">{submission.lender_reference_number}</p>
                                  </div>
                                )}
                              </div>

                              {/* Approval Details */}
                              {submission.submission_status === 'approved' && (
                                <div className="mt-3 pt-3 border-t">
                                  <div className="grid grid-cols-3 gap-3 text-sm">
                                    {submission.approved_amount && (
                                      <div>
                                        <span className="text-muted-foreground">Approved Amount:</span>
                                        <p className="font-semibold text-green-600">
                                          ${submission.approved_amount.toLocaleString()}
                                        </p>
                                      </div>
                                    )}
                                    {submission.approved_apr && (
                                      <div>
                                        <span className="text-muted-foreground">APR:</span>
                                        <p className="font-semibold">{submission.approved_apr}%</p>
                                      </div>
                                    )}
                                    {submission.approved_term_months && (
                                      <div>
                                        <span className="text-muted-foreground">Term:</span>
                                        <p>{submission.approved_term_months} months</p>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Rejection Reason */}
                              {submission.submission_status === 'rejected' && submission.rejection_reason && (
                                <div className="mt-3 pt-3 border-t">
                                  <span className="text-muted-foreground text-sm">Rejection Reason:</span>
                                  <p className="text-sm text-red-600 mt-1">{submission.rejection_reason}</p>
                                </div>
                              )}

                              {/* Notes */}
                              {submission.notes && (
                                <div className="mt-3 pt-3 border-t">
                                  <span className="text-muted-foreground text-sm">Notes:</span>
                                  <p className="text-sm mt-1">{submission.notes}</p>
                                </div>
                              )}
                              
                              {/* Update Status Button */}
                              <div className="mt-3 flex gap-2">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => {
                                    setSelectedSubmission(submission);
                                    setSubmissionUpdateForm({
                                      submission_status: submission.submission_status,
                                      approved_amount: submission.approved_amount?.toString() || '',
                                      approved_apr: submission.approved_apr?.toString() || '',
                                      approved_term_months: submission.approved_term_months?.toString() || '',
                                      rejection_reason: submission.rejection_reason || '',
                                      lender_reference_number: submission.lender_reference_number || ''
                                    });
                                    setShowUpdateSubmissionDialog(true);
                                  }}
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  Update Status
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Update Submission Dialog */}
        <Dialog open={showUpdateSubmissionDialog} onOpenChange={setShowUpdateSubmissionDialog}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Update Lender Submission</DialogTitle>
            </DialogHeader>
            
            {selectedSubmission && (
              <div className="space-y-4 py-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium">{selectedSubmission.lender_name}</p>
                  <p className="text-xs text-muted-foreground">Current Status: {selectedSubmission.submission_status}</p>
                </div>
                
                <div>
                  <Label>Status *</Label>
                  <Select 
                    value={submissionUpdateForm.submission_status} 
                    onValueChange={(v) => setSubmissionUpdateForm({ ...submissionUpdateForm, submission_status: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="submitted">Submitted</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                      <SelectItem value="countered">Countered</SelectItem>
                      <SelectItem value="withdrawn">Withdrawn</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {submissionUpdateForm.submission_status === 'approved' && (
                  <>
                    <div>
                      <Label>Approved Amount</Label>
                      <Input
                        type="number"
                        placeholder="Approved amount"
                        value={submissionUpdateForm.approved_amount}
                        onChange={(e) => setSubmissionUpdateForm({ ...submissionUpdateForm, approved_amount: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Approved APR (%)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="APR"
                        value={submissionUpdateForm.approved_apr}
                        onChange={(e) => setSubmissionUpdateForm({ ...submissionUpdateForm, approved_apr: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Approved Term (months)</Label>
                      <Input
                        type="number"
                        placeholder="Term in months"
                        value={submissionUpdateForm.approved_term_months}
                        onChange={(e) => setSubmissionUpdateForm({ ...submissionUpdateForm, approved_term_months: e.target.value })}
                      />
                    </div>
                  </>
                )}

                {submissionUpdateForm.submission_status === 'rejected' && (
                  <div>
                    <Label>Rejection Reason</Label>
                    <Input
                      placeholder="Why was this rejected?"
                      value={submissionUpdateForm.rejection_reason}
                      onChange={(e) => setSubmissionUpdateForm({ ...submissionUpdateForm, rejection_reason: e.target.value })}
                    />
                  </div>
                )}

                <div>
                  <Label>Lender Reference Number</Label>
                  <Input
                    placeholder="Lender's reference/tracking number"
                    value={submissionUpdateForm.lender_reference_number}
                    onChange={(e) => setSubmissionUpdateForm({ ...submissionUpdateForm, lender_reference_number: e.target.value })}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowUpdateSubmissionDialog(false);
                      setSelectedSubmission(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleUpdateSubmission}
                    disabled={updatingSubmission || !submissionUpdateForm.submission_status}
                  >
                    {updatingSubmission ? 'Updating...' : 'Update Submission'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Deal Dialog */}
        <Dialog open={showEditDealDialog} onOpenChange={setShowEditDealDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit {editDealForm.deal_type === 'finance' ? 'Finance' : 'Lease'} Deal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium">
                  Vehicle: {editingDeal?.year} {editingDeal?.make} {editingDeal?.model}
                </p>
                <p className="text-xs text-muted-foreground">
                  Current Status: {editingDeal?.status}
                </p>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label>Deal Type</Label>
                  <Select 
                    value={editDealForm.deal_type} 
                    disabled
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="lease">Lease</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Deal type cannot be changed</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit_price">{editDealForm.deal_type === 'finance' ? 'Vehicle Price' : 'Capitalized Cost'} *</Label>
                    <Input
                      id="edit_price"
                      type="number"
                      value={editDealForm.price}
                      onChange={(e) => setEditDealForm({ ...editDealForm, price: e.target.value })}
                      placeholder="30000"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit_down_payment">Down Payment</Label>
                    <Input
                      id="edit_down_payment"
                      type="number"
                      value={editDealForm.down_payment}
                      onChange={(e) => setEditDealForm({ ...editDealForm, down_payment: e.target.value })}
                      placeholder="5000"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit_term_months">Term (Months) *</Label>
                    <Select
                      value={editDealForm.term_months}
                      onValueChange={(v) => setEditDealForm({ ...editDealForm, term_months: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24">24 months</SelectItem>
                        <SelectItem value="36">36 months</SelectItem>
                        <SelectItem value="48">48 months</SelectItem>
                        <SelectItem value="60">60 months</SelectItem>
                        <SelectItem value="72">72 months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Finance-specific fields */}
                {editDealForm.deal_type === 'finance' && (
                  <Accordion type="single" collapsible className="w-full">
                    {/* Government Fees */}
                    <AccordionItem value="fees">
                      <AccordionTrigger className="text-sm font-medium">
                        Government Fees (TTL) - Optional
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 pt-2">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="edit_sales_tax_rate">Sales Tax Rate (e.g., 0.065)</Label>
                              <Input
                                id="edit_sales_tax_rate"
                                type="number"
                                step="0.0001"
                                value={editDealForm.sales_tax_rate}
                                onChange={(e) => setEditDealForm({ ...editDealForm, sales_tax_rate: e.target.value })}
                                placeholder="0.065"
                              />
                            </div>
                            <div>
                              <Label htmlFor="edit_title_fee">Title Fee</Label>
                              <Input
                                id="edit_title_fee"
                                type="number"
                                value={editDealForm.title_fee}
                                onChange={(e) => setEditDealForm({ ...editDealForm, title_fee: e.target.value })}
                                placeholder="150"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="edit_license_fee">License Fee</Label>
                              <Input
                                id="edit_license_fee"
                                type="number"
                                value={editDealForm.license_fee}
                                onChange={(e) => setEditDealForm({ ...editDealForm, license_fee: e.target.value })}
                                placeholder="75"
                              />
                            </div>
                            <div>
                              <Label htmlFor="edit_registration_fee">Registration Fee</Label>
                              <Input
                                id="edit_registration_fee"
                                type="number"
                                value={editDealForm.registration_fee}
                                onChange={(e) => setEditDealForm({ ...editDealForm, registration_fee: e.target.value })}
                                placeholder="100"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="edit_inspection_fee">Inspection Fee</Label>
                              <Input
                                id="edit_inspection_fee"
                                type="number"
                                value={editDealForm.inspection_fee}
                                onChange={(e) => setEditDealForm({ ...editDealForm, inspection_fee: e.target.value })}
                                placeholder="25"
                              />
                            </div>
                            <div>
                              <Label htmlFor="edit_processing_fee">Processing/Doc Fee</Label>
                              <Input
                                id="edit_processing_fee"
                                type="number"
                                value={editDealForm.processing_fee}
                                onChange={(e) => setEditDealForm({ ...editDealForm, processing_fee: e.target.value })}
                                placeholder="299"
                              />
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Trade-In */}
                    <AccordionItem value="tradein">
                      <AccordionTrigger className="text-sm font-medium">
                        Trade-In - Optional
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 pt-2">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="edit_trade_in_acv">ACV (Actual Cash Value)</Label>
                              <Input
                                id="edit_trade_in_acv"
                                type="number"
                                value={editDealForm.trade_in_acv}
                                onChange={(e) => setEditDealForm({ ...editDealForm, trade_in_acv: e.target.value })}
                                placeholder="15000"
                              />
                              <p className="text-xs text-muted-foreground mt-1">What dealer gives for trade-in</p>
                            </div>
                            <div>
                              <Label htmlFor="edit_trade_in_payoff">Payoff Amount</Label>
                              <Input
                                id="edit_trade_in_payoff"
                                type="number"
                                value={editDealForm.trade_in_payoff}
                                onChange={(e) => setEditDealForm({ ...editDealForm, trade_in_payoff: e.target.value })}
                                placeholder="12000"
                              />
                              <p className="text-xs text-muted-foreground mt-1">Amount customer still owes</p>
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Add-Ons */}
                    <AccordionItem value="addons">
                      <AccordionTrigger className="text-sm font-medium">
                        Add-Ons & Protection Products - Optional
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 pt-2">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="edit_add_ons">Add-Ons/Accessories Total</Label>
                              <Input
                                id="edit_add_ons"
                                type="number"
                                value={editDealForm.add_ons}
                                onChange={(e) => setEditDealForm({ ...editDealForm, add_ons: e.target.value })}
                                placeholder="500"
                              />
                            </div>
                            <div>
                              <Label htmlFor="edit_protection_products">Protection Products Total</Label>
                              <Input
                                id="edit_protection_products"
                                type="number"
                                value={editDealForm.protection_products}
                                onChange={(e) => setEditDealForm({ ...editDealForm, protection_products: e.target.value })}
                                placeholder="1500"
                              />
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                )}

                {/* Lease-specific fields */}
                {editDealForm.deal_type === 'lease' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="edit_msrp">MSRP</Label>
                        <Input
                          id="edit_msrp"
                          type="number"
                          value={editDealForm.msrp}
                          onChange={(e) => setEditDealForm({ ...editDealForm, msrp: e.target.value })}
                          placeholder="40000"
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit_tax_rate">Tax Rate</Label>
                        <Input
                          id="edit_tax_rate"
                          type="number"
                          step="0.0001"
                          value={editDealForm.tax_rate}
                          onChange={(e) => setEditDealForm({ ...editDealForm, tax_rate: e.target.value })}
                          placeholder="0.065"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="edit_cap_cost_reductions">Cap Cost Reductions</Label>
                        <Input
                          id="edit_cap_cost_reductions"
                          type="number"
                          value={editDealForm.cap_cost_reductions}
                          onChange={(e) => setEditDealForm({ ...editDealForm, cap_cost_reductions: e.target.value })}
                          placeholder="2000"
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit_capitalized_fees">Capitalized Fees</Label>
                        <Input
                          id="edit_capitalized_fees"
                          type="number"
                          value={editDealForm.capitalized_fees}
                          onChange={(e) => setEditDealForm({ ...editDealForm, capitalized_fees: e.target.value })}
                          placeholder="595"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="edit_annual_mileage">Annual Mileage</Label>
                        <Input
                          id="edit_annual_mileage"
                          type="number"
                          value={editDealForm.annual_mileage}
                          onChange={(e) => setEditDealForm({ ...editDealForm, annual_mileage: e.target.value })}
                          placeholder="12000"
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit_excess_mileage_rate">Excess Mileage Rate</Label>
                        <Input
                          id="edit_excess_mileage_rate"
                          type="number"
                          step="0.01"
                          value={editDealForm.excess_mileage_rate}
                          onChange={(e) => setEditDealForm({ ...editDealForm, excess_mileage_rate: e.target.value })}
                          placeholder="0.25"
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowEditDealDialog(false);
                      setEditingDeal(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleEditDeal}
                    disabled={updatingDeal || !editDealForm.price || !editDealForm.term_months}
                  >
                    {updatingDeal ? 'Updating...' : 'Update Deal'}
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Create Deal Dialog */}
        <Dialog open={showCreateDealDialog} onOpenChange={setShowCreateDealDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create {dealForm.deal_type === 'finance' ? 'Finance' : 'Lease'} Deal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {selectedApplication && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium">Customer: {selectedApplication.customer_name}</p>
                  <p className="text-sm text-muted-foreground">Credit Score: {selectedApplication.credit_score || 'N/A'}</p>
                </div>
              )}
              
              <div className="space-y-4">
                <div>
                  <Label>Deal Type</Label>
                  <Select 
                    value={dealForm.deal_type} 
                    onValueChange={(v: 'finance' | 'lease') => setDealForm({ ...dealForm, deal_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="lease">Lease</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="vehicle_id">Vehicle *</Label>
                  <Select
                    value={dealForm.vehicle_id}
                    onValueChange={(v) => {
                      const vehicle = vehicles.find(vh => vh.id === v);
                      setDealForm({
                        ...dealForm,
                        vehicle_id: v,
                        price: vehicle?.price?.toString() || ''
                      });
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a vehicle" />
                    </SelectTrigger>
                    <SelectContent>
                      {vehicles.map((vehicle) => (
                        <SelectItem key={vehicle.id} value={vehicle.id}>
                          {vehicle.year} {vehicle.make} {vehicle.model} - ${vehicle.price?.toLocaleString() || 'N/A'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="price">{dealForm.deal_type === 'finance' ? 'Vehicle Price' : 'Capitalized Cost'} *</Label>
                    <Input
                      id="price"
                      type="number"
                      value={dealForm.price}
                      onChange={(e) => setDealForm({ ...dealForm, price: e.target.value })}
                      placeholder="30000"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="down_payment">Down Payment</Label>
                    <Input
                      id="down_payment"
                      type="number"
                      value={dealForm.down_payment}
                      onChange={(e) => setDealForm({ ...dealForm, down_payment: e.target.value })}
                      placeholder="5000"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="credit_score">Credit Score *</Label>
                    <Input
                      id="credit_score"
                      type="number"
                      value={dealForm.credit_score}
                      onChange={(e) => setDealForm({ ...dealForm, credit_score: e.target.value })}
                      placeholder="720"
                      min="300"
                      max="850"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="term_months">Term (Months) *</Label>
                    <Select
                      value={dealForm.term_months}
                      onValueChange={(v) => setDealForm({ ...dealForm, term_months: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24">24 months</SelectItem>
                        <SelectItem value="36">36 months</SelectItem>
                        <SelectItem value="48">48 months</SelectItem>
                        <SelectItem value="60">60 months</SelectItem>
                        <SelectItem value="72">72 months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Additional Options - Collapsible Sections */}
                <Accordion type="multiple" className="w-full">
                  {/* Government Fees (TTL) */}
                  <AccordionItem value="government-fees">
                    <AccordionTrigger className="text-sm font-medium">
                      Government Fees (Tax, Title, License) - Optional
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="sales_tax_rate">Sales Tax Rate (e.g., 0.065 for 6.5%)</Label>
                            <Input
                              id="sales_tax_rate"
                              type="number"
                              step="0.0001"
                              value={dealForm.sales_tax_rate}
                              onChange={(e) => setDealForm({ ...dealForm, sales_tax_rate: e.target.value })}
                              placeholder="0.065"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Goes to State Comptroller</p>
                          </div>
                          <div>
                            <Label htmlFor="title_fee">Title Fee</Label>
                            <Input
                              id="title_fee"
                              type="number"
                              value={dealForm.title_fee}
                              onChange={(e) => setDealForm({ ...dealForm, title_fee: e.target.value })}
                              placeholder="150"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Goes to DMV</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="license_fee">License Fee</Label>
                            <Input
                              id="license_fee"
                              type="number"
                              value={dealForm.license_fee}
                              onChange={(e) => setDealForm({ ...dealForm, license_fee: e.target.value })}
                              placeholder="50"
                            />
                          </div>
                          <div>
                            <Label htmlFor="registration_fee">Registration Fee</Label>
                            <Input
                              id="registration_fee"
                              type="number"
                              value={dealForm.registration_fee}
                              onChange={(e) => setDealForm({ ...dealForm, registration_fee: e.target.value })}
                              placeholder="200"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="inspection_fee">Inspection Fee</Label>
                            <Input
                              id="inspection_fee"
                              type="number"
                              value={dealForm.inspection_fee}
                              onChange={(e) => setDealForm({ ...dealForm, inspection_fee: e.target.value })}
                              placeholder="25"
                            />
                          </div>
                          <div>
                            <Label htmlFor="processing_fee">Processing/Doc Fee</Label>
                            <Input
                              id="processing_fee"
                              type="number"
                              value={dealForm.processing_fee}
                              onChange={(e) => setDealForm({ ...dealForm, processing_fee: e.target.value })}
                              placeholder="500"
                            />
                          </div>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Trade-In */}
                  <AccordionItem value="trade-in">
                    <AccordionTrigger className="text-sm font-medium">
                      Trade-In - Optional
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="trade_in_acv">Actual Cash Value (ACV)</Label>
                            <Input
                              id="trade_in_acv"
                              type="number"
                              value={dealForm.trade_in_acv}
                              onChange={(e) => setDealForm({ ...dealForm, trade_in_acv: e.target.value })}
                              placeholder="15000"
                            />
                            <p className="text-xs text-muted-foreground mt-1">What dealer gives for trade-in</p>
                          </div>
                          <div>
                            <Label htmlFor="trade_in_payoff">Payoff Amount</Label>
                            <Input
                              id="trade_in_payoff"
                              type="number"
                              value={dealForm.trade_in_payoff}
                              onChange={(e) => setDealForm({ ...dealForm, trade_in_payoff: e.target.value })}
                              placeholder="12000"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Amount customer still owes</p>
                          </div>
                        </div>
                        {dealForm.trade_in_acv && dealForm.trade_in_payoff && (
                          <div className="p-3 bg-muted rounded-md">
                            <p className="text-sm">
                              <strong>Net Trade-In Credit:</strong> ${(parseFloat(dealForm.trade_in_acv || '0') - parseFloat(dealForm.trade_in_payoff || '0')).toLocaleString()}
                            </p>
                            {parseFloat(dealForm.trade_in_payoff || '0') > parseFloat(dealForm.trade_in_acv || '0') && (
                              <p className="text-sm text-destructive mt-1">
                                <strong>Negative Equity:</strong> ${(parseFloat(dealForm.trade_in_payoff || '0') - parseFloat(dealForm.trade_in_acv || '0')).toLocaleString()} (will be added to amount financed)
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Add-Ons & Protection Products */}
                  <AccordionItem value="addons">
                    <AccordionTrigger className="text-sm font-medium">
                      Add-Ons & Protection Products - Optional
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="add_ons">Add-Ons/Accessories Total</Label>
                            <Input
                              id="add_ons"
                              type="number"
                              value={dealForm.add_ons}
                              onChange={(e) => setDealForm({ ...dealForm, add_ons: e.target.value })}
                              placeholder="500"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Accessories, add-ons, etc.</p>
                          </div>
                          <div>
                            <Label htmlFor="protection_products">Protection Products Total</Label>
                            <Input
                              id="protection_products"
                              type="number"
                              value={dealForm.protection_products}
                              onChange={(e) => setDealForm({ ...dealForm, protection_products: e.target.value })}
                              placeholder="1500"
                            />
                            <p className="text-xs text-muted-foreground mt-1">GAP, VSC, Appearance, etc.</p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          💡 Tip: You can add individual protection products after creating the deal
                        </p>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                {/* Lease-specific fields */}
                {dealForm.deal_type === 'lease' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="msrp">MSRP (Manufacturer Suggested Retail Price)</Label>
                        <Input
                          id="msrp"
                          type="number"
                          value={dealForm.msrp}
                          onChange={(e) => setDealForm({ ...dealForm, msrp: e.target.value })}
                          placeholder="40000"
                        />
                        <p className="text-xs text-muted-foreground mt-1">Used for residual value calculation</p>
                      </div>
                      <div>
                        <Label htmlFor="tax_rate">Tax Rate (e.g., 0.065 for 6.5%)</Label>
                        <Input
                          id="tax_rate"
                          type="number"
                          step="0.0001"
                          value={dealForm.tax_rate}
                          onChange={(e) => setDealForm({ ...dealForm, tax_rate: e.target.value })}
                          placeholder="0.065"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="cap_cost_reductions">Cap Cost Reductions</Label>
                        <Input
                          id="cap_cost_reductions"
                          type="number"
                          value={dealForm.cap_cost_reductions}
                          onChange={(e) => setDealForm({ ...dealForm, cap_cost_reductions: e.target.value })}
                          placeholder="2000"
                        />
                        <p className="text-xs text-muted-foreground mt-1">Down payment, trade-in, rebates</p>
                      </div>
                      <div>
                        <Label htmlFor="capitalized_fees">Capitalized Fees</Label>
                        <Input
                          id="capitalized_fees"
                          type="number"
                          value={dealForm.capitalized_fees}
                          onChange={(e) => setDealForm({ ...dealForm, capitalized_fees: e.target.value })}
                          placeholder="595"
                        />
                        <p className="text-xs text-muted-foreground mt-1">Acquisition fee, etc.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="annual_mileage">Annual Mileage Allowance</Label>
                        <Input
                          id="annual_mileage"
                          type="number"
                          value={dealForm.annual_mileage}
                          onChange={(e) => setDealForm({ ...dealForm, annual_mileage: e.target.value })}
                          placeholder="12000"
                        />
                      </div>
                      <div>
                        <Label htmlFor="excess_mileage_rate">Excess Mileage Rate (per mile)</Label>
                        <Input
                          id="excess_mileage_rate"
                          type="number"
                          step="0.01"
                          value={dealForm.excess_mileage_rate}
                          onChange={(e) => setDealForm({ ...dealForm, excess_mileage_rate: e.target.value })}
                          placeholder="0.25"
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowCreateDealDialog(false);
                      setSelectedApplication(null);
                      setDealForm({
                        vehicle_id: '',
                        price: '',
                        down_payment: '',
                        credit_score: '',
                        term_months: '60',
                        deal_type: 'finance',
                        msrp: '',
                        cap_cost_reductions: '',
                        capitalized_fees: '',
                        tax_rate: '',
                        annual_mileage: '',
                        excess_mileage_rate: '0.25',
                        sales_tax_rate: '',
                        title_fee: '',
                        license_fee: '',
                        registration_fee: '',
                        inspection_fee: '',
                        processing_fee: '',
                        trade_in_acv: '',
                        trade_in_payoff: '',
                        add_ons: '',
                        protection_products: ''
                      });
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreateDeal}
                    disabled={creatingDeal}
                  >
                    {creatingDeal ? 'Creating...' : 'Create Deal'}
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default Finance;

