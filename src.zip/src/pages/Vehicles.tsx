import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { setupDevCacheClearing } from "@/lib/devCacheUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { VehicleForm } from "@/components/vehicles/VehicleForm";
import { VehicleImport } from "@/components/vehicles/VehicleImport";
import { VehicleTable } from "@/components/vehicles/VehicleTable";
import { VehicleGrid } from "@/components/vehicles/VehicleGrid";
import { VehicleFilters } from "@/components/vehicles/VehicleFilters";
import { BulkActions } from "@/components/vehicles/BulkActions";
import { QRCodeStickerModal } from "@/components/vehicles/QRCodeStickerModal";
import { Car, Plus, Search, Edit, Trash2, QrCode, Upload, LogOut, Download, Grid, List, RefreshCw, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { vehiclesAPI } from "@/lib/api";
import { clearDevCache } from "@/lib/devCacheUtils";
import { buildApiUrl } from "@/lib/config";
import type { Vehicle } from "@/types/vehicle";

const Vehicles = () => {
  const { user, signOut, loading: authLoading } = useAuth();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicles, setSelectedVehicles] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [isCorrectingFeatures, setIsCorrectingFeatures] = useState(false);
  const [isUpdatingTrimType, setIsUpdatingTrimType] = useState(false);
  // Pagination state
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false
  });
  
  // Filter state
  const [filters, setFilters] = useState({
    search: '',
    make: '',
    model: '',
    year: '',
    status: '',
    inventory_status: 'available', // Default to show only available vehicles
    sticker_status: '', // Filter by sticker status: printed, generated, not_generated, or empty for all
    new_used: '',
    stock_number: '',
    min_price: '',
    max_price: '',
    sort_by: 'created_at',
    sort_order: 'DESC'
  });

  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchVehicles(1, filters, true); // Initial load
    }
  }, [user]);


  // Setup development cache clearing
  useEffect(() => {
    setupDevCacheClearing();
  }, []);

  const fetchVehicles = async (page = pagination.page, newFilters = filters, isInitialLoad = false, customLimit = null) => {
    try {
      // Only show full page loading on initial load
      if (isInitialLoad) {
        setLoading(true);
      } else {
        setFilterLoading(true);
      }
      
      const response = await vehiclesAPI.getAll({
        page,
        limit: customLimit !== null ? customLimit : pagination.limit,
        ...newFilters
      });
      
      setVehicles(response.data);
      setPagination(response.pagination);
      
      // Only show toast for initial load or when there are results
      if (isInitialLoad && response.data.length > 0) {
        const limit = customLimit !== null ? customLimit : pagination.limit;
        const description = limit === -1 
          ? `Successfully loaded all ${response.data.length} vehicle(s)`
          : `Successfully loaded ${response.data.length} vehicle(s) (Page ${response.pagination.page} of ${response.pagination.totalPages})`;
        
        toast({
          title: "Vehicles loaded",
          description,
        });
      }
    } catch (error: any) {
      console.error("Error fetching vehicles:", error);
      toast({
        title: "Error",
        description: "Failed to fetch vehicles",
        variant: "destructive",
      });
    } finally {
      if (isInitialLoad) {
        setLoading(false);
      } else {
        setFilterLoading(false);
      }
    }
  };

  const deleteVehicle = async (vehicleId: string) => {
    if (!confirm("Are you sure you want to delete this vehicle?")) return;

    try {
      await vehiclesAPI.delete(vehicleId);
      // Refresh the current page after deletion
      await fetchVehicles();
      toast({
        title: "Success",
        description: "Vehicle deleted successfully",
      });
    } catch (error: any) {
      console.error("Error deleting vehicle:", error);
      toast({
        title: "Error",
        description: "Failed to delete vehicle",
        variant: "destructive",
      });
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out",
      });
      navigate("/auth");
    } catch (error) {
      console.error("Error signing out:", error);
      toast({
        title: "Sign out error",
        description: "Failed to sign out properly",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price?: number) => {
    if (!price) return "Price not set";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const generateQRCode = async (vehicleId: string) => {
    try {
      const response = await vehiclesAPI.generateQRCode(vehicleId);
      
      if (response.success && response.qrCodeUrl) {
        // Update the vehicle in the local state
        setVehicles(prev => prev.map(v => 
          v.id === vehicleId ? { ...v, qr_code_url: response.qrCodeUrl } : v
        ));
        
        toast({
          title: "Success",
          description: "QR code generated successfully",
        });
      } else {
        throw new Error("Failed to generate QR code");
      }
    } catch (error: any) {
      console.error("Error generating QR code:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to generate QR code",
        variant: "destructive",
      });
    }
  };

  const downloadQRCode = (qrCodeUrl: string, vehicleId: string) => {
    try {
      const link = document.createElement('a');
      link.href = qrCodeUrl;
      link.download = `vehicle-qr-${vehicleId}.png`;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "QR Code Downloaded",
        description: "QR code has been downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Download Error",
        description: "Failed to download QR code",
        variant: "destructive",
      });
    }
  };

  const clearCache = async () => {
    try {
      // Use the enhanced development cache clearing
      await clearDevCache(toast);
      
      // Refresh the vehicles data
      await fetchVehicles(1, filters, false);
    } catch (error) {
      console.error("Error clearing cache:", error);
      toast({
        title: "Cache Clear Error",
        description: "Failed to clear cache completely",
        variant: "destructive",
      });
    }
  };

  // Pagination handlers
  const handlePageChange = (newPage: number) => {
    setPagination(prev => ({ ...prev, page: newPage }));
    fetchVehicles(newPage, filters, false);
  };

  const handleLimitChange = (newLimit: number) => {
    setPagination(prev => ({ ...prev, limit: newLimit, page: 1 }));
    fetchVehicles(1, filters, false, newLimit);
  };

  // Filter handlers
  const handleFiltersChange = (newFilters: Partial<typeof filters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page when filters change
    // Note: API call will be triggered by onBlur events
  };

  // Handle filter blur (when user finishes typing and leaves field)
  const handleFilterBlur = () => {
    fetchVehicles(1, filters, false); // Filter load, not initial
  };

  const clearFilters = () => {
    const defaultFilters = {
      search: '',
      make: '',
      model: '',
      year: '',
      status: '',
      inventory_status: 'available', // Default to show only available vehicles
      sticker_status: '', // Reset sticker status filter
      new_used: '',
      stock_number: '',
      min_price: '',
      max_price: '',
      sort_by: 'created_at',
      sort_order: 'DESC'
    };
    setFilters(defaultFilters);
    setPagination(prev => ({ ...prev, page: 1 }));
    // Immediately fetch with cleared filters
    fetchVehicles(1, defaultFilters, false);
  };

  const correctFeatureFormat = async () => {
    if (!confirm("This will correct the format of features for all vehicles in the database. This may take a while. Continue?")) {
      return;
    }

    setIsCorrectingFeatures(true);
    try {
      const response = await fetch(buildApiUrl('vehicles/correct-features'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to correct feature formats');
      }

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Feature Format Corrected",
          description: `Successfully updated ${result.updatedCount} vehicles with corrected feature formats`,
        });

        // Refresh vehicles to show updated data
        await fetchVehicles(1, filters, false);
      } else {
        throw new Error(result.error || 'Failed to correct feature formats');
      }
    } catch (error: any) {
      console.error("Error correcting feature formats:", error);
      
      // Try to get more detailed error information
      let errorMessage = "Failed to correct feature formats";
      if (error.message) {
        errorMessage = error.message;
      } else if (error.details) {
        errorMessage = error.details;
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsCorrectingFeatures(false);
    }
  };

  const downloadVehicleImages = async (vehicleId: string) => {
    try {
      const response = await fetch(buildApiUrl(`vehicles/${vehicleId}/download-images`), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to download vehicle images');
      }

      const result = await response.json();
      
      toast({
        title: "Images Downloaded",
        description: `Successfully downloaded ${result.downloadedCount} images for this vehicle`,
      });

      // Refresh vehicles to show updated data
      await fetchVehicles(1, filters, false);
    } catch (error: any) {
      console.error("Error downloading vehicle images:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to download vehicle images",
        variant: "destructive",
      });
    }
  };

  const updateVehicleTrimType = async () => {
    if (!confirm("This will update trim and type data for all vehicles. This may take a while. Continue?")) {
      return;
    }

    setIsUpdatingTrimType(true);
    try {
      const response = await vehiclesAPI.updateTrimType();
      
      toast({
        title: "Vehicle Data Updated",
        description: `Successfully updated ${response.stats.updatedType} vehicle types and ${response.stats.updatedTrim} vehicle trims`,
      });

      // Refresh vehicles to show updated data
      await fetchVehicles(1, filters, false);
    } catch (error: any) {
      console.error("Error updating vehicle trim and type:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to update vehicle trim and type data",
        variant: "destructive",
      });
    } finally {
      setIsUpdatingTrimType(false);
    }
  };

  const uploadVehicleImages = async (vehicleId: string, files: FileList) => {
    try {
      const formData = new FormData();
      Array.from(files).forEach(file => {
        formData.append('images', file);
      });

      const response = await vehiclesAPI.uploadImages(vehicleId, formData);
      
      toast({
        title: "Images Uploaded",
        description: `Successfully uploaded ${files.length} image(s) for this vehicle`,
      });

      // Refresh vehicles to show updated data
      await fetchVehicles(1, filters, false);
    } catch (error: any) {
      console.error("Error uploading vehicle images:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to upload vehicle images",
        variant: "destructive",
      });
    }
  };

  const markStickerAsPrinted = async (vehicleId: string) => {
    try {
      const response = await fetch(buildApiUrl(`vehicles/${vehicleId}/mark-sticker-printed`), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to mark sticker as printed');
      }

      toast({
        title: "Success",
        description: "Sticker marked as printed",
      });

      // Refresh vehicles to show updated data
      await fetchVehicles(1, filters, false);
    } catch (error: any) {
      console.error("Error marking sticker as printed:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to mark sticker as printed",
        variant: "destructive",
      });
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin  h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary">
              <Car className="h-4 w-4 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-bold text-foreground">DealerIQ</h1>
            <span className="text-muted-foreground text-sm">/ Vehicles</span>
          </div>
          <div className="flex items-center space-x-3">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={clearCache}
              className="flex items-center space-x-1"
              title="Clear cache and refresh data"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Clear Cache</span>
            </Button>
            {process.env.NODE_ENV === 'development' && (
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={() => {
                  if (confirm('Force reload page and clear all cache?')) {
                    window.location.reload();
                  }
                }}
                className="flex items-center space-x-1"
                title="Force reload for development"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Dev Reload</span>
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={correctFeatureFormat}
              disabled={isCorrectingFeatures}
              className="flex items-center space-x-1"
              title="Correct feature formats in database"
            >
              {isCorrectingFeatures ? (
                <div className="animate-spin h-3 w-3 border-b border-current rounded-full" />
              ) : (
                <Settings className="h-3 w-3" />
              )}
              <span>{isCorrectingFeatures ? 'Correcting...' : 'Fix Features'}</span>
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={updateVehicleTrimType}
              disabled={isUpdatingTrimType}
              className="flex items-center space-x-1"
              title="Update vehicle trim and type data"
            >
              {isUpdatingTrimType ? (
                <div className="animate-spin h-3 w-3 border-b border-current rounded-full" />
              ) : (
                <Settings className="h-3 w-3" />
              )}
              <span>{isUpdatingTrimType ? 'Updating...' : 'Update Trim/Type'}</span>
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("/dashboard")}>
              Dashboard
            </Button>
            <span className="text-xs text-muted-foreground">
              {user.email}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              className="flex items-center space-x-1"
            >
              <LogOut className="h-3 w-3" />
              <span>Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1">Vehicle Inventory</h2>
            <p className="text-sm text-muted-foreground">
              Manage your vehicle inventory and track sales
            </p>
          </div>
          <div className="flex space-x-3">
            <div className="flex border rounded-lg p-1">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="h-8"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('table')}
                className="h-8"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Quick Status Filter */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Show:</span>
              <Button
                variant={filters.inventory_status === 'available' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, inventory_status: 'available' }));
                  fetchVehicles(1, { ...filters, inventory_status: 'available' }, false);
                }}
                className="h-8"
              >
                Available
              </Button>
              <Button
                variant={filters.inventory_status === 'sold' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, inventory_status: 'sold' }));
                  fetchVehicles(1, { ...filters, inventory_status: 'sold' }, false);
                }}
                className="h-8"
              >
                Sold
              </Button>
              <Button
                variant={filters.inventory_status === '' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, inventory_status: '' }));
                  fetchVehicles(1, { ...filters, inventory_status: '' }, false);
                }}
                className="h-8"
              >
                All
              </Button>
            </div>
            
            {/* Quick Sticker Status Filter */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Stickers:</span>
              <Button
                variant={filters.sticker_status === 'printed' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, sticker_status: 'printed' }));
                  fetchVehicles(1, { ...filters, sticker_status: 'printed' }, false);
                }}
                className="h-8"
              >
                Printed
              </Button>
              <Button
                variant={filters.sticker_status === 'generated' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, sticker_status: 'generated' }));
                  fetchVehicles(1, { ...filters, sticker_status: 'generated' }, false);
                }}
                className="h-8"
              >
                Generated Only
              </Button>
              <Button
                variant={filters.sticker_status === 'not_generated' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, sticker_status: 'not_generated' }));
                  fetchVehicles(1, { ...filters, sticker_status: 'not_generated' }, false);
                }}
                className="h-8"
              >
                No Sticker
              </Button>
              <Button
                variant={filters.sticker_status === '' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setFilters(prev => ({ ...prev, sticker_status: '' }));
                  fetchVehicles(1, { ...filters, sticker_status: '' }, false);
                }}
                className="h-8"
              >
                All
              </Button>
            </div>
            
            <QRCodeStickerModal 
              vehicles={vehicles}
              onGenerateQR={generateQRCode}
              onRefresh={fetchVehicles}
            />
            <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Upload className="h-4 w-4" />
                  <span>Import CSV</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Import Vehicle Inventory</DialogTitle>
                </DialogHeader>
                <VehicleImport
                  onImportComplete={() => {
                    setShowImportDialog(false);
                    fetchVehicles();
                  }}
                />
              </DialogContent>
            </Dialog>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button variant="accent" className="flex items-center space-x-2">
                  <Plus className="h-4 w-4" />
                  <span>Add Vehicle</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Vehicle</DialogTitle>
                </DialogHeader>
                <VehicleForm
                  onSuccess={() => {
                    setShowAddDialog(false);
                    fetchVehicles();
                  }}
                  onCancel={() => setShowAddDialog(false)}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Filters */}
        <VehicleFilters 
          filters={filters}
          onFiltersChange={handleFiltersChange}
          onFilterBlur={handleFilterBlur}
          onClearFilters={clearFilters}
          totalCount={pagination.total}
          loading={filterLoading}
        />

        {/* Bulk Actions */}
        <BulkActions
          selectedVehicles={selectedVehicles}
          onClearSelection={() => setSelectedVehicles([])}
          onRefresh={() => fetchVehicles(1, filters, false)}
        />

        {/* Vehicle Content */}
        <div className="relative">
          {filterLoading && (
            <div className="absolute top-0 left-0 right-0 z-10 bg-background/80 backdrop-blur-sm rounded-lg">
              <div className="flex items-center justify-center py-8">
                <div className="flex items-center space-x-2">
                  <div className="animate-spin h-5 w-5 border-b-2 border-primary rounded-full"></div>
                  <span className="text-sm text-muted-foreground">Updating results...</span>
                </div>
              </div>
            </div>
          )}
          
          {viewMode === 'table' ? (
            <VehicleTable
              vehicles={vehicles}
              selectedVehicles={selectedVehicles}
              onSelectionChange={setSelectedVehicles}
              onEdit={setEditingVehicle}
              onDelete={deleteVehicle}
              onRefresh={() => fetchVehicles(1, filters, false)}
              onDownloadImages={downloadVehicleImages}
              onUploadImages={uploadVehicleImages}
              onMarkStickerPrinted={markStickerAsPrinted}
              pagination={pagination}
            />
          ) : (
          <VehicleGrid
            vehicles={vehicles}
            selectedVehicles={selectedVehicles}
            onSelectionChange={setSelectedVehicles}
            onEdit={setEditingVehicle}
            onDelete={deleteVehicle}
            onGenerateQR={generateQRCode}
            onDownloadQR={downloadQRCode}
            onDownloadImages={downloadVehicleImages}
            onUploadImages={uploadVehicleImages}
            onMarkStickerPrinted={markStickerAsPrinted}
            pagination={pagination}
          />
          )}
        </div>

        {/* Pagination Controls */}
        <div className="mt-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Show</span>
              <Select value={pagination.limit.toString()} onValueChange={(value) => handleLimitChange(parseInt(value))}>
                <SelectTrigger className={`w-20 ${pagination.limit === -1 ? 'bg-blue-50 border-blue-200' : ''}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                  <SelectItem value="-1">All</SelectItem>
                </SelectContent>
              </Select>
              <span className="text-sm text-muted-foreground">
                {pagination.limit === -1 ? '' : 'per page'}
              </span>
            </div>
            <div className="text-sm text-muted-foreground">
              {pagination.limit === -1 ? (
                `Showing all ${pagination.total} vehicles`
              ) : (
                `Showing ${((pagination.page - 1) * pagination.limit) + 1} to ${Math.min(pagination.page * pagination.limit, pagination.total)} of ${pagination.total} vehicles`
              )}
            </div>
          </div>
          
          {pagination.limit !== -1 && (
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={!pagination.hasPrevPage}
              >
                Previous
              </Button>
              
              <div className="flex items-center space-x-1">
                {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                  let pageNum;
                  if (pagination.totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (pagination.page <= 3) {
                    pageNum = i + 1;
                  } else if (pagination.page >= pagination.totalPages - 2) {
                    pageNum = pagination.totalPages - 4 + i;
                  } else {
                    pageNum = pagination.page - 2 + i;
                  }
                  
                  return (
                    <Button
                      key={pageNum}
                      variant={pagination.page === pageNum ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePageChange(pageNum)}
                      className="w-8 h-8 p-0"
                    >
                      {pageNum}
                    </Button>
                  );
                })}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={!pagination.hasNextPage}
              >
                Next
              </Button>
            </div>
          )}
        </div>
      </main>

      {/* Edit Vehicle Dialog */}
      <Dialog open={!!editingVehicle} onOpenChange={() => setEditingVehicle(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Vehicle</DialogTitle>
          </DialogHeader>
          {editingVehicle && (
            <VehicleForm
              vehicle={editingVehicle}
              onSuccess={() => {
                setEditingVehicle(null);
                fetchVehicles();
              }}
              onCancel={() => setEditingVehicle(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Vehicles;