/**
 * Customer Management Page
 * CRM interface for managing customers and generating application links
 */

import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { api } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Link as LinkIcon, 
  Mail, 
  MessageSquare, 
  Copy, 
  ExternalLink, 
  ArrowLeft,
  FileText,
  Calendar
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Customer {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone: string;
  created_at: string;
  last_login: string;
  application_count: number;
  last_application_date: string;
}

interface Vehicle {
  id: string;
  make: string;
  model: string;
  year: number;
}

const CustomerManagement = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string>('none');
  const [generatedLink, setGeneratedLink] = useState<string>('');
  const [linkExpiry, setLinkExpiry] = useState('168'); // 7 days in hours
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    console.log('CustomerManagement - Auth check:', { 
      hasToken: !!token, 
      hasUser: !!user,
      userEmail: user?.email 
    });
    
    if (token && user) {
      loadCustomers();
      loadVehicles();
    }
  }, [searchTerm, showAll, user]);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      
      // Build query params
      const params = new URLSearchParams();
      if (searchTerm) {
        params.append('search', searchTerm);
      }
      if (showAll) {
        params.append('all', 'true');
      }
      
      const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';
      const url = `${API_BASE_URL}/api/customers${params.toString() ? `?${params.toString()}` : ''}`;
      console.log('Loading customers from:', url);
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('Response status:', response.status);
      console.log('Response headers:', response.headers.get('content-type'));
      
      if (!response.ok) {
        const text = await response.text();
        console.error('Error response:', text.substring(0, 200));
        throw new Error(`Failed to fetch: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Customers response:', data);
      
      setCustomers(data.data || []);
    } catch (error: any) {
      console.error('Error loading customers:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to load customers',
        variant: 'destructive',
      });
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  const loadVehicles = async () => {
    try {
      console.log('Loading vehicles...');
      const response = await api.getVehicles();
      console.log('Vehicles loaded:', response?.length || 0, 'vehicles');
      setVehicles(response || []);
    } catch (error: any) {
      console.error('Error loading vehicles:', error);
      console.error('Error details:', error.message);
      setVehicles([]); // Set empty array on error
      
      // Don't show error toast - just log it
      if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
        console.warn('Vehicle loading failed due to authentication. This is non-critical.');
      }
    }
  };

  const generateLink = async () => {
    if (!selectedCustomer) return;

    try {
      setGenerating(true);
      const response = await api.generateCustomerApplicationLink(
        selectedCustomer.id,
        {
          vehicleId: (selectedVehicle && selectedVehicle !== 'none') ? selectedVehicle : undefined,
          expiresIn: parseInt(linkExpiry)
        }
      );

      setGeneratedLink(response.link);
      
      toast({
        title: 'Link Generated!',
        description: 'Application link has been created successfully',
      });
    } catch (error: any) {
      console.error('Error generating link:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate link',
        variant: 'destructive',
      });
    } finally {
      setGenerating(false);
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(generatedLink);
    toast({
      title: 'Copied!',
      description: 'Link copied to clipboard',
    });
  };

  const sendViaEmail = async () => {
    if (!selectedCustomer) return;

    try {
      setSending(true);
      await api.sendCustomerApplicationLink(
        selectedCustomer.id,
        {
          vehicleId: (selectedVehicle && selectedVehicle !== 'none') ? selectedVehicle : undefined,
          expiresIn: parseInt(linkExpiry),
          method: 'email'
        }
      );

      toast({
        title: 'Email Sent!',
        description: `Application link sent to ${selectedCustomer.email}`,
      });
    } catch (error: any) {
      console.error('Error sending email:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to send email',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const sendViaSMS = async () => {
    if (!selectedCustomer) return;

    try {
      setSending(true);
      await api.sendCustomerApplicationLink(
        selectedCustomer.id,
        {
          vehicleId: (selectedVehicle && selectedVehicle !== 'none') ? selectedVehicle : undefined,
          expiresIn: parseInt(linkExpiry),
          method: 'sms'
        }
      );

      toast({
        title: 'SMS Sent!',
        description: `Application link sent to ${selectedCustomer.phone}`,
      });
    } catch (error: any) {
      console.error('Error sending SMS:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to send SMS',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const sendViaBoth = async () => {
    if (!selectedCustomer) return;

    try {
      setSending(true);
      await api.sendCustomerApplicationLink(
        selectedCustomer.id,
        {
          vehicleId: (selectedVehicle && selectedVehicle !== 'none') ? selectedVehicle : undefined,
          expiresIn: parseInt(linkExpiry),
          method: 'both'
        }
      );

      toast({
        title: 'Sent!',
        description: `Application link sent via email and SMS`,
      });
    } catch (error: any) {
      console.error('Error sending:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to send link',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };


  // Check if user is logged in
  if (!user) {
    return (
      <div className="p-6 space-y-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-semibold mb-2">Authentication Required</p>
              <p className="text-gray-600 mb-4">Please log in to access Customer Management</p>
              <Button onClick={() => navigate('/auth')}>
                Go to Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Users className="h-8 w-8" />
            Customer Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage customers and generate application links
          </p>
        </div>
        <div className="text-sm text-gray-500">
          {customers.length} customer{customers.length !== 1 ? 's' : ''}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Customers</CardTitle>
          <CardDescription>
            View customers and generate personalized application links
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="showAll"
                checked={showAll}
                onChange={(e) => setShowAll(e.target.checked)}
                className="h-4 w-4"
              />
              <label htmlFor="showAll" className="text-sm">
                Show all customers
              </label>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <p>Loading customers...</p>
            </div>
          ) : customers.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              {showAll || searchTerm ? (
                <>
                  <p>No customers found</p>
                  <p className="text-sm mt-2">Try a different search or check "Show all customers"</p>
                </>
              ) : (
                <>
                  <p>No customers have interacted with your dealership yet</p>
                  <p className="text-sm mt-2">
                    Customers appear here after submitting applications or chatting with DAIVE
                  </p>
                  <p className="text-sm mt-2">
                    💡 <strong>Tip:</strong> Check "Show all customers" to search and generate links for any customer
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Applications</TableHead>
                    <TableHead>Last Activity</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">
                        {customer.first_name} {customer.last_name}
                      </TableCell>
                      <TableCell>{customer.email}</TableCell>
                      <TableCell>{customer.phone || '-'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {customer.application_count}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {customer.last_application_date ? (
                            <>
                              <Calendar className="h-3 w-3 inline mr-1" />
                              {new Date(customer.last_application_date).toLocaleDateString()}
                            </>
                          ) : (
                            <span className="text-gray-400">Never</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setSelectedCustomer(customer);
                                setGeneratedLink('');
                                setSelectedVehicle('none');
                              }}
                            >
                              <LinkIcon className="h-4 w-4 mr-2" />
                              Generate Link
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Generate Application Link</DialogTitle>
                              <DialogDescription>
                                Create a shareable link for {customer.first_name} {customer.last_name}
                              </DialogDescription>
                            </DialogHeader>

                            <div className="space-y-4">
                              {/* Vehicle Selection */}
                              <div>
                                <Label>Vehicle (Optional)</Label>
                                <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a vehicle or leave blank for general application" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="none">No specific vehicle</SelectItem>
                                    {Array.isArray(vehicles) && vehicles.length > 0 ? (
                                      vehicles.map((v) => (
                                        <SelectItem key={v.id} value={v.id}>
                                          {v.year} {v.make} {v.model}
                                        </SelectItem>
                                      ))
                                    ) : (
                                      <div className="px-2 py-1.5 text-sm text-gray-500">
                                        No vehicles available
                                      </div>
                                    )}
                                  </SelectContent>
                                </Select>
                                <p className="text-xs text-gray-500 mt-1">
                                  {Array.isArray(vehicles) && vehicles.length > 0
                                    ? 'If selected, vehicle information will be pre-filled'
                                    : 'Add vehicles to your inventory to pre-fill vehicle information'}
                                </p>
                              </div>

                              {/* Link Expiry */}
                              <div>
                                <Label>Link Expiry</Label>
                                <Select value={linkExpiry} onValueChange={setLinkExpiry}>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="24">24 hours</SelectItem>
                                    <SelectItem value="72">3 days</SelectItem>
                                    <SelectItem value="168">7 days (recommended)</SelectItem>
                                    <SelectItem value="336">14 days</SelectItem>
                                    <SelectItem value="720">30 days</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>

                              {/* Generate Button */}
                              {!generatedLink && (
                                <Button 
                                  onClick={generateLink} 
                                  className="w-full"
                                  disabled={generating}
                                >
                                  <LinkIcon className="h-4 w-4 mr-2" />
                                  {generating ? 'Generating...' : 'Generate Link'}
                                </Button>
                              )}

                              {/* Generated Link Display */}
                              {generatedLink && (
                                <div className="space-y-3">
                                  <div>
                                    <Label>Generated Link</Label>
                                    <div className="flex gap-2 mt-2">
                                      <Input 
                                        readOnly 
                                        value={generatedLink}
                                        className="font-mono text-sm"
                                      />
                                      <Button onClick={copyLink} variant="outline" size="icon">
                                        <Copy className="h-4 w-4" />
                                      </Button>
                                      <Button 
                                        onClick={() => window.open(generatedLink, '_blank')}
                                        variant="outline"
                                        size="icon"
                                      >
                                        <ExternalLink className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">
                                      Link expires: {new Date(Date.now() + parseInt(linkExpiry) * 60 * 60 * 1000).toLocaleString()}
                                    </p>
                                  </div>

                                  {/* Quick Actions */}
                                  <div className="border-t pt-3">
                                    <Label className="mb-2 block">Send to Customer</Label>
                                    <div className="grid grid-cols-3 gap-2">
                                      <Button 
                                        onClick={sendViaEmail}
                                        variant="outline"
                                        disabled={sending}
                                        className="flex-1"
                                      >
                                        <Mail className="h-4 w-4 mr-2" />
                                        Email
                                      </Button>
                                      <Button 
                                        onClick={sendViaSMS}
                                        variant="outline"
                                        disabled={sending || !customer.phone}
                                        className="flex-1"
                                      >
                                        <MessageSquare className="h-4 w-4 mr-2" />
                                        SMS
                                      </Button>
                                      <Button 
                                        onClick={sendViaBoth}
                                        disabled={sending || !customer.phone}
                                        className="flex-1"
                                      >
                                        <FileText className="h-4 w-4 mr-2" />
                                        Both
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerManagement;

