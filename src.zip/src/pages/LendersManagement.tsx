/**
 * Lenders Management Page
 * Manage lender relationships and submissions
 */

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';
import { lendersAPI } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Plus, Eye, Edit, Trash2, Star, Building, CreditCard, Check, X } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';

interface Lender {
  id: string;
  lender_name: string;
  lender_type: string;
  contact_name?: string;
  contact_email?: string;
  contact_phone?: string;
  min_credit_score?: number;
  is_active: boolean;
  is_preferred: boolean;
  scope: 'global' | 'dealer';
  created_at: string;
}

const LendersManagement = () => {
  const { user, loading: authLoading } = useAuth();
  const { canAccessFeature } = usePermissions();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [lenders, setLenders] = useState<Lender[]>([]);
  const [filteredLenders, setFilteredLenders] = useState<Lender[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [selectedLender, setSelectedLender] = useState<Lender | null>(null);
  const [saving, setSaving] = useState(false);
  
  // Filters
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  
  // Form state
  const [formData, setFormData] = useState({
    lender_name: '',
    lender_type: 'Bank',
    contact_name: '',
    contact_email: '',
    contact_phone: '',
    website: '',
    address: '',
    min_credit_score: '',
    max_ltv: '',
    notes: '',
    is_preferred: false
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadLenders();
    }
  }, [user]);

  useEffect(() => {
    applyFilters();
  }, [lenders, typeFilter, activeFilter]);

  const loadLenders = async () => {
    try {
      setLoading(true);
      const response = await lendersAPI.getAll();
      setLenders(response.data || []);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load lenders',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...lenders];
    
    if (typeFilter !== 'all') {
      filtered = filtered.filter(l => l.lender_type === typeFilter);
    }
    
    if (activeFilter === 'active') {
      filtered = filtered.filter(l => l.is_active);
    } else if (activeFilter === 'inactive') {
      filtered = filtered.filter(l => !l.is_active);
    }
    
    setFilteredLenders(filtered);
  };

  const resetForm = () => {
    setFormData({
      lender_name: '',
      lender_type: 'Bank',
      contact_name: '',
      contact_email: '',
      contact_phone: '',
      website: '',
      address: '',
      min_credit_score: '',
      max_ltv: '',
      notes: '',
      is_preferred: false
    });
  };

  const handleCreate = async () => {
    if (!formData.lender_name) {
      toast({
        title: 'Error',
        description: 'Lender name is required',
        variant: 'destructive',
      });
      return;
    }

    try {
      setSaving(true);
      await lendersAPI.create(formData);
      
      toast({
        title: 'Success',
        description: 'Lender created successfully',
      });
      
      setShowCreateDialog(false);
      resetForm();
      loadLenders();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create lender',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!selectedLender || !formData.lender_name) {
      return;
    }

    try {
      setSaving(true);
      await lendersAPI.update(selectedLender.id, formData);
      
      toast({
        title: 'Success',
        description: 'Lender updated successfully',
      });
      
      setShowEditDialog(false);
      setSelectedLender(null);
      resetForm();
      loadLenders();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update lender',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (lenderId: string) => {
    if (!confirm('Are you sure you want to deactivate this lender?')) {
      return;
    }

    try {
      await lendersAPI.delete(lenderId);
      
      toast({
        title: 'Success',
        description: 'Lender deactivated successfully',
      });
      
      loadLenders();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to deactivate lender',
        variant: 'destructive',
      });
    }
  };

  const openEditDialog = (lender: Lender) => {
    setSelectedLender(lender);
    setFormData({
      lender_name: lender.lender_name,
      lender_type: lender.lender_type,
      contact_name: lender.contact_name || '',
      contact_email: lender.contact_email || '',
      contact_phone: lender.contact_phone || '',
      website: '',
      address: '',
      min_credit_score: lender.min_credit_score?.toString() || '',
      max_ltv: '',
      notes: '',
      is_preferred: lender.is_preferred
    });
    setShowEditDialog(true);
  };

  const openViewDialog = async (lender: Lender) => {
    try {
      const response = await lendersAPI.getById(lender.id);
      setSelectedLender(response.data);
      setShowViewDialog(true);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load lender details',
        variant: 'destructive',
      });
    }
  };

  const getLenderTypeBadge = (type: string) => {
    const colors: Record<string, 'default' | 'secondary' | 'outline'> = {
      Bank: 'default',
      CreditUnion: 'secondary',
      OEM: 'outline',
      InHouse: 'outline',
    };
    return <Badge variant={colors[type] || 'outline'}>{type}</Badge>;
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Building2 className="h-8 w-8" />
              Lenders Management
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your lender relationships and financing options
            </p>
          </div>
          {canAccessFeature('finance_management' as any) && (
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Lender
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Lenders</CardTitle>
            <CardDescription>View and manage all your lender relationships</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Bank">Bank</SelectItem>
                  <SelectItem value="CreditUnion">Credit Union</SelectItem>
                  <SelectItem value="OEM">OEM</SelectItem>
                  <SelectItem value="InHouse">In-House</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={activeFilter} onValueChange={setActiveFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {loading ? (
              <div className="text-center py-8">Loading...</div>
            ) : filteredLenders.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No lenders found
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Lender Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Min Credit Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Scope</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLenders.map((lender) => (
                    <TableRow key={lender.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {lender.is_preferred && (
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          )}
                          {lender.lender_name}
                        </div>
                      </TableCell>
                      <TableCell>{getLenderTypeBadge(lender.lender_type)}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {lender.contact_name && <div>{lender.contact_name}</div>}
                          {lender.contact_email && (
                            <div className="text-muted-foreground">{lender.contact_email}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {lender.min_credit_score ? (
                          <Badge variant="outline">{lender.min_credit_score}+</Badge>
                        ) : (
                          <span className="text-muted-foreground">N/A</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={lender.is_active ? 'default' : 'outline'}>
                          {lender.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={lender.scope === 'global' ? 'secondary' : 'outline'}>
                          {lender.scope}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openViewDialog(lender)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {lender.scope === 'dealer' && canAccessFeature('finance_management' as any) && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(lender)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(lender.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Create Lender Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Lender</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="lender_name">Lender Name *</Label>
                  <Input
                    id="lender_name"
                    value={formData.lender_name}
                    onChange={(e) => setFormData({ ...formData, lender_name: e.target.value })}
                    placeholder="Chase Auto Finance"
                  />
                </div>
                
                <div>
                  <Label htmlFor="lender_type">Type *</Label>
                  <Select
                    value={formData.lender_type}
                    onValueChange={(v) => setFormData({ ...formData, lender_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bank">Bank</SelectItem>
                      <SelectItem value="CreditUnion">Credit Union</SelectItem>
                      <SelectItem value="OEM">OEM</SelectItem>
                      <SelectItem value="InHouse">In-House</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="contact_name">Contact Name</Label>
                  <Input
                    id="contact_name"
                    value={formData.contact_name}
                    onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
                
                <div>
                  <Label htmlFor="contact_email">Contact Email</Label>
                  <Input
                    id="contact_email"
                    type="email"
                    value={formData.contact_email}
                    onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                    placeholder="contact@lender.com"
                  />
                </div>
                
                <div>
                  <Label htmlFor="contact_phone">Contact Phone</Label>
                  <Input
                    id="contact_phone"
                    value={formData.contact_phone}
                    onChange={(e) => setFormData({ ...formData, contact_phone: e.target.value })}
                    placeholder="(555) 123-4567"
                  />
                </div>
                
                <div>
                  <Label htmlFor="min_credit_score">Min Credit Score</Label>
                  <Input
                    id="min_credit_score"
                    type="number"
                    value={formData.min_credit_score}
                    onChange={(e) => setFormData({ ...formData, min_credit_score: e.target.value })}
                    placeholder="650"
                    min="300"
                    max="850"
                  />
                </div>
                
                <div>
                  <Label htmlFor="max_ltv">Max LTV (%)</Label>
                  <Input
                    id="max_ltv"
                    type="number"
                    value={formData.max_ltv}
                    onChange={(e) => setFormData({ ...formData, max_ltv: e.target.value })}
                    placeholder="125"
                    min="0"
                    max="200"
                  />
                </div>
                
                <div className="col-span-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Additional notes about this lender..."
                    rows={3}
                  />
                </div>
                
                <div className="col-span-2 flex items-center space-x-2">
                  <Switch
                    id="is_preferred"
                    checked={formData.is_preferred}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_preferred: checked })}
                  />
                  <Label htmlFor="is_preferred">Mark as preferred lender</Label>
                </div>
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCreateDialog(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={saving}>
                  {saving ? 'Creating...' : 'Create Lender'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Lender Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Lender</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="edit_lender_name">Lender Name *</Label>
                  <Input
                    id="edit_lender_name"
                    value={formData.lender_name}
                    onChange={(e) => setFormData({ ...formData, lender_name: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit_lender_type">Type *</Label>
                  <Select
                    value={formData.lender_type}
                    onValueChange={(v) => setFormData({ ...formData, lender_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bank">Bank</SelectItem>
                      <SelectItem value="CreditUnion">Credit Union</SelectItem>
                      <SelectItem value="OEM">OEM</SelectItem>
                      <SelectItem value="InHouse">In-House</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="edit_contact_name">Contact Name</Label>
                  <Input
                    id="edit_contact_name"
                    value={formData.contact_name}
                    onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit_contact_email">Contact Email</Label>
                  <Input
                    id="edit_contact_email"
                    type="email"
                    value={formData.contact_email}
                    onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit_contact_phone">Contact Phone</Label>
                  <Input
                    id="edit_contact_phone"
                    value={formData.contact_phone}
                    onChange={(e) => setFormData({ ...formData, contact_phone: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit_min_credit_score">Min Credit Score</Label>
                  <Input
                    id="edit_min_credit_score"
                    type="number"
                    value={formData.min_credit_score}
                    onChange={(e) => setFormData({ ...formData, min_credit_score: e.target.value })}
                    min="300"
                    max="850"
                  />
                </div>
                
                <div className="col-span-2 flex items-center space-x-2">
                  <Switch
                    id="edit_is_preferred"
                    checked={formData.is_preferred}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_preferred: checked })}
                  />
                  <Label htmlFor="edit_is_preferred">Mark as preferred lender</Label>
                </div>
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowEditDialog(false);
                    setSelectedLender(null);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button onClick={handleEdit} disabled={saving}>
                  {saving ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* View Lender Dialog */}
        <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Lender Details</DialogTitle>
            </DialogHeader>
            {selectedLender && (
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Lender Name</Label>
                    <p className="font-medium">{selectedLender.lender_name}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Type</Label>
                    <div>{getLenderTypeBadge(selectedLender.lender_type)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Status</Label>
                    <div>
                      <Badge variant={selectedLender.is_active ? 'default' : 'outline'}>
                        {selectedLender.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Preferred</Label>
                    <p>{selectedLender.is_preferred ? 'Yes' : 'No'}</p>
                  </div>
                  {selectedLender.contact_name && (
                    <div>
                      <Label className="text-muted-foreground">Contact Name</Label>
                      <p>{selectedLender.contact_name}</p>
                    </div>
                  )}
                  {selectedLender.contact_email && (
                    <div>
                      <Label className="text-muted-foreground">Contact Email</Label>
                      <p>{selectedLender.contact_email}</p>
                    </div>
                  )}
                  {selectedLender.contact_phone && (
                    <div>
                      <Label className="text-muted-foreground">Contact Phone</Label>
                      <p>{selectedLender.contact_phone}</p>
                    </div>
                  )}
                  {selectedLender.min_credit_score && (
                    <div>
                      <Label className="text-muted-foreground">Min Credit Score</Label>
                      <p>{selectedLender.min_credit_score}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default LendersManagement;

