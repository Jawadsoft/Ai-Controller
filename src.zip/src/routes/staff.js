import express from 'express';
import { body, validationResult } from 'express-validator';
import bcrypt from 'bcryptjs';
import { query } from '../database/connection.js';
import { authenticateToken, requireDealerAccess, requireStaffRole, requirePermission } from '../middleware/auth.js';

const router = express.Router();

// Apply authentication to all routes
router.use(authenticateToken);
router.use(requireDealerAccess);

// Check for staff management permission for all routes
const requireStaffManagement = async (req, res, next) => {
  try {
    // Super admin has all permissions
    if (req.user.role === 'super_admin') {
      return next();
    }

    // Check if user has admin staff role
    if (req.user.staff_role === 'admin') {
      return next();
    }

    // Check permission using database function
    const result = await query(
      'SELECT user_has_permission($1, $2) as has_permission',
      [req.user.id, 'staff_management']
    );

    if (!result.rows[0].has_permission) {
      return res.status(403).json({ error: 'Staff management permission required' });
    }

    next();
  } catch (error) {
    res.status(500).json({ error: 'Permission check failed' });
  }
};

router.use(requireStaffManagement);

// Check if admin exists for current dealer
router.get('/admin-exists', async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        ds.id,
        u.email,
        u.name,
        ds.created_at
       FROM dealership_staff ds
       JOIN users u ON ds.user_id = u.id
       WHERE ds.dealer_id = $1 AND ds.staff_role = 'admin' AND ds.is_active = true`,
      [req.user.dealer_id]
    );

    res.json({ 
      adminExists: result.rows.length > 0,
      admin: result.rows[0] || null
    });
  } catch (error) {
    console.error('Error checking admin existence:', error);
    res.status(500).json({ error: 'Failed to check admin existence' });
  }
});

// Get all staff members for current dealer
router.get('/', async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        ds.*,
        u.email,
        u.name,
        u.created_at as user_created_at,
        creator.email as created_by_email
       FROM dealership_staff ds
       JOIN users u ON ds.user_id = u.id
       LEFT JOIN users creator ON ds.created_by = creator.id
       WHERE ds.dealer_id = $1
       ORDER BY ds.created_at DESC`,
      [req.user.dealer_id]
    );

    res.json({ staff: result.rows });
  } catch (error) {
    console.error('Error fetching staff:', error);
    res.status(500).json({ error: 'Failed to fetch staff members' });
  }
});

// Get specific staff member
router.get('/:staffId', async (req, res) => {
  try {
    const { staffId } = req.params;

    const result = await query(
      `SELECT 
        ds.*,
        u.email,
        u.name,
        u.created_at as user_created_at,
        creator.email as created_by_email
       FROM dealership_staff ds
       JOIN users u ON ds.user_id = u.id
       LEFT JOIN users creator ON ds.created_by = creator.id
       WHERE ds.id = $1 AND ds.dealer_id = $2`,
      [staffId, req.user.dealer_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    res.json({ staff: result.rows[0] });
  } catch (error) {
    console.error('Error fetching staff member:', error);
    res.status(500).json({ error: 'Failed to fetch staff member' });
  }
});

// Create new staff member
router.post('/', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('staff_role').isIn(['admin', 'sales', 'finance', 'service', 'inventory']),
  body('permissions').optional().isArray(),
  body('name').optional().isLength({ min: 2, max: 255 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, staff_role, permissions = [], name } = req.body;

    // Resolve dealer_id robustly for both dealer owners and staff
    let dealerId = req.user.dealer_id;
    if (!dealerId) {
      const dealerLookup = await query('SELECT id FROM dealers WHERE user_id = $1 LIMIT 1', [req.user.id]);
      dealerId = dealerLookup.rows[0]?.id || null;
    }

    if (!dealerId) {
      return res.status(403).json({ error: 'Dealer access required to create staff' });
    }

    // Check if user already exists
    const existingUser = await query('SELECT id FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email already exists' });
    }

    // For all roles, multiple staff are allowed
    console.log('Creating staff member with role:', staff_role, 'for dealer_id:', dealerId);

    // Hash password
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Start transaction
    await query('BEGIN');

    try {
      // Create user
      const userResult = await query(
        'INSERT INTO users (email, password_hash, name) VALUES ($1, $2, $3) RETURNING id',
        [email, passwordHash, name || email.split('@')[0]]
      );
      const userId = userResult.rows[0].id;

      // Create user role
      await query(
        'INSERT INTO user_roles (user_id, role) VALUES ($1, $2)',
        [userId, 'dealer']
      );

      // Create staff member
      console.log('About to insert staff member with values:', {
        dealer_id: dealerId,
        user_id: userId,
        staff_role: staff_role,
        permissions: permissions,
        created_by: req.user.id
      });
      
      const staffResult = await query(
        `INSERT INTO dealership_staff (
          dealer_id, 
          user_id, 
          staff_role, 
          permissions, 
          created_by
        ) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
        [dealerId, userId, staff_role, permissions, req.user.id]
      );

      // Insert default permissions for the role
      const defaultPermissions = getDefaultPermissions(staff_role);
      for (const permission of defaultPermissions) {
        await query(
          'INSERT INTO staff_permissions (staff_id, permission_name, permission_value) VALUES ($1, $2, $3)',
          [staffResult.rows[0].id, permission, true]
        );
      }

      await query('COMMIT');

      res.status(201).json({
        message: 'Staff member created successfully',
        staff: staffResult.rows[0]
      });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error creating staff member:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      detail: error.detail,
      constraint: error.constraint
    });
    res.status(500).json({ 
      error: 'Failed to create staff member',
      details: error.message,
      code: error.code
    });
  }
});

// Update staff member
router.put('/:staffId', [
  body('staff_role').optional().isIn(['admin', 'sales', 'finance', 'service', 'inventory']),
  body('permissions').optional().isArray(),
  body('is_active').optional().isBoolean(),
  body('name').optional().isLength({ min: 2, max: 255 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { staffId } = req.params;
    const { staff_role, permissions, is_active, name } = req.body;

    // Verify staff member belongs to current dealer
    const staffCheck = await query(
      'SELECT id FROM dealership_staff WHERE id = $1 AND dealer_id = $2',
      [staffId, req.user.dealer_id]
    );

    if (staffCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    // Start transaction
    await query('BEGIN');

    try {
      // Update staff member
      const updateFields = [];
      const updateValues = [];
      let paramCount = 1;

      if (staff_role !== undefined) {
        updateFields.push(`staff_role = $${paramCount++}`);
        updateValues.push(staff_role);
      }

      if (permissions !== undefined) {
        updateFields.push(`permissions = $${paramCount++}`);
        updateValues.push(permissions);
      }

      if (is_active !== undefined) {
        updateFields.push(`is_active = $${paramCount++}`);
        updateValues.push(is_active);
      }

      updateFields.push(`updated_at = NOW()`);
      updateValues.push(staffId);

      const result = await query(
        `UPDATE dealership_staff 
         SET ${updateFields.join(', ')} 
         WHERE id = $${paramCount} AND dealer_id = $${paramCount + 1}
         RETURNING *`,
        [...updateValues, req.user.dealer_id]
      );

      if (result.rows.length === 0) {
        await query('ROLLBACK');
        return res.status(404).json({ error: 'Staff member not found' });
      }

      // Update user name if provided
      if (name !== undefined) {
        await query(
          'UPDATE users SET name = $1 WHERE id = $2',
          [name, result.rows[0].user_id]
        );
      }

      // Update permissions if staff role changed
      if (staff_role !== undefined) {
        // Clear existing permissions
        await query(
          'DELETE FROM staff_permissions WHERE staff_id = $1',
          [staffId]
        );

        // Insert new default permissions
        const defaultPermissions = getDefaultPermissions(staff_role);
        for (const permission of defaultPermissions) {
          await query(
            'INSERT INTO staff_permissions (staff_id, permission_name, permission_value) VALUES ($1, $2, $3)',
            [staffId, permission, true]
          );
        }
      }

      await query('COMMIT');

      res.json({
        message: 'Staff member updated successfully',
        staff: result.rows[0]
      });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error updating staff member:', error);
    res.status(500).json({ error: 'Failed to update staff member' });
  }
});

// Delete staff member
router.delete('/:staffId', async (req, res) => {
  try {
    const { staffId } = req.params;

    // Verify staff member belongs to current dealer
    const staffCheck = await query(
      'SELECT id FROM dealership_staff WHERE id = $1 AND dealer_id = $2',
      [staffId, req.user.dealer_id]
    );

    if (staffCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    // Delete staff member (this will cascade to user_roles and users)
    await query('DELETE FROM dealership_staff WHERE id = $1', [staffId]);

    res.json({ message: 'Staff member deleted successfully' });
  } catch (error) {
    console.error('Error deleting staff member:', error);
    res.status(500).json({ error: 'Failed to delete staff member' });
  }
});

// Get staff permissions
router.get('/:staffId/permissions', async (req, res) => {
  try {
    const { staffId } = req.params;

    // Verify staff member belongs to current dealer
    const staffCheck = await query(
      'SELECT id FROM dealership_staff WHERE id = $1 AND dealer_id = $2',
      [staffId, req.user.dealer_id]
    );

    if (staffCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    const result = await query(
      'SELECT permission_name, permission_value FROM staff_permissions WHERE staff_id = $1',
      [staffId]
    );

    res.json({ permissions: result.rows });
  } catch (error) {
    console.error('Error fetching staff permissions:', error);
    res.status(500).json({ error: 'Failed to fetch staff permissions' });
  }
});

// Update staff permissions
router.put('/:staffId/permissions', [
  body('permissions').isArray(),
  body('permissions.*.permission_name').isString(),
  body('permissions.*.permission_value').isBoolean()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { staffId } = req.params;
    const { permissions } = req.body;

    // Verify staff member belongs to current dealer
    const staffCheck = await query(
      'SELECT id FROM dealership_staff WHERE id = $1 AND dealer_id = $2',
      [staffId, req.user.dealer_id]
    );

    if (staffCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    // Start transaction
    await query('BEGIN');

    try {
      // Clear existing permissions
      await query(
        'DELETE FROM staff_permissions WHERE staff_id = $1',
        [staffId]
      );

      // Insert new permissions
      for (const permission of permissions) {
        await query(
          'INSERT INTO staff_permissions (staff_id, permission_name, permission_value) VALUES ($1, $2, $3)',
          [staffId, permission.permission_name, permission.permission_value]
        );
      }

      await query('COMMIT');

      res.json({ message: 'Staff permissions updated successfully' });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error updating staff permissions:', error);
    res.status(500).json({ error: 'Failed to update staff permissions' });
  }
});

// Helper function to get default permissions for each role
function getDefaultPermissions(staffRole) {
  const rolePermissions = {
    'admin': [
      'qr_code_generation',
      'lead_management',
      'vehicle_import',
      'analytics_dashboard',
      'bulk_actions',
      'staff_management',
      'user_management',
      'custom_branding',
      'api_access',
      'priority_support'
    ],
    'sales': [
      'qr_code_generation',
      'lead_management',
      'vehicle_import'
    ],
    'finance': [
      'lead_management',
      'analytics_dashboard'
    ],
    'service': [
      'lead_management'
    ],
    'inventory': [
      'vehicle_import',
      'qr_code_generation'
    ]
  };

  return rolePermissions[staffRole] || [];
}

export default router;
