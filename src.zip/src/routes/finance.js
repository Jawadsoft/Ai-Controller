/**
 * Finance API Routes
 * Handles all finance and lease-related endpoints
 * Includes credit applications, finance terms, and deal generation
 */

import express from 'express';
import { body, validationResult, query as queryValidator } from 'express-validator';
import { query } from '../database/connection.js';
import financeService from '../lib/financeService.js';
import financeNotificationService from '../lib/financeNotificationService.js';
import protectionProductsService from '../lib/protectionProductsService.js';

const router = express.Router();

// Note: Authentication and tenant context are handled at server.js level
// All routes below are already protected by authenticateToken and attachTenantContext

// =====================================================
// CREDIT APPLICATIONS ENDPOINTS
// =====================================================

/**
 * POST /api/finance/credit-application
 * Create a new credit application
 */
router.post('/credit-application', [
  body('customer_name').notEmpty().trim().isLength({ min: 2, max: 100 }),
  body('customer_email').isEmail().normalizeEmail(),
  body('customer_phone')
    .optional()
    .trim()
    .custom((value) => {
      if (!value) return true; // Allow empty
      // Remove all non-digit characters
      const cleaned = value.replace(/\D/g, '');
      // Must be 10 digits (or 11 with country code starting with 1)
      if (cleaned.length === 10 || (cleaned.length === 11 && cleaned[0] === '1')) {
        return true;
      }
      throw new Error('Phone number must be 10 digits (US format)');
    }),
  body('ssn').optional().matches(/^\d{3}-\d{2}-\d{4}$/).withMessage('SSN must be in format XXX-XX-XXXX'),
  body('dl_number').optional().trim().isLength({ min: 5, max: 20 }),
  body('conversation_id').optional().isUUID(),
  body('credit_score').optional().isInt({ min: 300, max: 850 }),
  body('preferred_lender_id').optional().isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const { 
      customer_name, 
      customer_email, 
      customer_phone, 
      ssn, 
      dl_number, 
      conversation_id,
      credit_score,
      preferred_lender_id
    } = req.body;

    // Encrypt sensitive data if provided
    const ssnEncrypted = ssn ? financeService.encrypt(ssn) : null;
    const dlEncrypted = dl_number ? financeService.encrypt(dl_number) : null;

    const insertQuery = `
      INSERT INTO credit_applications (
        dealer_id, conversation_id, customer_name, customer_email, customer_phone,
        ssn_encrypted, dl_number_encrypted, credit_score, preferred_lender_id, application_status
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending')
      RETURNING id, dealer_id, conversation_id, customer_name, customer_email, 
                customer_phone, application_status, credit_score, preferred_lender_id, created_at
    `;

    const result = await query(insertQuery, [
      dealerId,
      conversation_id || null,
      customer_name,
      customer_email,
      customer_phone || null,
      ssnEncrypted,
      dlEncrypted,
      credit_score || null,
      preferred_lender_id || null
    ]);

    const application = result.rows[0];

    // Send notification to customer and dealer
    try {
      await financeNotificationService.notifyCreditApplicationReceived(application, dealerId);
      console.log('✅ Credit application notification sent');
    } catch (notifError) {
      console.error('⚠️ Error sending credit application notification:', notifError);
      // Don't fail the request if notification fails
    }

    res.status(201).json({
      success: true,
      data: application
    });
  } catch (error) {
    console.error('Error creating credit application:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to create credit application',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/credit-applications
 * List all credit applications for the dealer
 */
router.get('/credit-applications', [
  queryValidator('status').optional().isIn(['pending', 'approved', 'rejected', 'reviewing']),
  queryValidator('page').optional().isInt({ min: 1 }),
  queryValidator('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;
    const status = req.query.status;

    let whereConditions = ['ca.dealer_id = $1'];
    let params = [dealerId];
    let paramIndex = 2;

    if (status) {
      whereConditions.push(`ca.application_status = $${paramIndex}`);
      params.push(status);
      paramIndex++;
    }

    const countQuery = `SELECT COUNT(*) FROM credit_applications ca WHERE ${whereConditions.join(' AND ')}`;
    const countResult = await query(countQuery, params);
    const total = parseInt(countResult.rows[0].count);

    const listQuery = `
      SELECT 
        ca.id, ca.dealer_id, ca.conversation_id, ca.customer_name, ca.customer_email, 
        ca.customer_phone, ca.application_status, ca.credit_score, ca.submitted_at,
        ca.reviewed_at, ca.reviewed_by, ca.notes, ca.created_at,
        ca.preferred_lender_id, ca.approved_lender_id, ca.lender_approval_date,
        pl.lender_name as preferred_lender_name,
        al.lender_name as approved_lender_name
      FROM credit_applications ca
      LEFT JOIN lenders pl ON ca.preferred_lender_id = pl.id
      LEFT JOIN lenders al ON ca.approved_lender_id = al.id
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY ca.created_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;

    params.push(limit, offset);
    const result = await query(listQuery, params);

    res.json({
      success: true,
      data: result.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error listing credit applications:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to list credit applications',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/credit-applications/:id
 * Get single credit application (masked sensitive data)
 */
router.get('/credit-applications/:id', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const result = await query(`
      SELECT 
        id, dealer_id, conversation_id, customer_name, customer_email, 
        customer_phone, application_status, credit_score, submitted_at,
        reviewed_at, reviewed_by, notes, created_at,
        -- Mask encrypted fields (only show last 4 digits if decrypted)
        CASE 
          WHEN ssn_encrypted IS NOT NULL THEN '***-**-****'
          ELSE NULL
        END as ssn_masked,
        CASE 
          WHEN dl_number_encrypted IS NOT NULL THEN '*******'
          ELSE NULL
        END as dl_masked
      FROM credit_applications
      WHERE id = $1 AND dealer_id = $2
    `, [id, dealerId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Credit application not found' 
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Error getting credit application:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to get credit application',
      message: error.message 
    });
  }
});

/**
 * PUT /api/finance/credit-applications/:id
 * Update credit application information
 */
router.put('/credit-applications/:id', [
  body('customer_name').optional({ nullable: true, checkFalsy: true }).trim().isLength({ min: 2, max: 100 }),
  body('customer_email').optional({ nullable: true, checkFalsy: true }).isEmail(),
  body('customer_phone')
    .optional({ nullable: true, checkFalsy: true })
    .trim()
    .custom((value) => {
      if (!value) return true; // Allow empty
      // Remove all non-digit characters
      const cleaned = value.replace(/\D/g, '');
      // Must be 10 digits (or 11 with country code starting with 1)
      if (cleaned.length === 10 || (cleaned.length === 11 && cleaned[0] === '1')) {
        return true;
      }
      throw new Error('Phone number must be 10 digits (US format)');
    }),
  body('credit_score').optional({ nullable: true, checkFalsy: true }).isInt({ min: 300, max: 850 }),
  body('preferred_lender_id').optional({ nullable: true, checkFalsy: true }).isUUID(),
  body('notes').optional({ nullable: true, checkFalsy: true }).trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify application belongs to dealer
    const checkQuery = 'SELECT id FROM credit_applications WHERE id = $1 AND dealer_id = $2';
    const checkResult = await query(checkQuery, [id, dealerId]);
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Application not found or access denied' 
      });
    }

    const allowedFields = ['customer_name', 'customer_email', 'customer_phone', 'credit_score', 'preferred_lender_id', 'notes'];
    const updates = [];
    const values = [];
    let paramIndex = 1;

    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates.push(`${field} = $${paramIndex}`);
        // Convert empty strings to null for optional fields
        values.push(req.body[field] === '' ? null : req.body[field]);
        paramIndex++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ 
        success: false,
        error: 'No fields to update' 
      });
    }

    updates.push('updated_at = NOW()');
    values.push(id);

    const updateQuery = `
      UPDATE credit_applications
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING id, dealer_id, conversation_id, customer_name, customer_email, 
                customer_phone, application_status, credit_score, preferred_lender_id, notes, 
                submitted_at, reviewed_at, reviewed_by, created_at, updated_at
    `;

    const result = await query(updateQuery, values);

    res.json({
      success: true,
      data: result.rows[0],
      message: 'Application updated successfully'
    });
  } catch (error) {
    console.error('Error updating credit application:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to update credit application',
      message: error.message 
    });
  }
});

/**
 * PUT /api/finance/credit-applications/:id/status
 * Update credit application status
 */
router.put('/credit-applications/:id/status', [
  body('status').isIn(['pending', 'approved', 'rejected', 'reviewing']).withMessage('Invalid application status.')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      success: false,
      errors: errors.array() 
    });
  }

  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;
    const { status } = req.body;
    const userId = req.user.id;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify application belongs to dealer
    const checkResult = await query(`
      SELECT id FROM credit_applications WHERE id = $1 AND dealer_id = $2
    `, [id, dealerId]);

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Credit application not found' 
      });
    }

    // Update status
    const result = await query(`
      UPDATE credit_applications
      SET 
        application_status = $3,
        reviewed_at = NOW(),
        reviewed_by = $4,
        updated_at = NOW()
      WHERE id = $1 AND dealer_id = $2
      RETURNING 
        id, customer_name, customer_email, customer_phone, application_status, 
        credit_score, reviewed_at, reviewed_by, updated_at
    `, [id, dealerId, status, userId]);

    const application = result.rows[0];

    // Send status-specific notifications
    try {
      if (status === 'approved') {
        await financeNotificationService.notifyCreditApplicationApproved(
          application,
          dealerId,
          { approved_amount: 50000, apr: 4.9 } // You can calculate actual values
        );
        console.log('✅ Credit application approved notification sent');
      } else if (status === 'rejected') {
        await financeNotificationService.notifyCreditApplicationDeclined(
          application,
          dealerId,
          'We were unable to approve your application at this time.'
        );
        console.log('✅ Credit application declined notification sent');
      }
    } catch (notifError) {
      console.error('⚠️ Error sending status notification:', notifError);
      // Don't fail the request if notification fails
    }

    res.json({
      success: true,
      data: application,
      message: `Application status updated to ${status}`
    });
  } catch (error) {
    console.error('Error updating credit application status:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to update application status',
      message: error.message 
    });
  }
});

/**
 * DELETE /api/finance/credit-applications/:id
 * Delete a credit application
 */
router.delete('/credit-applications/:id', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify application belongs to dealer
    const checkResult = await query(
      'SELECT id FROM credit_applications WHERE id = $1 AND dealer_id = $2',
      [id, dealerId]
    );

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Credit application not found or access denied' 
      });
    }

    // Delete the application
    await query('DELETE FROM credit_applications WHERE id = $1', [id]);

    res.json({
      success: true,
      message: 'Credit application deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting credit application:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to delete credit application',
      message: error.message 
    });
  }
});

// =====================================================
// FINANCE TERMS ENDPOINTS
// =====================================================

/**
 * GET /api/finance/terms
 * Get finance/lease terms by credit score
 */
router.get('/terms', [
  queryValidator('type').isIn(['finance', 'lease']).withMessage('Type must be finance or lease'),
  queryValidator('term_months').isInt({ min: 12, max: 84 }).withMessage('Term months must be between 12 and 84'),
  queryValidator('credit_score').isInt({ min: 300, max: 850 }).withMessage('Credit score must be between 300 and 850')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    const { type, term_months, credit_score } = req.query;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const term = await financeService.getTermsByCreditScore(
      dealerId,
      type,
      parseInt(term_months),
      parseInt(credit_score)
    );

    if (!term) {
      return res.status(404).json({ 
        success: false,
        error: `No ${type} program found for credit score ${credit_score} and ${term_months} month term` 
      });
    }

    // Get credit tier info
    const tierInfo = financeService.getCreditTier(parseInt(credit_score));

    res.json({
      success: true,
      data: {
        ...term,
        credit_tier: tierInfo
      }
    });
  } catch (error) {
    console.error('Error getting finance terms:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to get finance terms',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/programs
 * List all finance programs for the dealer (with pagination)
 */
router.get('/programs', [
  queryValidator('type').optional().isIn(['finance', 'lease']),
  queryValidator('is_active').optional().isBoolean(),
  queryValidator('page').optional().isInt({ min: 1 }),
  queryValidator('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;
    const offset = (page - 1) * limit;
    const type = req.query.type;
    const isActive = req.query.is_active;

    let whereConditions = ['(dealer_id = $1 OR dealer_id IS NULL)'];
    let params = [dealerId];
    let paramIndex = 2;

    if (type) {
      whereConditions.push(`type = $${paramIndex}`);
      params.push(type);
      paramIndex++;
    }

    if (isActive !== undefined) {
      whereConditions.push(`is_active = $${paramIndex}`);
      params.push(isActive === 'true');
      paramIndex++;
    }

    const countQuery = `SELECT COUNT(*) FROM finance_terms_master WHERE ${whereConditions.join(' AND ')}`;
    const countResult = await query(countQuery, params);
    const total = parseInt(countResult.rows[0].count);

    const listQuery = `
      SELECT *,
        CASE WHEN dealer_id IS NULL THEN 'global' ELSE 'dealer' END as program_scope
      FROM finance_terms_master
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY 
        CASE WHEN dealer_id IS NULL THEN 1 ELSE 0 END,
        type, term_months, tier_min_score
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;

    params.push(limit, offset);
    const result = await query(listQuery, params);

    res.json({
      success: true,
      data: result.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error listing finance programs:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to list finance programs',
      message: error.message 
    });
  }
});

/**
 * POST /api/finance/programs
 * Create a new finance program (Admin/Staff only)
 */
router.post('/programs', [
  body('program_name').notEmpty().trim().isLength({ min: 3, max: 200 }),
  body('type').isIn(['finance', 'lease']),
  body('term_months').isInt({ min: 12, max: 84 }),
  body('tier_min_score').isInt({ min: 300, max: 850 }),
  body('tier_max_score').isInt({ min: 300, max: 850 }),
  body('interest_rate').optional().isFloat({ min: 0, max: 100 }),
  body('money_factor').optional().isFloat({ min: 0 }),
  body('residual_value_pct').optional().isFloat({ min: 0, max: 100 }),
  body('down_payment_min').optional().isFloat({ min: 0 }),
  body('program_source').optional().isIn(['OEM', 'Bank', 'CreditUnion', 'InHouse']),
  body('effective_date').optional().isISO8601(),
  body('expiry_date').optional().isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Check permissions (staff_management or dealer admin)
    const user = req.user;
    if (user.role !== 'super_admin' && user.staff_role !== 'admin' && !user.staff_permissions?.includes('staff_management')) {
      return res.status(403).json({ 
        success: false,
        error: 'Insufficient permissions to create finance programs' 
      });
    }

    const { 
      program_name, 
      type, 
      term_months, 
      tier_min_score, 
      tier_max_score,
      interest_rate,
      money_factor,
      residual_value_pct,
      down_payment_min,
      program_source,
      effective_date,
      expiry_date
    } = req.body;

    // Validate tier range
    if (tier_min_score > tier_max_score) {
      return res.status(400).json({ 
        success: false,
        error: 'tier_min_score must be less than or equal to tier_max_score' 
      });
    }

    // Validate type-specific fields
    if (type === 'finance' && !interest_rate) {
      return res.status(400).json({ 
        success: false,
        error: 'interest_rate is required for finance programs' 
      });
    }

    if (type === 'lease' && (!money_factor || !residual_value_pct)) {
      return res.status(400).json({ 
        success: false,
        error: 'money_factor and residual_value_pct are required for lease programs' 
      });
    }

    const insertQuery = `
      INSERT INTO finance_terms_master (
        dealer_id, program_name, type, term_months, tier_min_score, tier_max_score,
        interest_rate, money_factor, residual_value_pct, down_payment_min,
        program_source, effective_date, expiry_date, is_active
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, TRUE)
      RETURNING *
    `;

    const result = await query(insertQuery, [
      dealerId, // Dealer-specific program
      program_name,
      type,
      term_months,
      tier_min_score,
      tier_max_score,
      interest_rate || null,
      money_factor || null,
      residual_value_pct || null,
      down_payment_min || 0,
      program_source || 'Bank',
      effective_date || new Date().toISOString().split('T')[0],
      expiry_date || null
    ]);

    // Clear cache for this dealer
    financeService.clearCache(dealerId);

    res.status(201).json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Error creating finance program:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to create finance program',
      message: error.message 
    });
  }
});

/**
 * PUT /api/finance/programs/:id
 * Update finance program
 */
router.put('/programs/:id', [
  body('program_name').optional().trim().isLength({ min: 3, max: 200 }),
  body('tier_min_score').optional().isInt({ min: 300, max: 850 }),
  body('tier_max_score').optional().isInt({ min: 300, max: 850 }),
  body('interest_rate').optional().isFloat({ min: 0, max: 100 }),
  body('money_factor').optional().isFloat({ min: 0 }),
  body('residual_value_pct').optional().isFloat({ min: 0, max: 100 }),
  body('is_active').optional().isBoolean(),
  body('expiry_date').optional().isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify program belongs to dealer
    const checkQuery = await query('SELECT dealer_id FROM finance_terms_master WHERE id = $1', [id]);
    
    if (checkQuery.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Finance program not found' 
      });
    }

    if (checkQuery.rows[0].dealer_id !== dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Cannot update program that belongs to another dealer' 
      });
    }

    // Build update query dynamically
    const allowedFields = [
      'program_name', 'tier_min_score', 'tier_max_score', 
      'interest_rate', 'money_factor', 'residual_value_pct',
      'down_payment_min', 'is_active', 'expiry_date'
    ];

    const updates = [];
    const values = [];
    let paramIndex = 1;

    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates.push(`${field} = $${paramIndex}`);
        values.push(req.body[field]);
        paramIndex++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ 
        success: false,
        error: 'No valid fields to update' 
      });
    }

    updates.push(`updated_at = NOW()`);
    values.push(id);

    const updateQuery = `
      UPDATE finance_terms_master
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING *
    `;

    const result = await query(updateQuery, values);

    // Clear cache for this dealer
    financeService.clearCache(dealerId);

    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Error updating finance program:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to update finance program',
      message: error.message 
    });
  }
});

/**
 * DELETE /api/finance/programs/:id
 * Deactivate finance program (soft delete)
 */
router.delete('/programs/:id', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify program belongs to dealer
    const checkQuery = await query('SELECT dealer_id FROM finance_terms_master WHERE id = $1', [id]);
    
    if (checkQuery.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Finance program not found' 
      });
    }

    if (checkQuery.rows[0].dealer_id !== dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Cannot delete program that belongs to another dealer' 
      });
    }

    // Soft delete (set is_active = FALSE)
    const result = await query(`
      UPDATE finance_terms_master
      SET is_active = FALSE, updated_at = NOW()
      WHERE id = $1
      RETURNING *
    `, [id]);

    // Clear cache for this dealer
    financeService.clearCache(dealerId);

    res.json({
      success: true,
      data: result.rows[0],
      message: 'Finance program deactivated successfully'
    });
  } catch (error) {
    console.error('Error deactivating finance program:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to deactivate finance program',
      message: error.message 
    });
  }
});

// =====================================================
// FINANCE DEALS ENDPOINTS
// =====================================================

/**
 * POST /api/finance/deal
 * Generate a finance deal
 */
router.post('/deal', [
  body('vehicle_id').isUUID(),
  body('price').isFloat({ min: 0 }),
  body('down_payment').optional().isFloat({ min: 0 }),
  body('credit_score').isInt({ min: 300, max: 850 }),
  body('term_months').isInt({ min: 12, max: 84 }),
  body('conversation_id').optional().isUUID(),
  body('application_id').optional().isUUID(),
  // Government fees (TTL)
  body('sales_tax_rate').optional().isFloat({ min: 0, max: 1 }),
  body('title_fee').optional().isFloat({ min: 0 }),
  body('license_fee').optional().isFloat({ min: 0 }),
  body('registration_fee').optional().isFloat({ min: 0 }),
  body('inspection_fee').optional().isFloat({ min: 0 }),
  body('processing_fee').optional().isFloat({ min: 0 }),
  // Trade-in
  body('trade_in_acv').optional().isFloat({ min: 0 }),
  body('trade_in_payoff').optional().isFloat({ min: 0 }),
  // Other
  body('add_ons').optional().isFloat({ min: 0 }),
  body('protection_products').optional().isFloat({ min: 0 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const { 
      vehicle_id, 
      price, 
      down_payment, 
      credit_score, 
      term_months, 
      conversation_id, 
      application_id,
      sales_tax_rate,
      title_fee,
      license_fee,
      registration_fee,
      inspection_fee,
      processing_fee,
      trade_in_acv,
      trade_in_payoff,
      add_ons,
      protection_products
    } = req.body;

    // Verify vehicle exists and belongs to dealer
    const vehicleCheck = await query('SELECT id, price FROM vehicles WHERE id = $1 AND dealer_id = $2', [vehicle_id, dealerId]);
    
    if (vehicleCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Vehicle not found or does not belong to dealer' 
      });
    }

    // Use vehicle price from DB if price not provided
    const finalPrice = price || vehicleCheck.rows[0].price;
    if (!finalPrice) {
      return res.status(400).json({ 
        success: false,
        error: 'Vehicle price is required' 
      });
    }

    // Generate deal with all new fields
    const deal = await financeService.generateFinanceDeal({
      dealerId,
      vehicleId: vehicle_id,
      price: finalPrice,
      downPayment: down_payment || 0,
      creditScore: credit_score,
      termMonths: term_months,
      conversationId: conversation_id,
      applicationId: application_id,
      governmentFees: {
        salesTaxRate: sales_tax_rate || 0,
        titleFee: title_fee || 0,
        licenseFee: license_fee || 0,
        registrationFee: registration_fee || 0,
        inspectionFee: inspection_fee || 0,
        processingFee: processing_fee || 0
      },
      tradeIn: {
        acv: trade_in_acv,
        payoff: trade_in_payoff || 0
      },
      addOns: add_ons || 0,
      protectionProducts: protection_products || 0
    });

    // Send deal created notification
    try {
      if (application_id) {
        // Get application and vehicle details for notification
        const appResult = await query(
          'SELECT customer_name, customer_email, customer_phone FROM credit_applications WHERE id = $1',
          [application_id]
        );
        const vehicleResult = await query(
          'SELECT year, make, model FROM vehicles WHERE id = $1',
          [vehicle_id]
        );
        
        if (appResult.rows.length > 0 && vehicleResult.rows.length > 0) {
          await financeNotificationService.notifyFinanceDealCreated(
            deal,
            appResult.rows[0],
            vehicleResult.rows[0],
            dealerId
          );
          console.log('✅ Finance deal created notification sent');
        }
      }
    } catch (notifError) {
      console.error('⚠️ Error sending deal notification:', notifError);
      // Don't fail the request if notification fails
    }

    res.status(201).json({
      success: true,
      data: deal
    });
  } catch (error) {
    console.error('Error generating finance deal:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to generate finance deal',
      message: error.message 
    });
  }
});

/**
 * POST /api/finance/lease
 * Generate a lease deal
 */
router.post('/lease', [
  body('vehicle_id').isUUID(),
  body('cap_cost').isFloat({ min: 0 }),
  body('credit_score').isInt({ min: 300, max: 850 }),
  body('term_months').isInt({ min: 12, max: 48 }),
  body('conversation_id').optional().isUUID(),
  body('application_id').optional().isUUID(),
  body('residual_pct').optional().isFloat({ min: 0, max: 100 }),
  body('money_factor').optional().isFloat({ min: 0 }),
  body('msrp').optional().isFloat({ min: 0 }),
  body('cap_cost_reductions').optional().isFloat({ min: 0 }),
  body('capitalized_fees').optional().isFloat({ min: 0 }),
  body('tax_rate').optional().isFloat({ min: 0, max: 1 }),
  body('annual_mileage').optional().isInt({ min: 0 }),
  body('excess_mileage_rate').optional().isFloat({ min: 0 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const { 
      vehicle_id, 
      cap_cost, 
      credit_score, 
      term_months, 
      conversation_id, 
      application_id, 
      residual_pct, 
      money_factor,
      msrp,
      cap_cost_reductions,
      capitalized_fees,
      tax_rate,
      annual_mileage,
      excess_mileage_rate
    } = req.body;

    // Verify vehicle exists and belongs to dealer
    const vehicleCheck = await query('SELECT id FROM vehicles WHERE id = $1 AND dealer_id = $2', [vehicle_id, dealerId]);
    
    if (vehicleCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Vehicle not found or does not belong to dealer' 
      });
    }

    // Generate lease deal with all new fields
    const deal = await financeService.generateLeaseDeal({
      dealerId,
      vehicleId: vehicle_id,
      capCost: cap_cost,
      creditScore: credit_score,
      termMonths: term_months,
      residualPct: residual_pct,
      moneyFactor: money_factor,
      msrp: msrp,
      capCostReductions: cap_cost_reductions || 0,
      capitalizedFees: capitalized_fees || 0,
      taxRate: tax_rate || 0,
      annualMileage: annual_mileage,
      excessMileageRate: excess_mileage_rate || 0.25,
      conversationId: conversation_id,
      applicationId: application_id
    });

    // Send lease deal created notification
    try {
      if (application_id) {
        // Get application and vehicle details for notification
        const appResult = await query(
          'SELECT customer_name, customer_email, customer_phone FROM credit_applications WHERE id = $1',
          [application_id]
        );
        const vehicleResult = await query(
          'SELECT year, make, model FROM vehicles WHERE id = $1',
          [vehicle_id]
        );
        
        if (appResult.rows.length > 0 && vehicleResult.rows.length > 0) {
          await financeNotificationService.notifyFinanceDealCreated(
            deal,
            appResult.rows[0],
            vehicleResult.rows[0],
            dealerId
          );
          console.log('✅ Lease deal created notification sent');
        }
      }
    } catch (notifError) {
      console.error('⚠️ Error sending lease notification:', notifError);
      // Don't fail the request if notification fails
    }

    res.status(201).json({
      success: true,
      data: deal
    });
  } catch (error) {
    console.error('Error generating lease deal:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to generate lease deal',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/deals
 * List all deals for the dealer
 */
router.get('/deals', [
  queryValidator('status').optional().isIn(['draft', 'pending', 'approved', 'rejected', 'signed', 'completed', 'cancelled']),
  queryValidator('deal_type').optional().isIn(['finance', 'lease']),
  queryValidator('conversation_id').optional().isUUID(),
  queryValidator('page').optional().isInt({ min: 1 }),
  queryValidator('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;
    const status = req.query.status;
    const dealType = req.query.deal_type;
    const conversationId = req.query.conversation_id;

    let whereConditions = ['fd.dealer_id = $1'];
    let params = [dealerId];
    let paramIndex = 2;

    if (status) {
      whereConditions.push(`fd.status = $${paramIndex}`);
      params.push(status);
      paramIndex++;
    }

    if (dealType) {
      whereConditions.push(`fd.deal_type = $${paramIndex}`);
      params.push(dealType);
      paramIndex++;
    }

    if (conversationId) {
      whereConditions.push(`fd.conversation_id = $${paramIndex}`);
      params.push(conversationId);
      paramIndex++;
    }

    const countQuery = `SELECT COUNT(*) FROM finance_deals fd WHERE ${whereConditions.join(' AND ')}`;
    const countResult = await query(countQuery, params);
    const total = parseInt(countResult.rows[0].count);

    const listQuery = `
      SELECT 
        fd.*,
        v.make, v.model, v.year, v.vin,
        ftm.program_name, ftm.program_source,
        ca.customer_name, ca.customer_email, ca.customer_phone,
        gds.id as latest_deal_sheet_id, gds.pdf_url, gds.pdf_filename,
        sr.id as signature_request_id, sr.status as signature_status
      FROM finance_deals fd
      LEFT JOIN vehicles v ON fd.vehicle_id = v.id
      LEFT JOIN finance_terms_master ftm ON fd.term_id = ftm.id
      LEFT JOIN credit_applications ca ON fd.application_id = ca.id
      LEFT JOIN LATERAL (
        SELECT id, pdf_url, pdf_filename
        FROM generated_deal_sheets
        WHERE deal_id = fd.id
        ORDER BY created_at DESC
        LIMIT 1
      ) gds ON true
      LEFT JOIN LATERAL (
        SELECT id, status
        FROM signature_requests
        WHERE deal_id = fd.id
        ORDER BY created_at DESC
        LIMIT 1
      ) sr ON true
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY fd.created_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;

    params.push(limit, offset);
    const result = await query(listQuery, params);

    res.json({
      success: true,
      data: result.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error listing deals:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to list deals',
      message: error.message 
    });
  }
});

/**
 * POST /api/finance/deals/:id/update-status
 * Update deal status (for testing/workflow progression)
 * IMPORTANT: Must come BEFORE GET /deals/:id or Express will match that route first
 */
router.post('/deals/:id/update-status', [
  body('status').isIn(['draft', 'pending', 'approved', 'rejected', 'signed', 'completed', 'cancelled'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    const { id } = req.params;
    const { status } = req.body;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const checkQuery = 'SELECT id, status FROM finance_deals WHERE id = $1 AND dealer_id = $2';
    const checkResult = await query(checkQuery, [id, dealerId]);
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    const oldStatus = checkResult.rows[0].status;

    // Update status
    const updateQuery = `
      UPDATE finance_deals 
      SET status = $1, updated_at = NOW() 
      WHERE id = $2 AND dealer_id = $3
      RETURNING *
    `;
    
    const result = await query(updateQuery, [status, id, dealerId]);

    res.json({
      success: true,
      data: result.rows[0],
      message: `Deal status updated from ${oldStatus} to ${status}`
    });
  } catch (error) {
    console.error('Error updating deal status:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to update deal status',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/deals/:id
 * Get single deal details
 * NOTE: Specific routes like /deals/:id/update-status must come BEFORE this
 */
router.get('/deals/:id', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    const result = await query(`
      SELECT 
        fd.*,
        v.make, v.model, v.year, v.vin, v.price as vehicle_current_price,
        ftm.program_name, ftm.program_source,
        ca.customer_name, ca.customer_email, ca.customer_phone
      FROM finance_deals fd
      LEFT JOIN vehicles v ON fd.vehicle_id = v.id
      LEFT JOIN finance_terms_master ftm ON fd.term_id = ftm.id
      LEFT JOIN credit_applications ca ON fd.application_id = ca.id
      WHERE fd.id = $1 AND fd.dealer_id = $2
    `, [id, dealerId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found' 
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Error getting deal:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to get deal',
      message: error.message 
    });
  }
});

// =====================================================
// DEAL SHEET / PDF GENERATION ENDPOINTS
// =====================================================

import pdfGenerator from '../lib/pdfGenerator.js';

/**
 * POST /api/finance/deals/:id/generate-sheet
 * Generate PDF deal sheet for a deal
 */
router.post('/deals/:id/generate-sheet', async (req, res) => {
  console.log('\n🔵 ===== PDF GENERATION REQUEST START =====');
  console.log('📍 Endpoint: POST /api/finance/deals/:id/generate-sheet');
  console.log('⏰ Timestamp:', new Date().toISOString());
  console.log('📋 Request Details:', {
    params: req.params,
    body: req.body,
    headers: {
      authorization: req.headers.authorization ? 'Bearer [PRESENT]' : 'MISSING',
      'content-type': req.headers['content-type']
    }
  });
  
  try {
    // Check if user is authenticated
    console.log('👤 User authentication check...');
    if (!req.user) {
      console.log('❌ No user object found - authentication failed');
      return res.status(401).json({ 
        success: false,
        error: 'Authentication required' 
      });
    }
    console.log('✅ User authenticated:', { userId: req.user.id, email: req.user.email });

    const dealerId = req.user.dealer_id;
    const { id } = req.params;
    const { template_id } = req.body;

    console.log('🏢 Dealer ID:', dealerId);
    console.log('📄 Deal ID:', id);
    console.log('🎨 Template ID:', template_id || 'default');

    if (!dealerId) {
      console.log('❌ No dealer_id found in user object');
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    console.log('🔍 Verifying deal ownership...');
    const dealCheck = await query('SELECT id FROM finance_deals WHERE id = $1 AND dealer_id = $2', [id, dealerId]);
    console.log('📊 Deal check result:', { found: dealCheck.rows.length > 0, rowCount: dealCheck.rows.length });
    
    if (dealCheck.rows.length === 0) {
      console.log('❌ Deal not found or access denied');
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }
    console.log('✅ Deal ownership verified');

    // Generate deal sheet
    console.log('🎨 Starting PDF generation...');
    const startTime = Date.now();
    const dealSheet = await pdfGenerator.generateDealSheet({
      dealId: id,
      templateId: template_id || null,
      userId: req.user.id,
      dealerId
    });
    const duration = Date.now() - startTime;
    console.log(`✅ PDF generated successfully in ${duration}ms`);
    console.log('📄 Deal sheet details:', {
      id: dealSheet.id,
      filename: dealSheet.pdf_filename,
      url: dealSheet.pdf_url,
      size: dealSheet.pdf_size_bytes
    });

    console.log('🔵 ===== PDF GENERATION REQUEST END (SUCCESS) =====\n');
    res.status(201).json({
      success: true,
      data: dealSheet,
      message: 'Deal sheet generated successfully'
    });
  } catch (error) {
    console.error('🔴 ===== ERROR IN PDF GENERATION =====');
    console.error('❌ Error type:', error.constructor.name);
    console.error('❌ Error message:', error.message);
    console.error('❌ Error stack:', error.stack);
    console.log('🔴 ===== PDF GENERATION REQUEST END (ERROR) =====\n');
    
    res.status(500).json({ 
      success: false,
      error: 'Failed to generate deal sheet',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/deals/:id/sheets
 * Get all deal sheets for a deal
 */
router.get('/deals/:id/sheets', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const dealCheck = await query('SELECT id FROM finance_deals WHERE id = $1 AND dealer_id = $2', [id, dealerId]);
    
    if (dealCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    const sheets = await pdfGenerator.getDealSheets(id);

    res.json({
      success: true,
      data: sheets
    });
  } catch (error) {
    console.error('Error getting deal sheets:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to get deal sheets',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/deals/:id/preview-html
 * Preview HTML before PDF generation
 */
router.get('/deals/:id/preview-html', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { id } = req.params;
    const { template_id } = req.query;

    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const dealCheck = await query('SELECT id FROM finance_deals WHERE id = $1 AND dealer_id = $2', [id, dealerId]);
    
    if (dealCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    const { html } = await pdfGenerator.generateHTML(id, template_id || null);

    res.send(html);
  } catch (error) {
    console.error('Error previewing HTML:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to preview HTML',
      message: error.message 
    });
  }
});

// =====================================================
// PROTECTION PRODUCTS ENDPOINTS
// =====================================================

/**
 * POST /api/finance/deals/:dealId/products
 * Add protection product to a deal
 */
router.post('/deals/:dealId/products', [
  body('product_type').isIn(['GAP', 'VSC', 'Appearance', 'TireWheel', 'ServiceContract', 'InteriorExterior', 'Other']),
  body('product_name').notEmpty().trim(),
  body('price').isFloat({ min: 0 }),
  body('is_financed').optional().isBoolean(),
  body('provider_name').optional().trim(),
  body('dealer_profit').optional().isFloat({ min: 0 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const dealerId = req.user.dealer_id;
    const { dealId } = req.params;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const dealCheck = await query('SELECT id, term_months FROM finance_deals WHERE id = $1 AND dealer_id = $2', [dealId, dealerId]);
    
    if (dealCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    const termMonths = dealCheck.rows[0].term_months;

    const product = await protectionProductsService.addProduct({
      dealId,
      productType: req.body.product_type,
      productName: req.body.product_name,
      price: req.body.price,
      isFinanced: req.body.is_financed !== false,
      providerName: req.body.provider_name || null,
      dealerProfit: req.body.dealer_profit || 0,
      termMonths
    });

    res.status(201).json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Error adding protection product:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to add protection product',
      message: error.message 
    });
  }
});

/**
 * GET /api/finance/deals/:dealId/products
 * Get all protection products for a deal
 */
router.get('/deals/:dealId/products', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { dealId } = req.params;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const dealCheck = await query('SELECT id FROM finance_deals WHERE id = $1 AND dealer_id = $2', [dealId, dealerId]);
    
    if (dealCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    const products = await protectionProductsService.getDealProducts(dealId);

    res.json({
      success: true,
      data: products
    });
  } catch (error) {
    console.error('Error getting protection products:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to get protection products',
      message: error.message 
    });
  }
});

/**
 * DELETE /api/finance/deals/:dealId/products/:productId
 * Remove protection product from deal
 */
router.delete('/deals/:dealId/products/:productId', async (req, res) => {
  try {
    const dealerId = req.user.dealer_id;
    const { dealId, productId } = req.params;
    
    if (!dealerId) {
      return res.status(403).json({ 
        success: false,
        error: 'Dealer access required' 
      });
    }

    // Verify deal belongs to dealer
    const dealCheck = await query('SELECT id FROM finance_deals WHERE id = $1 AND dealer_id = $2', [dealId, dealerId]);
    
    if (dealCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Deal not found or access denied' 
      });
    }

    await protectionProductsService.removeProduct(productId);

    res.json({
      success: true,
      message: 'Protection product removed successfully'
    });
  } catch (error) {
    console.error('Error removing protection product:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to remove protection product',
      message: error.message 
    });
  }
});

export default router;

