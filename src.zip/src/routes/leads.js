import express from 'express';
import { body, validationResult } from 'express-validator';
import { query } from '../database/connection.js';
import { sendNewLeadNotification } from '../lib/notificationHelper.js';

const router = express.Router();

// Get all leads for the authenticated dealer
router.get('/', async (req, res) => {
  try {
    const userId = req.user.id;
    
    let sqlQuery;
    let params;
    
    if (req.user.role === 'super_admin') {
      // Super admin can see all leads
      sqlQuery = `
        SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name,
               ds_assigned.user_id as assigned_user_id, u_assigned.name as assigned_agent_name,
               u_assigned.email as assigned_agent_email
        FROM leads l 
        LEFT JOIN vehicles v ON l.vehicle_id = v.id 
        LEFT JOIN dealers d ON l.dealer_id = d.id 
        LEFT JOIN dealership_staff ds_assigned ON l.assigned_to = ds_assigned.id
        LEFT JOIN users u_assigned ON ds_assigned.user_id = u_assigned.id
        ORDER BY l.created_at DESC
      `;
      params = [];
    } else if (req.user.dealer_id) {
      // Staff can see leads by dealer_id, but sales agents only see their assigned leads
      if (req.user.staff_role === 'sales' && req.user.staff_id) {
        sqlQuery = `
          SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name,
                 ds_assigned.user_id as assigned_user_id, u_assigned.name as assigned_agent_name,
                 u_assigned.email as assigned_agent_email
          FROM leads l 
          LEFT JOIN vehicles v ON l.vehicle_id = v.id 
          LEFT JOIN dealers d ON l.dealer_id = d.id 
          LEFT JOIN dealership_staff ds_assigned ON l.assigned_to = ds_assigned.id
          LEFT JOIN users u_assigned ON ds_assigned.user_id = u_assigned.id
          WHERE l.dealer_id = $1 AND l.assigned_to = $2
          ORDER BY l.created_at DESC
        `;
        params = [req.user.dealer_id, req.user.staff_id];
      } else {
        // Admin and other staff can see all leads for their dealer
        sqlQuery = `
          SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name,
                 ds_assigned.user_id as assigned_user_id, u_assigned.name as assigned_agent_name,
                 u_assigned.email as assigned_agent_email
          FROM leads l 
          LEFT JOIN vehicles v ON l.vehicle_id = v.id 
          LEFT JOIN dealers d ON l.dealer_id = d.id 
          LEFT JOIN dealership_staff ds_assigned ON l.assigned_to = ds_assigned.id
          LEFT JOIN users u_assigned ON ds_assigned.user_id = u_assigned.id
          WHERE l.dealer_id = $1 
          ORDER BY l.created_at DESC
        `;
        params = [req.user.dealer_id];
      }
    } else {
      // Dealer owners (no staff record) can see all leads for their dealer
      sqlQuery = `
        SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name,
               ds_assigned.user_id as assigned_user_id, u_assigned.name as assigned_agent_name,
               u_assigned.email as assigned_agent_email
        FROM leads l 
        LEFT JOIN vehicles v ON l.vehicle_id = v.id 
        LEFT JOIN dealers d ON l.dealer_id = d.id 
        LEFT JOIN dealership_staff ds_assigned ON l.assigned_to = ds_assigned.id
        LEFT JOIN users u_assigned ON ds_assigned.user_id = u_assigned.id
        WHERE d.user_id = $1 
        ORDER BY l.created_at DESC
      `;
      params = [userId];
    }
    
    const result = await query(sqlQuery, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get leads error:', error);
    res.status(500).json({ error: 'Failed to fetch leads', details: error.message });
  }
});

// Get available sales agents for assignment
router.get('/sales-agents', async (req, res) => {
  try {
    const userId = req.user.id;

    // Only admin and super_admin can see sales agents
    if (req.user.role !== 'super_admin' && req.user.staff_role !== 'admin') {
      return res.status(403).json({ error: 'Only administrators can view sales agents' });
    }

    let sqlQuery;
    let params;

    if (req.user.role === 'super_admin') {
      // Super admin can see all sales agents
      sqlQuery = `
        SELECT ds.id, u.name, ds.staff_role, u.email, d.business_name as dealer_name
        FROM dealership_staff ds
        JOIN users u ON ds.user_id = u.id
        JOIN dealers d ON ds.dealer_id = d.id
        WHERE ds.staff_role = 'sales' AND ds.is_active = true
        ORDER BY d.business_name, u.name
      `;
      params = [];
    } else if (req.user.dealer_id) {
      // Admin can see sales agents for their dealer
      sqlQuery = `
        SELECT ds.id, u.name, ds.staff_role, u.email
        FROM dealership_staff ds
        JOIN users u ON ds.user_id = u.id
        WHERE ds.dealer_id = $1 AND ds.staff_role = 'sales' AND ds.is_active = true
        ORDER BY u.name
      `;
      params = [req.user.dealer_id];
    } else {
      // Dealer owner can see sales agents for their dealer
      sqlQuery = `
        SELECT ds.id, u.name, ds.staff_role, u.email
        FROM dealership_staff ds
        JOIN users u ON ds.user_id = u.id
        JOIN dealers d ON ds.dealer_id = d.id
        WHERE d.user_id = $1 AND ds.staff_role = 'sales' AND ds.is_active = true
        ORDER BY u.name
      `;
      params = [userId];
    }

    const result = await query(sqlQuery, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get sales agents error:', error);
    res.status(500).json({ error: 'Failed to fetch sales agents' });
  }
});

// Get single lead
router.get('/:id', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;
    
    let sqlQuery;
    let params;
    
    if (req.user.role === 'super_admin') {
      sqlQuery = `
        SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name
        FROM leads l 
        LEFT JOIN vehicles v ON l.vehicle_id = v.id 
        LEFT JOIN dealers d ON l.dealer_id = d.id 
        WHERE l.id = $1
      `;
      params = [leadId];
    } else if (req.user.dealer_id) {
      sqlQuery = `
        SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name
        FROM leads l 
        LEFT JOIN vehicles v ON l.vehicle_id = v.id 
        LEFT JOIN dealers d ON l.dealer_id = d.id 
        WHERE l.id = $1 AND l.dealer_id = $2
      `;
      params = [leadId, req.user.dealer_id];
    } else {
      sqlQuery = `
        SELECT l.*, v.make, v.model, v.year, v.vin, d.business_name as dealer_name
        FROM leads l 
        LEFT JOIN vehicles v ON l.vehicle_id = v.id 
        LEFT JOIN dealers d ON l.dealer_id = d.id 
        WHERE l.id = $1 AND d.user_id = $2
      `;
      params = [leadId, userId];
    }
    
    const result = await query(sqlQuery, params);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get lead error:', error);
    res.status(500).json({ error: 'Failed to fetch lead' });
  }
});

// Create new lead (public endpoint - no auth required)
router.post('/public', [
  body('vehicle_id').isUUID(),
  body('customer_name').notEmpty().trim(),
  body('customer_email').isEmail().normalizeEmail()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { vehicle_id, customer_name, customer_email, customer_phone, message, interest_level = 'medium' } = req.body;
    
    // Get dealer ID from vehicle
    const vehicleResult = await query('SELECT dealer_id FROM vehicles WHERE id = $1', [vehicle_id]);
    if (vehicleResult.rows.length === 0) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }
    
    const dealerId = vehicleResult.rows[0].dealer_id;
    
    const result = await query(
      `INSERT INTO leads 
       (dealer_id, vehicle_id, customer_name, customer_email, customer_phone, message, interest_level, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
       RETURNING *`,
      [dealerId, vehicle_id, customer_name, customer_email, customer_phone, message, interest_level, 'new']
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create public lead error:', error);
    res.status(500).json({ error: 'Failed to create lead' });
  }
});

// Create new lead (authenticated)
router.post('/', [
  body('vehicle_id').isUUID(),
  body('customer_name').notEmpty().trim(),
  body('customer_email').isEmail().normalizeEmail()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const userId = req.user.id;
    const { vehicle_id, customer_name, customer_email, customer_phone, message, interest_level = 'medium' } = req.body;
    
    // Get dealer ID for this user (prefer staff dealer_id)
    let dealerId = req.user.dealer_id;
    if (!dealerId) {
      const dealerResult = await query('SELECT id FROM dealers WHERE user_id = $1', [userId]);
      if (dealerResult.rows.length === 0) {
        return res.status(404).json({ error: 'Dealer profile not found' });
      }
      dealerId = dealerResult.rows[0].id;
    }
    
    const result = await query(
      `INSERT INTO leads 
       (dealer_id, vehicle_id, customer_name, customer_email, customer_phone, message, interest_level, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
       RETURNING *`,
      [dealerId, vehicle_id, customer_name, customer_email, customer_phone, message, interest_level, 'new']
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create lead error:', error);
    res.status(500).json({ error: 'Failed to create lead' });
  }
});

// Update lead
router.put('/:id', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;
    const { status, interest_level, message } = req.body;
    
    // Check if lead belongs to this dealer (unless super admin)
    let leadCheck;
    if (req.user.role === 'super_admin') {
      leadCheck = await query('SELECT id FROM leads WHERE id = $1', [leadId]);
    } else if (req.user.dealer_id) {
      leadCheck = await query('SELECT id FROM leads WHERE id = $1 AND dealer_id = $2', [leadId, req.user.dealer_id]);
    } else {
      leadCheck = await query(
        'SELECT l.id FROM leads l JOIN dealers d ON l.dealer_id = d.id WHERE l.id = $1 AND d.user_id = $2',
        [leadId, userId]
      );
    }
    
    if (leadCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    const result = await query(
      `UPDATE leads SET 
       status = COALESCE($1, status),
       interest_level = COALESCE($2, interest_level),
       message = COALESCE($3, message),
       updated_at = NOW()
       WHERE id = $4
       RETURNING *`,
      [status, interest_level, message, leadId]
    );
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update lead error:', error);
    res.status(500).json({ error: 'Failed to update lead' });
  }
});

// Delete lead
router.delete('/:id', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;
    
    // Check if lead belongs to this dealer (unless super admin)
    let deleteQuery;
    let params;
    
    if (req.user.role === 'super_admin') {
      deleteQuery = 'DELETE FROM leads WHERE id = $1 RETURNING id';
      params = [leadId];
    } else if (req.user.dealer_id) {
      deleteQuery = 'DELETE FROM leads WHERE id = $1 AND dealer_id = $2 RETURNING id';
      params = [leadId, req.user.dealer_id];
    } else {
      deleteQuery = `
        DELETE FROM leads 
        WHERE id = $1 AND dealer_id IN (
          SELECT id FROM dealers WHERE user_id = $2
        ) 
        RETURNING id
      `;
      params = [leadId, userId];
    }
    
    const result = await query(deleteQuery, params);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    res.json({ message: 'Lead deleted successfully' });
  } catch (error) {
    console.error('Delete lead error:', error);
    res.status(500).json({ error: 'Failed to delete lead' });
  }
});

// Assign lead to sales agent (admin only)
router.post('/:id/assign', [
  body('staff_id').isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const leadId = req.params.id;
    const userId = req.user.id;
    const { staff_id } = req.body;

    // Only admin and super_admin can assign leads
    if (req.user.role !== 'super_admin' && req.user.staff_role !== 'admin') {
      return res.status(403).json({ error: 'Only administrators can assign leads' });
    }

    // Check if lead exists and belongs to this dealer (unless super admin)
    let leadCheck;
    if (req.user.role === 'super_admin') {
      leadCheck = await query('SELECT id, dealer_id FROM leads WHERE id = $1', [leadId]);
    } else if (req.user.dealer_id) {
      leadCheck = await query('SELECT id, dealer_id FROM leads WHERE id = $1 AND dealer_id = $2', [leadId, req.user.dealer_id]);
    } else {
      leadCheck = await query(
        'SELECT l.id, l.dealer_id FROM leads l JOIN dealers d ON l.dealer_id = d.id WHERE l.id = $1 AND d.user_id = $2',
        [leadId, userId]
      );
    }

    if (leadCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    const leadDealerId = leadCheck.rows[0].dealer_id;

    // Verify the staff member exists and belongs to the same dealer
    const staffCheck = await query(
      'SELECT ds.id, u.name, ds.staff_role FROM dealership_staff ds JOIN users u ON ds.user_id = u.id WHERE ds.id = $1 AND ds.dealer_id = $2 AND ds.staff_role = $3',
      [staff_id, leadDealerId, 'sales']
    );

    if (staffCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Sales agent not found or not valid for this dealer' });
    }

    // Assign the lead
    const result = await query(
      `UPDATE leads SET 
       assigned_to = $1,
       assigned_at = NOW(),
       assigned_by = $2,
       updated_at = NOW()
       WHERE id = $3
       RETURNING *`,
      [staff_id, userId, leadId]
    );

    res.json({
      message: 'Lead assigned successfully',
      lead: result.rows[0],
      assigned_agent: staffCheck.rows[0]
    });
  } catch (error) {
    console.error('Assign lead error:', error);
    res.status(500).json({ error: 'Failed to assign lead', details: error.message });
  }
});

// Unassign lead (admin only)
router.post('/:id/unassign', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;

    // Only admin and super_admin can unassign leads
    if (req.user.role !== 'super_admin' && req.user.staff_role !== 'admin') {
      return res.status(403).json({ error: 'Only administrators can unassign leads' });
    }

    // Check if lead exists and belongs to this dealer (unless super admin)
    let leadCheck;
    if (req.user.role === 'super_admin') {
      leadCheck = await query('SELECT id FROM leads WHERE id = $1', [leadId]);
    } else if (req.user.dealer_id) {
      leadCheck = await query('SELECT id FROM leads WHERE id = $1 AND dealer_id = $2', [leadId, req.user.dealer_id]);
    } else {
      leadCheck = await query(
        'SELECT l.id FROM leads l JOIN dealers d ON l.dealer_id = d.id WHERE l.id = $1 AND d.user_id = $2',
        [leadId, userId]
      );
    }

    if (leadCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    // Unassign the lead
    const result = await query(
      `UPDATE leads SET 
       assigned_to = NULL,
       assigned_at = NULL,
       assigned_by = NULL,
       updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [leadId]
    );

    res.json({
      message: 'Lead unassigned successfully',
      lead: result.rows[0]
    });
  } catch (error) {
    console.error('Unassign lead error:', error);
    res.status(500).json({ error: 'Failed to unassign lead' });
  }
});

// Get conversation history for a lead
router.get('/:id/conversations', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;

    // Check if lead exists and belongs to this dealer (unless super admin)
    let leadCheck;
    if (req.user.role === 'super_admin') {
      leadCheck = await query('SELECT id, dealer_id FROM leads WHERE id = $1', [leadId]);
    } else if (req.user.dealer_id) {
      leadCheck = await query('SELECT id, dealer_id FROM leads WHERE id = $1 AND dealer_id = $2', [leadId, req.user.dealer_id]);
    } else {
      leadCheck = await query(
        'SELECT l.id, l.dealer_id FROM leads l JOIN dealers d ON l.dealer_id = d.id WHERE l.id = $1 AND d.user_id = $2',
        [leadId, userId]
      );
    }

    if (leadCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    const leadDealerId = leadCheck.rows[0].dealer_id;

    // Get conversations related to this lead by customer email or phone
    const leadDetails = await query('SELECT customer_email, customer_phone FROM leads WHERE id = $1', [leadId]);
    const lead = leadDetails.rows[0];

    // Find conversations by customer email or phone
    const conversationsQuery = `
      SELECT 
        dc.id,
        dc.session_id,
        dc.customer_name,
        dc.customer_email,
        dc.customer_phone,
        dc.conversation_type,
        dc.lead_qualification_score,
        dc.lead_status,
        dc.handoff_requested,
        dc.handoff_reason,
        dc.handoff_requested_at,
        dc.created_at,
        dc.updated_at,
        v.make,
        v.model,
        v.year,
        v.vin,
        v.price
      FROM daive_conversations dc
      LEFT JOIN vehicles v ON dc.vehicle_id = v.id
      WHERE dc.dealer_id = $1 
      AND (dc.customer_email = $2 OR dc.customer_phone = $3)
      ORDER BY dc.created_at DESC
    `;

    const conversations = await query(conversationsQuery, [
      leadDealerId, 
      lead.customer_email, 
      lead.customer_phone
    ]);

    // Get messages for each conversation
    const conversationsWithMessages = await Promise.all(
      conversations.rows.map(async (conversation) => {
        const messagesQuery = `
          SELECT 
            id,
            role,
            content,
            created_at as timestamp
          FROM conversation_messages
          WHERE conversation_id = $1
          ORDER BY created_at ASC
        `;
        
        const messages = await query(messagesQuery, [conversation.id]);
        
        return {
          ...conversation,
          messages: messages.rows
        };
      })
    );

    res.json({
      success: true,
      data: {
        lead_id: leadId,
        conversations: conversationsWithMessages,
        total_conversations: conversationsWithMessages.length
      }
    });

  } catch (error) {
    console.error('Get lead conversations error:', error);
    res.status(500).json({ error: 'Failed to fetch conversation history' });
  }
});

// Get analytics for leads
router.get('/analytics', async (req, res) => {
  try {
    const userId = req.user.id;
    const { startDate, endDate } = req.query;

    // Set default date range (last 30 days)
    const defaultStartDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const defaultEndDate = new Date().toISOString().split('T')[0];
    
    const start = startDate || defaultStartDate;
    const end = endDate || defaultEndDate;

    let sqlQuery;
    let params;

    if (req.user.role === 'super_admin') {
      // Super admin can see all leads analytics
      sqlQuery = `
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as total_leads,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as new_leads,
          COUNT(CASE WHEN status = 'contacted' THEN 1 END) as contacted_leads,
          COUNT(CASE WHEN status = 'qualified' THEN 1 END) as qualified_leads,
          COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads,
          COUNT(CASE WHEN assigned_to IS NOT NULL THEN 1 END) as assigned_leads,
          AVG(CASE WHEN interest_level = 'low' THEN 1 WHEN interest_level = 'medium' THEN 2 WHEN interest_level = 'high' THEN 3 END) as avg_interest_score
        FROM leads 
        WHERE created_at BETWEEN $1 AND $2
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `;
      params = [start, end];
    } else if (req.user.dealer_id) {
      // Staff can see analytics for their dealer
      sqlQuery = `
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as total_leads,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as new_leads,
          COUNT(CASE WHEN status = 'contacted' THEN 1 END) as contacted_leads,
          COUNT(CASE WHEN status = 'qualified' THEN 1 END) as qualified_leads,
          COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads,
          COUNT(CASE WHEN assigned_to IS NOT NULL THEN 1 END) as assigned_leads,
          AVG(CASE WHEN interest_level = 'low' THEN 1 WHEN interest_level = 'medium' THEN 2 WHEN interest_level = 'high' THEN 3 END) as avg_interest_score
        FROM leads 
        WHERE dealer_id = $1 AND created_at BETWEEN $2 AND $3
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `;
      params = [req.user.dealer_id, start, end];
    } else {
      // Dealer owners can see analytics for their dealer
      sqlQuery = `
        SELECT 
          DATE(l.created_at) as date,
          COUNT(*) as total_leads,
          COUNT(CASE WHEN l.status = 'new' THEN 1 END) as new_leads,
          COUNT(CASE WHEN l.status = 'contacted' THEN 1 END) as contacted_leads,
          COUNT(CASE WHEN l.status = 'qualified' THEN 1 END) as qualified_leads,
          COUNT(CASE WHEN l.status = 'converted' THEN 1 END) as converted_leads,
          COUNT(CASE WHEN l.assigned_to IS NOT NULL THEN 1 END) as assigned_leads,
          AVG(CASE WHEN l.interest_level = 'low' THEN 1 WHEN l.interest_level = 'medium' THEN 2 WHEN l.interest_level = 'high' THEN 3 END) as avg_interest_score
        FROM leads l
        JOIN dealers d ON l.dealer_id = d.id
        WHERE d.user_id = $1 AND l.created_at BETWEEN $2 AND $3
        GROUP BY DATE(l.created_at)
        ORDER BY date DESC
      `;
      params = [userId, start, end];
    }

    const dailyStats = await query(sqlQuery, params);

    // Get total summary statistics
    let summaryQuery;
    let summaryParams;

    if (req.user.role === 'super_admin') {
      summaryQuery = `
        SELECT 
          COUNT(*) as total_leads,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as total_new_leads,
          COUNT(CASE WHEN status = 'contacted' THEN 1 END) as total_contacted_leads,
          COUNT(CASE WHEN status = 'qualified' THEN 1 END) as total_qualified_leads,
          COUNT(CASE WHEN status = 'converted' THEN 1 END) as total_converted_leads,
          COUNT(CASE WHEN assigned_to IS NOT NULL THEN 1 END) as total_assigned_leads,
          AVG(CASE WHEN interest_level = 'low' THEN 1 WHEN interest_level = 'medium' THEN 2 WHEN interest_level = 'high' THEN 3 END) as overall_avg_interest_score
        FROM leads 
        WHERE created_at BETWEEN $1 AND $2
      `;
      summaryParams = [start, end];
    } else if (req.user.dealer_id) {
      summaryQuery = `
        SELECT 
          COUNT(*) as total_leads,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as total_new_leads,
          COUNT(CASE WHEN status = 'contacted' THEN 1 END) as total_contacted_leads,
          COUNT(CASE WHEN status = 'qualified' THEN 1 END) as total_qualified_leads,
          COUNT(CASE WHEN status = 'converted' THEN 1 END) as total_converted_leads,
          COUNT(CASE WHEN assigned_to IS NOT NULL THEN 1 END) as total_assigned_leads,
          AVG(CASE WHEN interest_level = 'low' THEN 1 WHEN interest_level = 'medium' THEN 2 WHEN interest_level = 'high' THEN 3 END) as overall_avg_interest_score
        FROM leads 
        WHERE dealer_id = $1 AND created_at BETWEEN $2 AND $3
      `;
      summaryParams = [req.user.dealer_id, start, end];
    } else {
      summaryQuery = `
        SELECT 
          COUNT(*) as total_leads,
          COUNT(CASE WHEN l.status = 'new' THEN 1 END) as total_new_leads,
          COUNT(CASE WHEN l.status = 'contacted' THEN 1 END) as total_contacted_leads,
          COUNT(CASE WHEN l.status = 'qualified' THEN 1 END) as total_qualified_leads,
          COUNT(CASE WHEN l.status = 'converted' THEN 1 END) as total_converted_leads,
          COUNT(CASE WHEN l.assigned_to IS NOT NULL THEN 1 END) as total_assigned_leads,
          AVG(CASE WHEN l.interest_level = 'low' THEN 1 WHEN l.interest_level = 'medium' THEN 2 WHEN l.interest_level = 'high' THEN 3 END) as overall_avg_interest_score
        FROM leads l
        JOIN dealers d ON l.dealer_id = d.id
        WHERE d.user_id = $1 AND l.created_at BETWEEN $2 AND $3
      `;
      summaryParams = [userId, start, end];
    }

    const summaryStats = await query(summaryQuery, summaryParams);

    res.json({
      success: true,
      data: {
        daily: dailyStats.rows,
        summary: summaryStats.rows[0] || {},
        period: { startDate: start, endDate: end }
      }
    });

  } catch (error) {
    console.error('Get leads analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch leads analytics' });
  }
});

// Send SMS to lead
router.post('/:id/sms', async (req, res) => {
  try {
    const leadId = req.params.id;
    const userId = req.user.id;
    const { message, phone, customer_name } = req.body;

    if (!message || !phone) {
      return res.status(400).json({ 
        success: false,
        error: 'Message and phone number are required' 
      });
    }

    // Check if lead exists and belongs to this dealer (unless super admin)
    let leadCheck;
    if (req.user.role === 'super_admin') {
      leadCheck = await query('SELECT id, dealer_id, customer_name FROM leads WHERE id = $1', [leadId]);
    } else if (req.user.dealer_id) {
      leadCheck = await query('SELECT id, dealer_id, customer_name FROM leads WHERE id = $1 AND dealer_id = $2', [leadId, req.user.dealer_id]);
    } else {
      leadCheck = await query(
        'SELECT l.id, l.dealer_id, l.customer_name FROM leads l JOIN dealers d ON l.dealer_id = d.id WHERE l.id = $1 AND d.user_id = $2',
        [leadId, userId]
      );
    }

    if (leadCheck.rows.length === 0) {
      return res.status(404).json({ 
        success: false,
        error: 'Lead not found' 
      });
    }

    const lead = leadCheck.rows[0];

    // Import SMS service
    const smsService = require('../lib/smsService');

    // Validate phone number
    const isValidPhone = await smsService.validatePhoneNumber(phone);
    if (!isValidPhone) {
      return res.status(400).json({ 
        success: false,
        error: 'Invalid phone number format' 
      });
    }

    // Format phone number
    const formattedPhone = smsService.formatPhoneNumber(phone);

    // Send SMS
    const smsResult = await smsService.sendSMS(formattedPhone, message);

    // Log SMS activity in lead notes
    const smsLog = `SMS sent to ${customer_name || lead.customer_name} (${formattedPhone}) on ${new Date().toLocaleString()}:\n"${message}"\n\nSMS SID: ${smsResult.sid}`;
    
    await query(
      'UPDATE leads SET notes = COALESCE(notes, \'\') || $1, updated_at = NOW() WHERE id = $2',
      [`\n\n[SMS Activity]\n${smsLog}`, leadId]
    );

    res.json({
      success: true,
      data: {
        message: 'SMS sent successfully',
        smsResult: smsResult,
        leadId: leadId,
        customerName: customer_name || lead.customer_name,
        phone: formattedPhone
      }
    });

  } catch (error) {
    console.error('Send SMS error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message || 'Failed to send SMS' 
    });
  }
});

export default router;
