import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import { attachTenantContext } from '../middleware/tenantIsolation.js';
import financeNotificationService from '../lib/financeNotificationService.js';
import { pool } from '../database/connection.js';

const router = express.Router();

/**
 * GET /api/notifications/logs - Get notification history
 * Query params: type (email/sms), status (sent/failed), limit
 */
router.get('/logs', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const { type, status, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT 
        id,
        notification_type,
        recipient,
        content,
        status,
        error_message,
        sent_at,
        metadata
      FROM finance_notifications_log
      WHERE dealer_id = $1
    `;
    const params = [req.user.dealer_id];
    
    if (type) {
      params.push(type);
      query += ` AND notification_type = $${params.length}`;
    }
    
    if (status) {
      params.push(status);
      query += ` AND status = $${params.length}`;
    }
    
    query += ` ORDER BY sent_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit));
    params.push(parseInt(offset));
    
    const result = await pool.query(query, params);
    
    // Get total count
    let countQuery = 'SELECT COUNT(*) FROM finance_notifications_log WHERE dealer_id = $1';
    const countParams = [req.user.dealer_id];
    
    if (type) {
      countParams.push(type);
      countQuery += ` AND notification_type = $${countParams.length}`;
    }
    
    if (status) {
      countParams.push(status);
      countQuery += ` AND status = $${countParams.length}`;
    }
    
    const countResult = await pool.query(countQuery, countParams);
    const totalCount = parseInt(countResult.rows[0].count);
    
    res.json({ 
      success: true, 
      logs: result.rows,
      pagination: {
        total: totalCount,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: totalCount > (parseInt(offset) + parseInt(limit))
      }
    });
  } catch (error) {
    console.error('Error fetching notification logs:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/notifications/stats - Get notification statistics
 */
router.get('/stats', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    
    // Overall stats
    const statsQuery = `
      SELECT 
        notification_type,
        status,
        COUNT(*) as count
      FROM finance_notifications_log
      WHERE dealer_id = $1
        AND sent_at >= NOW() - INTERVAL '${parseInt(days)} days'
      GROUP BY notification_type, status
      ORDER BY notification_type, status
    `;
    
    const statsResult = await pool.query(statsQuery, [req.user.dealer_id]);
    
    // Daily breakdown
    const dailyQuery = `
      SELECT 
        DATE(sent_at) as date,
        notification_type,
        status,
        COUNT(*) as count
      FROM finance_notifications_log
      WHERE dealer_id = $1
        AND sent_at >= NOW() - INTERVAL '${parseInt(days)} days'
      GROUP BY DATE(sent_at), notification_type, status
      ORDER BY date DESC
    `;
    
    const dailyResult = await pool.query(dailyQuery, [req.user.dealer_id]);
    
    res.json({ 
      success: true, 
      stats: statsResult.rows,
      daily: dailyResult.rows
    });
  } catch (error) {
    console.error('Error fetching notification stats:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/notifications/test - Test notification system
 * Body: { type: 'email'|'sms', recipient: 'email@test.com'|'+1234567890' }
 */
router.post('/test', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const { type, recipient } = req.body;
    
    if (!type || !recipient) {
      return res.status(400).json({ 
        success: false, 
        error: 'Type and recipient are required' 
      });
    }
    
    if (type === 'email') {
      const dealerResult = await pool.query(
        'SELECT business_name FROM dealers WHERE id = $1',
        [req.user.dealer_id]
      );
      const dealerName = dealerResult.rows[0]?.business_name || 'DAIVE CRM';
      
      const testHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 30px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>✅ Test Email Successful</h1>
            </div>
            <div class="content">
              <p>This is a test email from the <strong>${dealerName}</strong> Finance Notification System.</p>
              <p>Your email notification system is working correctly!</p>
              <p><strong>Test Details:</strong></p>
              <ul>
                <li>Sent from: DAIVE CRM Finance Module</li>
                <li>Time: ${new Date().toLocaleString()}</li>
                <li>Dealer ID: ${req.user.dealer_id}</li>
              </ul>
            </div>
            <div class="footer">
              <p>© ${new Date().getFullYear()} DAIVE CRM. All rights reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `;
      
      const result = await financeNotificationService.sendEmail(
        recipient,
        'Test Email from DAIVE Finance Module',
        testHtml,
        req.user.dealer_id
      );
      
      if (result.success) {
        res.json({ 
          success: true, 
          message: 'Test email sent successfully',
          messageId: result.messageId
        });
      } else {
        res.status(500).json({ 
          success: false, 
          error: result.error || result.reason 
        });
      }
      
    } else if (type === 'sms') {
      const dealerResult = await pool.query(
        'SELECT business_name FROM dealers WHERE id = $1',
        [req.user.dealer_id]
      );
      const dealerName = dealerResult.rows[0]?.business_name || 'DAIVE CRM';
      
      const testMessage = `Test SMS from ${dealerName} Finance Module. Your SMS notification system is working! Sent at ${new Date().toLocaleTimeString()}`;
      
      const result = await financeNotificationService.sendSMS(
        recipient,
        testMessage,
        req.user.dealer_id
      );
      
      if (result.success) {
        res.json({ 
          success: true, 
          message: 'Test SMS sent successfully',
          sid: result.sid
        });
      } else {
        res.status(500).json({ 
          success: false, 
          error: result.error || result.reason 
        });
      }
      
    } else {
      res.status(400).json({ 
        success: false, 
        error: 'Invalid notification type. Use "email" or "sms"' 
      });
    }
  } catch (error) {
    console.error('Error testing notifications:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/notifications/settings - Get dealer notification settings
 */
router.get('/settings', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT notification_settings FROM dealers WHERE id = $1',
      [req.user.dealer_id]
    );
    
    const settings = result.rows[0]?.notification_settings || {
      email_enabled: true,
      sms_enabled: true,
      finance_notifications: true,
      signature_reminders: true,
      deal_status_updates: true
    };
    
    res.json({ success: true, settings });
  } catch (error) {
    console.error('Error fetching notification settings:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * PUT /api/notifications/settings - Update dealer notification settings
 * Body: { settings: { email_enabled: true, sms_enabled: true, ... } }
 */
router.put('/settings', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const { settings } = req.body;
    
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ 
        success: false, 
        error: 'Settings object is required' 
      });
    }
    
    // Validate settings structure
    const allowedKeys = [
      'email_enabled',
      'sms_enabled',
      'finance_notifications',
      'signature_reminders',
      'deal_status_updates'
    ];
    
    const validSettings = {};
    for (const key of allowedKeys) {
      if (key in settings) {
        validSettings[key] = Boolean(settings[key]);
      }
    }
    
    await pool.query(
      'UPDATE dealers SET notification_settings = $1 WHERE id = $2',
      [JSON.stringify(validSettings), req.user.dealer_id]
    );
    
    res.json({ 
      success: true, 
      message: 'Notification settings updated successfully',
      settings: validSettings
    });
  } catch (error) {
    console.error('Error updating notification settings:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/notifications/resend/:id - Resend a failed notification
 */
router.post('/resend/:id', authenticateToken, attachTenantContext, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get the original notification
    const notificationResult = await pool.query(
      'SELECT * FROM finance_notifications_log WHERE id = $1 AND dealer_id = $2',
      [id, req.user.dealer_id]
    );
    
    if (notificationResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Notification not found' 
      });
    }
    
    const notification = notificationResult.rows[0];
    
    // Only allow resending failed notifications
    if (notification.status !== 'failed') {
      return res.status(400).json({ 
        success: false, 
        error: 'Only failed notifications can be resent' 
      });
    }
    
    let result;
    if (notification.notification_type === 'email') {
      // For email, we'd need the original HTML content
      // For now, send a generic message
      result = await financeNotificationService.sendEmail(
        notification.recipient,
        notification.content,
        '<p>This is a resent notification. Original content not available.</p>',
        req.user.dealer_id
      );
    } else if (notification.notification_type === 'sms') {
      result = await financeNotificationService.sendSMS(
        notification.recipient,
        notification.content,
        req.user.dealer_id
      );
    }
    
    if (result.success) {
      res.json({ 
        success: true, 
        message: 'Notification resent successfully' 
      });
    } else {
      res.status(500).json({ 
        success: false, 
        error: result.error || result.reason 
      });
    }
    
  } catch (error) {
    console.error('Error resending notification:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;

