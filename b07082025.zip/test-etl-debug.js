// Debug script to check ETL database contents
import { query } from './src/database/connection.js';

async function debugETLDatabase() {
  try {
    console.log('🔍 Debugging ETL database...');
    
    // Check the main export configs table
    const exportConfigs = await query('SELECT * FROM etl_export_configs');
    console.log('\n=== ETL Export Configs ===');
    console.log('Total records:', exportConfigs.rows.length);
    exportConfigs.rows.forEach((config, index) => {
      console.log(`\nConfig ${index + 1}:`);
      console.log('  ID:', config.id);
      console.log('  Dealer ID:', config.dealer_id);
      console.log('  Config Name:', config.config_name);
      console.log('  Is Active:', config.is_active);
      console.log('  Created At:', config.created_at);
    });
    
    // Check connection settings
    const connectionSettings = await query('SELECT * FROM etl_connection_settings');
    console.log('\n=== Connection Settings ===');
    console.log('Total records:', connectionSettings.rows.length);
    connectionSettings.rows.forEach((conn, index) => {
      console.log(`\nConnection ${index + 1}:`);
      console.log('  Export Config ID:', conn.export_config_id);
      console.log('  Connection Type:', conn.connection_type);
      console.log('  Host URL:', conn.host_url);
      console.log('  Username:', conn.username);
    });
    
    // Check the dealer ID we're using
    const dealerId = '2e00a324-5931-4377-aef1-9ee9362e11a6';
    console.log('\n=== Dealer ID Check ===');
    console.log('Looking for dealer ID:', dealerId);
    
    // Check if this dealer ID exists in the export configs
    const dealerConfigs = await query('SELECT * FROM etl_export_configs WHERE dealer_id = $1', [dealerId]);
    console.log('Configs found for this dealer:', dealerConfigs.rows.length);
    
    // Check all dealer IDs in the table
    const allDealerIds = await query('SELECT DISTINCT dealer_id FROM etl_export_configs');
    console.log('\nAll dealer IDs in table:');
    allDealerIds.rows.forEach(row => {
      console.log('  -', row.dealer_id);
    });
    
    // Test the exact query from the service
    console.log('\n=== Testing Service Query ===');
    const serviceQuery = await query(`
      SELECT 
        ec.*,
        cs.connection_type, cs.host_url, cs.port, cs.username, cs.remote_directory,
        ss.frequency, ss.time_hour, ss.time_minute, ss.day_of_week, ss.day_of_month,
        ffs.file_type, ffs.delimiter, ffs.multi_value_delimiter, ffs.include_header,
        fns.naming_pattern, fns.include_timestamp,
        comp.company_name, comp.company_id
      FROM etl_export_configs ec
      LEFT JOIN etl_connection_settings cs ON ec.id = cs.export_config_id
      LEFT JOIN etl_schedule_settings ss ON ec.id = ss.export_config_id
      LEFT JOIN etl_file_format_settings ffs ON ec.id = ffs.export_config_id
      LEFT JOIN etl_file_naming_settings fns ON ec.id = fns.export_config_id
      LEFT JOIN etl_company_settings comp ON ec.id = comp.export_config_id
      WHERE ec.dealer_id = $1
      ORDER BY ec.created_at DESC
    `, [dealerId]);
    
    console.log('Service query results:', serviceQuery.rows.length);
    if (serviceQuery.rows.length > 0) {
      console.log('First result:', serviceQuery.rows[0]);
    }
    
  } catch (error) {
    console.error('❌ Error debugging ETL database:', error);
  }
}

debugETLDatabase(); 