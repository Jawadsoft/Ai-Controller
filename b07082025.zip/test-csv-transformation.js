import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:password@localhost:5432/vehicle_management'
});

// Simulate the transformation process
function transformRecordWithValidation(record, fieldMappings) {
  const transformed = {};
  
  console.log('Starting record transformation with validation...');
  console.log('Original record keys:', Object.keys(record));
  console.log('Field mappings count:', fieldMappings.length);
  
  for (const mapping of fieldMappings) {
    const sourceField = mapping.source_field || mapping.sourceField;
    const targetField = mapping.target_field || mapping.targetField;
    let fieldType = mapping.field_type || mapping.fieldType;
    const fieldNameLower = targetField.toLowerCase();
    
    const sourceValue = record[sourceField];
    
    console.log(`Mapping field: ${sourceField} -> ${targetField}, Original Value: "${sourceValue}"`);
    
    if (sourceValue !== undefined) {
      // Clean the value first
      const cleanedValue = sourceValue.toString().trim();
      console.log(`Cleaned value for ${targetField}: "${sourceValue}" -> "${cleanedValue}"`);
      
      // Auto-detect field type if not specified
      if (!fieldType) {
        fieldType = 'string'; // Default to string
        console.log(`Auto-detected field type for ${targetField}: ${fieldType}`);
      }
      
      // Simple transformation for now
      let transformedValue = cleanedValue;
      
      // Convert to number if needed
      if (fieldType === 'number' || fieldType === 'integer' || fieldType === 'decimal') {
        const numValue = parseFloat(cleanedValue);
        if (!isNaN(numValue)) {
          transformedValue = fieldType === 'integer' ? parseInt(numValue) : numValue;
        } else {
          transformedValue = null;
        }
      }
      
      // Convert to boolean if needed
      if (fieldType === 'boolean') {
        const boolValue = cleanedValue.toLowerCase();
        transformedValue = ['yes', 'true', '1', 'certified'].includes(boolValue);
      }
      
      transformed[targetField] = transformedValue;
      console.log(`Final value for ${targetField}: ${transformedValue} (${typeof transformedValue})`);
    } else {
      console.log(`No value found for ${sourceField}, skipping ${targetField}`);
    }
  }
  
  console.log('Final transformed record keys:', Object.keys(transformed));
  return transformed;
}

async function testCSVTransformation() {
  const client = await pool.connect();
  try {
    console.log('=== TESTING CSV TRANSFORMATION ===');
    
    // Get the latest import config
    const configsResult = await client.query(`
      SELECT id, dealer_id, config_name 
      FROM import_configs 
      ORDER BY created_at DESC LIMIT 1
    `);
    
    if (configsResult.rows.length === 0) {
      console.log('No import configs found!');
      return;
    }
    
    const config = configsResult.rows[0];
    console.log(`Using config: ${config.config_name} (ID: ${config.id})`);
    
    // Get field mappings
    const mappingsResult = await client.query(`
      SELECT source_field, target_field, field_type, field_order, is_required
      FROM import_field_mappings 
      WHERE import_config_id = $1 
      ORDER BY field_order
    `, [config.id]);
    
    console.log('\nField mappings loaded:', mappingsResult.rows.length);
    
    // Test with the actual CSV data from the error
    const testRecord = {
      "DealerId": "MP7042_ClayCooleyHyundaiofRockwall",
      "VIN": "2GNAXKEX6J6282582",
      "Year": "2018",
      "Make": "Chevrolet",
      "Model": "Equinox",
      "Series": "LT",
      "New/Used": "U",
      "Stock #": "J6282582",
      "Autowriter Description": "Odometer is 35737 miles below market average! Clean CARFAX. CARFAX One-Owner. Mosaic Black Metallic 2018 Chevrolet Equinox 4D Sport Utility LT 2.0L Turbocharged 22/29 City/Highway MPG 9-Speed Automatic with Overdrive FWD** Alloy Wheels / Premium Wheels, ** Apple CarPlay / Android Auto, ** Backup Camera / Parking Sensors, ** Bluetooth, Hands-Free, ** Brake Assist, ** Cruise Control, ** Keyless Entry, ** Premium Sound System / Premium Audio, ** Satellite Radio Capable, ** Security System, ** Stability Control, ** Steering Wheel Controls, ** USB Port, Equinox LT, 4D Sport Utility, 2.0L Turbocharged, 9-Speed Automatic with Overdrive, FWD, Mosaic Black Metallic, Jet Black Cloth.Awards:  * JD Power Automotive Performance, Execution and Layout (APEAL) Study   * 2018 KBB.com Best Family Cars   * 2018 KBB.com 10 Best SUVs Under $25,000   * 2018 KBB.com 10 Most Awarded Brands***Our average reconditioning costs is $1595 to bring your vehicle up to your expectations.Visit us at http://www.rockwallhyundai.net. 7 Day Vehicle Exchange Program on cars, trucks, and SUV inventory in Rockwall.Clay Cooley Hyundai of Rockwall is proud to offer this superb-looking 2018 Chevrolet Equinox LT. Well equipped with Confidence & Convenience Package, Driver Confidence Package (Lane Change Alert w/Side Blind Zone Alert, Outside Heated Power-Adjustable Mirrors, Rear Cross Traffic Alert, and Rear Park Assist w/Audible Warning), Driver Convenience Package (3-Spoke Leather-Wrapped Steering Wheel, Dual Zone Automatic Climate Control, Heated Driver & Front Passenger Seats, Rear Power Liftgate, Remote Vehicle Starter System, and Universal Home Remote), Preferred Equipment Group 2LT (4-Wheel Antilock 4-Wheel Disc Brakes, Body-Color Trailer Hitch Close-Out Cover, Dual Stainless-Steel Exhaust w/Bright Tips, and Factory Installed Trailer Hitch), Trailering Equipment, Equinox LT, 4D Sport Utility, 2.0L Turbocharged, 9-Speed Automatic with Overdrive, FWD, Mosaic Black Metallic, Jet Black Cloth, 18 Aluminum Wheels, 3.17 Final Drive Axle Ratio, 4-Wheel Disc Brakes, 6 Speaker Audio System Feature, 6 Speakers, 8-Way Power Driver Seat Adjuster, ABS brakes, Air Conditioning, Alloy wheels, AM/FM radio: SiriusXM, Apple CarPlay/Android Auto, Bluetooth® For Phone, Brake assist, Bumpers: body-color, Compass, Delay-off headlights, Driver door bin, Driver vanity mirror, Dual front impact airbags, Dual front side impact airbags, Electronic Stability Control, Emergency communication system: OnStar and Chevrolet connected services capable, Exterior Parking Camera Rear, Four wheel independent suspension, Front anti-roll bar, Front Bucket Seats, Front Center Armrest, Front Passenger 4-Way Manual Seat Adjuster, Front reading lights, Fully automatic headlights, Heated door mirrors, High-Intensity Discharge Headlights, Illuminated entry, Leather Shift Knob, Low tire pressure warning, Occupant sensing airbag, Outside temperature display, Overhead airbag, Overhead console, Panic alarm, Passenger door bin, Passenger vanity mirror, Power door mirrors, Power driver seat, Power steering, Power windows, Premium audio system: Chevrolet MyLink, Premium Cloth Seat Trim, Radio data system, Radio: Chevrolet MyLink AM/FM Stereo, Rear anti-roll bar, Rear reading lights, Rear seat center armrest, Rear window defroster, Rear window wiper, Remote keyless entry, Roof rack: rails only, Security system, SiriusXM Satellite Radio, Speed control, Speed-sensing steering, Split folding rear seat, Spoiler, Steering wheel mounted audio controls, Tachometer, Telescoping steering wheel, Tilt steering wheel, Traction control, Trip computer, USB Port & Auxiliary Input Jack, and Variably intermittent wipers.",
      "Body": "4D Sport Utility",
      "Certified": "",
      "Certification": "",
      "Color": "Mosaic Black Metallic",
      "Interior Color": "Jet Black",
      "Engine": "2.0L Turbocharged",
      "Disp": "R",
      "Features": "Confidence & Convenience Package|Driver Confidence Package|Driver Convenience Package|Preferred Equipment Group 2LT|Trailering Equipment|6 Speaker Audio System Feature|6 Speakers|AM/FM radio: SiriusXM|Premium audio system: Chevrolet MyLink|Radio data system|Radio: Chevrolet MyLink AM/FM Stereo|SiriusXM Satellite Radio|USB Port & Auxiliary Input Jack|Air Conditioning|Dual Zone Automatic Climate Control|Rear window defroster|8-Way Power Driver Seat Adjuster|Bluetooth® For Phone|Power driver seat|Power steering|Power windows|Remote keyless entry|Remote Vehicle Starter System|Steering wheel mounted audio controls|Universal Home Remote|Four wheel independent suspension|Speed-sensing steering|Traction control|4-Wheel Antilock 4-Wheel Disc Brakes|4-Wheel Disc Brakes|ABS brakes|Dual front impact airbags|Dual front side impact airbags|Emergency communication system: OnStar and Chevrolet connected services capable|Front anti-roll bar|Low tire pressure warning|Occupant sensing airbag|Overhead airbag|Rear anti-roll bar|Rear Power Liftgate|Brake assist|Electronic Stability Control|Exterior Parking Camera Rear|Delay-off headlights|Fully automatic headlights|High-Intensity Discharge Headlights|Panic alarm|Security system|Speed control|Bumpers: body-color|Dual Stainless-Steel Exhaust w/Bright Tips|Heated door mirrors|Outside Heated Power-Adjustable Mirrors|Power door mirrors|Roof rack: rails only|Spoiler|3-Spoke Leather-Wrapped Steering Wheel|Apple CarPlay/Android Auto|Compass|Driver door bin|Driver vanity mirror|Front reading lights|Illuminated entry|Lane Change Alert w/Side Blind Zone Alert|Leather Shift Knob|Outside temperature display|Overhead console|Passenger vanity mirror|Premium Cloth Seat Trim|Rear Cross Traffic Alert|Rear Park Assist w/Audible Warning|Rear reading lights|Rear seat center armrest|Tachometer|Telescoping steering wheel|Tilt steering wheel|Trip computer|Front Bucket Seats|Front Center Armrest|Front Passenger 4-Way Manual Seat Adjuster|Heated Driver & Front Passenger Seats|Split folding rear seat|Passenger door bin|Body-Color Trailer Hitch Close-Out Cover|Factory Installed Trailer Hitch|18 Aluminum Wheels|Alloy wheels|Rear window wiper|Variably intermittent wipers|3.17 Final Drive Axle Ratio|** Alloy Wheels / Premium Wheels|** Apple CarPlay / Android Auto|** Backup Camera / Parking Sensors|** Bluetooth, Hands-Free|** Brake Assist|** Cruise Control|** Keyless Entry|** Premium Sound System / Premium Audio|** Satellite Radio Capable|** Security System|** Stability Control|** Steering Wheel Controls|** USB Port",
      "Odometer": "62060",
      "Price": "16888",
      "Other Price": "16250",
      "Photo Url List": "http://imageonthefly.autodatadirect.com/images/?width=1200&height=900&IMG=CAC80CHS151A01301.jpg",
      "Transmission": "9-Speed Automatic with Overdrive",
      "Vehicle Detail Link": "",
      "MSRP": "",
      "Dealer Discounted": "",
      "Consumer Cash": "",
      "Dlr Accessories": "",
      "Total Customer Incentives": "",
      "Total Dealer Rebate": ""
    };
    
    console.log('\n=== TESTING TRANSFORMATION ===');
    console.log('Original record VIN:', testRecord.VIN);
    console.log('Original record Make:', testRecord.Make);
    console.log('Original record Model:', testRecord.Model);
    console.log('Original record Year:', testRecord.Year);
    
    // Transform the record
    const transformedRecord = transformRecordWithValidation(testRecord, mappingsResult.rows);
    
    console.log('\n=== TRANSFORMATION RESULTS ===');
    console.log('Transformed VIN:', transformedRecord.vin);
    console.log('Transformed Make:', transformedRecord.make);
    console.log('Transformed Model:', transformedRecord.model);
    console.log('Transformed Year:', transformedRecord.year);
    console.log('Transformed Dealer ID:', transformedRecord.dealer_id);
    
    // Check if required fields are present
    const requiredFields = ['dealer_id', 'vin', 'make', 'model', 'year'];
    console.log('\n=== REQUIRED FIELD CHECK ===');
    requiredFields.forEach(field => {
      const value = transformedRecord[field];
      if (value !== undefined && value !== null && value !== '') {
        console.log(`✅ ${field}: ${value}`);
      } else {
        console.log(`❌ ${field}: MISSING or EMPTY`);
      }
    });
    
  } catch (error) {
    console.error('Error testing CSV transformation:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

testCSVTransformation(); 