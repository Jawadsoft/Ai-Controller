import dotenv from 'dotenv';
import { query } from './src/database/connection.js';
import jwt from 'jsonwebtoken';

dotenv.config();

const testAuthMe = async () => {
  try {
    console.log('Testing /me endpoint for admin user...');
    
    // Get admin user
    const userResult = await query(
      'SELECT id, email FROM users WHERE email = $1',
      ['admin@example.com']
    );
    
    if (userResult.rows.length === 0) {
      console.log('❌ Admin user not found!');
      return;
    }
    
    const adminUser = userResult.rows[0];
    console.log('Admin user:', adminUser);
    
    // Generate a token for this user
    const token = jwt.sign({ userId: adminUser.id }, process.env.JWT_SECRET);
    console.log('Generated token:', token.substring(0, 50) + '...');
    
    // Test the /me endpoint logic manually
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log('Decoded token:', decoded);
    
    const meResult = await query(
      `SELECT u.id, u.email, ur.role, d.id as dealer_id, d.business_name, d.contact_name 
       FROM users u 
       LEFT JOIN user_roles ur ON u.id = ur.user_id 
       LEFT JOIN dealers d ON u.id = d.user_id 
       WHERE u.id = $1`,
      [decoded.userId]
    );
    
    if (meResult.rows.length === 0) {
      console.log('❌ User not found in /me query!');
      return;
    }
    
    const user = meResult.rows[0];
    console.log('Raw user data from /me query:', user);
    
    const userResponse = {
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        dealerProfile: user.dealer_id ? {
          id: user.dealer_id,
          businessName: user.business_name,
          contactName: user.contact_name
        } : null
      }
    };
    
    console.log('Final /me response:', JSON.stringify(userResponse, null, 2));
    
    // Check if role is null or undefined
    if (!user.role) {
      console.log('❌ ROLE IS NULL OR UNDEFINED!');
    } else {
      console.log('✅ Role is present:', user.role);
    }
    
  } catch (error) {
    console.error('Error testing /me endpoint:', error);
  } finally {
    process.exit(0);
  }
};

testAuthMe(); 