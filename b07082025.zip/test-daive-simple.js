import fetch from 'node-fetch';

async function testSimpleDAIVE() {
  try {
    console.log('🧪 Simple D.A.I.V.E. test...\n');
    
    const testData = {
      vehicleId: 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5',
      sessionId: 'simple_test_' + Date.now(),
      message: 'Hello',
      customerInfo: {
        name: 'Test User',
        email: 'test@example.com'
      }
    };
    
    console.log('📤 Sending request...');
    console.log('Data:', JSON.stringify(testData, null, 2));
    
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    console.log(`📥 Status: ${response.status}`);
    console.log(`📥 Headers:`, Object.fromEntries(response.headers.entries()));
    
    const responseText = await response.text();
    console.log(`📥 Body: ${responseText}`);
    
    if (response.ok) {
      const data = JSON.parse(responseText);
      console.log('\n✅ Success!');
      console.log('Response:', data.data.response);
    } else {
      console.log('\n❌ Failed!');
      console.log('Error:', responseText);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

testSimpleDAIVE(); 