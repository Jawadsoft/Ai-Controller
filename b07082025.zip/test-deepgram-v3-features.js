import DeepgramService from './src/lib/deepgram-v3.js';
import fs from 'fs';
import path from 'path';

async function testDeepgramV3Features() {
  console.log('🎤 Testing Deepgram v3 Features...\n');
  
  try {
    // Get Deepgram API key from environment
    const deepgramKey = process.env.DEEPGRAM_API_KEY;
    
    if (!deepgramKey) {
      console.error('❌ DEEPGRAM_API_KEY environment variable is required');
      process.exit(1);
    }
    
    const deepgramService = new DeepgramService(deepgramKey);
    
    // Test 1: Get available models
    console.log('1. Testing getAvailableModels...');
    const modelsResult = await deepgramService.getAvailableModels();
    
    if (modelsResult.success) {
      console.log('✅ Available models retrieved successfully');
      console.log('📋 Models:', modelsResult.models);
    } else {
      console.log('❌ Failed to get models:', modelsResult.error);
    }
    
    // Test 2: Get usage information
    console.log('\n2. Testing getUsage...');
    const usageResult = await deepgramService.getUsage();
    
    if (usageResult.success) {
      console.log('✅ Usage information retrieved successfully');
      console.log('📊 Usage:', usageResult.usage);
    } else {
      console.log('❌ Failed to get usage:', usageResult.error);
    }
    
    // Test 3: Test connection with v3 features
    console.log('\n3. Testing API connection...');
    const connectionResult = await deepgramService.testConnection();
    
    if (connectionResult.success) {
      console.log('✅ Deepgram v3 API connection successful');
      console.log('📝 Message:', connectionResult.message);
    } else {
      console.log('❌ Deepgram v3 API connection failed:', connectionResult.error);
    }
    
    // Test 4: Create test audio and test v3 transcription features
    console.log('\n4. Testing v3 transcription features...');
    const testAudioPath = path.join(process.cwd(), 'test-deepgram-v3-audio.wav');
    
    // Create a simple WAV file for testing
    const sampleRate = 16000;
    const duration = 3; // 3 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate a simple tone (440 Hz sine wave)
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      const sample = Math.sin(2 * Math.PI * 440 * i / sampleRate) * 0.3;
      audioData.writeInt16LE(Math.floor(sample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(testAudioPath, wavFile);
    
    console.log('✅ Test audio file created');
    
    // Test v3 specific options
    const v3Result = await deepgramService.transcribeAudioWithOptions(testAudioPath, {
      model: 'nova-2',
      language: 'en',
      smart_format: true,
      punctuate: true,
      filler_words: true,
      profanity_filter: false,
      redact: false,
      utterances: true
    });
    
    if (v3Result.success) {
      console.log('✅ Deepgram v3 transcription successful');
      console.log('📝 Transcription:', v3Result.text);
      console.log('🌍 Language:', v3Result.language);
      console.log('🎯 Confidence:', v3Result.confidence);
      console.log('⏱️ Duration:', v3Result.duration);
      console.log('📝 Words count:', v3Result.words?.length || 0);
      console.log('📝 Sentences count:', v3Result.sentences?.length || 0);
      console.log('📝 Paragraphs count:', v3Result.paragraphs?.length || 0);
    } else {
      console.log('❌ Deepgram v3 transcription failed:', v3Result.error);
    }
    
    // Clean up
    if (fs.existsSync(testAudioPath)) {
      fs.unlinkSync(testAudioPath);
      console.log('✅ Test audio file cleaned up');
    }
    
    console.log('\n✅ All Deepgram v3 feature tests completed!');
    
  } catch (error) {
    console.error('❌ Error testing Deepgram v3 features:', error);
    process.exit(1);
  }
}

testDeepgramV3Features(); 