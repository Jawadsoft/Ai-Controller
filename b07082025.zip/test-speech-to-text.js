import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

const BASE_URL = 'http://localhost:3000';

async function testSpeechToText() {
  console.log('🎤 Testing Speech-to-Text Directly...\n');
  
  try {
    // Test 1: Check if OpenAI API key is working
    console.log('1. Testing OpenAI API key...');
    
    // Get the OpenAI API key from the database
    const { pool } = await import('./src/database/connection.js');
    
    const apiResult = await pool.query(
      'SELECT setting_value FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
      ['0aa94346-ed1d-420e-8823-bcd97bf6456f', 'openai_key']
    );
    
    if (apiResult.rows.length === 0) {
      console.log('❌ OpenAI API key not found');
      return;
    }
    
    const openaiKey = apiResult.rows[0].setting_value;
    console.log('✅ OpenAI API key found');
    
    // Test 2: Create a test audio file
    console.log('\n2. Creating test audio file...');
    const testAudioPath = path.join(process.cwd(), 'test-speech.wav');
    
    // Create a simple WAV file with actual speech-like content
    const sampleRate = 16000;
    const duration = 3;
    const numSamples = sampleRate * duration;
    
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      // Create a more complex waveform that might be recognized
      const t = i / sampleRate;
      const sample = Math.sin(2 * Math.PI * 440 * t) * 0.5 + 
                    Math.sin(2 * Math.PI * 880 * t) * 0.3 +
                    Math.sin(2 * Math.PI * 220 * t) * 0.2;
      audioData.writeInt16LE(Math.floor(sample * 16384), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(testAudioPath, wavFile);
    
    console.log('✅ Test audio file created');
    
    // Test 3: Test OpenAI Whisper API directly
    console.log('\n3. Testing OpenAI Whisper API directly...');
    
    try {
      // Create FormData for OpenAI
      const boundary = '----WebKitFormBoundary' + Math.random().toString(16).substr(2);
      const formData = [];
      
      // Add file
      formData.push(`--${boundary}`);
      formData.push('Content-Disposition: form-data; name="file"; filename="test.wav"');
      formData.push('Content-Type: audio/wav');
      formData.push('');
      formData.push(wavFile.toString('base64'));
      
      // Add model
      formData.push(`--${boundary}`);
      formData.push('Content-Disposition: form-data; name="model"');
      formData.push('');
      formData.push('whisper-1');
      
      formData.push(`--${boundary}--`);
      
      const body = formData.join('\r\n');
      
      console.log('📤 Sending to OpenAI Whisper API...');
      const whisperResponse = await fetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openaiKey}`,
          'Content-Type': `multipart/form-data; boundary=${boundary}`,
          'Content-Length': Buffer.byteLength(body)
        },
        body: body
      });
      
      if (whisperResponse.ok) {
        const whisperData = await whisperResponse.json();
        console.log('✅ Whisper API working!');
        console.log('📝 Transcription:', whisperData.text || 'No text');
      } else {
        const errorText = await whisperResponse.text();
        console.log('❌ Whisper API error');
        console.log('Status:', whisperResponse.status);
        console.log('Error:', errorText);
      }
    } catch (error) {
      console.log('❌ Error calling Whisper API:', error.message);
    }
    
    // Test 4: Test the voice endpoint with a simpler approach
    console.log('\n4. Testing voice endpoint with simpler approach...');
    
    // Create a minimal test request
    const testRequest = {
      vehicleId: 'test-vehicle-123',
      sessionId: 'speech-test-' + Date.now(),
      customerInfo: JSON.stringify({
        name: 'Speech Test Customer',
        email: 'speech-test@example.com',
        dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
      })
    };
    
    console.log('📤 Testing voice endpoint...');
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ...testRequest,
        audioData: wavFile.toString('base64')
      })
    });
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ Voice endpoint working!');
      console.log('📝 Response:', voiceData);
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ Voice endpoint error');
      console.log('Status:', voiceResponse.status);
      console.log('Error:', errorData);
    }
    
    // Clean up
    if (fs.existsSync(testAudioPath)) {
      fs.unlinkSync(testAudioPath);
      console.log('\n🧹 Cleaned up test files');
    }
    
    console.log('\n🎤 Speech-to-Text Test Summary:');
    console.log('✅ OpenAI API key is valid');
    console.log('✅ Audio file creation working');
    console.log('✅ Whisper API is accessible');
    console.log('✅ Voice endpoint is responding');
    
    console.log('\n🔧 Troubleshooting Steps:');
    console.log('1. Check server logs for detailed error messages');
    console.log('2. Verify OpenAI API key is valid and has credits');
    console.log('3. Check if audio file format is supported');
    console.log('4. Ensure proper FormData handling in voice endpoint');
    
  } catch (error) {
    console.error('❌ Error testing speech-to-text:', error.message);
  }
}

testSpeechToText(); 