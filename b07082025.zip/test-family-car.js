import fetch from 'node-fetch';

async function testFamilyCarPrompt() {
  try {
    console.log('🧪 Testing D.A.I.V.E. with family car prompt...\n');
    
    // Use the Toyota Corolla from the database (good family car)
    const testData = {
      vehicleId: 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5', // Toyota Corolla
      sessionId: 'family_test_' + Date.now(),
      message: 'I want an ideal car for my family. What makes this vehicle perfect for families?',
      customerInfo: {
        name: 'Family Customer',
        email: 'family@example.com'
      }
    };
    
    console.log('📤 Sending family car request to D.A.I.V.E...');
    console.log('Vehicle: Toyota Corolla 2025');
    console.log('Customer prompt: "I want an ideal car for my family"');
    console.log('');
    
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    console.log(`📥 Response Status: ${response.status}`);
    
    const responseText = await response.text();
    console.log(`📥 Response Body: ${responseText}`);
    
    if (response.ok) {
      const data = JSON.parse(responseText);
      console.log('\n✅ Family car conversation successful!');
      console.log('\n🤖 D.A.I.V.E. Response:');
      console.log('=' .repeat(50));
      console.log(data.data.response);
      console.log('=' .repeat(50));
      console.log(`\n📊 Lead Score: ${data.data.leadScore}%`);
      console.log(`🔄 Handoff Needed: ${data.data.shouldHandoff ? 'Yes' : 'No'}`);
      
      // Test follow-up questions
      console.log('\n🔄 Testing follow-up questions...');
      
      const followUpQuestions = [
        'What about safety features for children?',
        'How much cargo space does it have for family trips?',
        'What are the fuel efficiency ratings?',
        'Can you tell me about financing options for families?'
      ];
      
      for (const question of followUpQuestions) {
        console.log(`\n❓ Customer: ${question}`);
        
        const followUpData = {
          ...testData,
          message: question
        };
        
        const followUpResponse = await fetch('http://localhost:3000/api/daive/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(followUpData),
        });
        
        if (followUpResponse.ok) {
          const followUpResult = await followUpResponse.json();
          console.log(`🤖 D.A.I.V.E.: ${followUpResult.data.response.substring(0, 150)}...`);
          console.log(`📊 Lead Score: ${followUpResult.data.leadScore}%`);
        } else {
          console.log('❌ Follow-up question failed');
        }
      }
      
    } else {
      console.log('\n❌ Family car conversation failed!');
      console.log('Error response:', responseText);
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error('Stack:', error.stack);
  }
}

// Run the test
testFamilyCarPrompt(); 