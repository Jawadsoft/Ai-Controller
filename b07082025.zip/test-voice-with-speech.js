import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { pool } from './src/database/connection.js';
import FormData from 'form-data';

const BASE_URL = 'http://localhost:3000';

async function testVoiceWithSpeech() {
  console.log('🎤 Testing Voice Endpoint with Speech-like Audio...\n');
  
  try {
    // Get a real vehicle ID from the database
    console.log('1. Getting real vehicle ID from database...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id = '0aa94346-ed1d-420e-8823-bcd97bf6456f'
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for dealer with API settings');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    
    // Create a more realistic speech-like audio file
    console.log('\n2. Creating speech-like audio file...');
    const audioFilePath = path.join(process.cwd(), 'test-speech-audio.wav');
    
    // Create a WAV file that simulates speech patterns
    const sampleRate = 16000;
    const duration = 5; // 5 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate speech-like audio with varying frequencies and patterns
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      // Create varying frequencies to simulate speech
      const time = i / sampleRate;
      const baseFreq = 150 + Math.sin(time * 2) * 50; // Varying base frequency
      const modFreq = 800 + Math.sin(time * 3) * 200; // Varying modulation
      
      // Combine multiple frequencies to simulate speech
      const sample1 = Math.sin(2 * Math.PI * baseFreq * time) * 0.2;
      const sample2 = Math.sin(2 * Math.PI * modFreq * time) * 0.1;
      const sample3 = Math.sin(2 * Math.PI * (baseFreq + modFreq) * time) * 0.05;
      
      // Add some noise to make it more realistic
      const noise = (Math.random() - 0.5) * 0.02;
      
      const combinedSample = sample1 + sample2 + sample3 + noise;
      audioData.writeInt16LE(Math.floor(combinedSample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(audioFilePath, wavFile);
    
    console.log('✅ Speech-like audio file created');
    console.log('📊 File size:', formatFileSize(wavFile.length));
    
    // Test voice endpoint
    console.log('\n3. Testing voice endpoint with speech-like audio...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(audioFilePath), {
      filename: 'speech-test.wav',
      contentType: 'audio/wav'
    });
    formData.append('vehicleId', vehicle.id);
    formData.append('sessionId', 'speech-test-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'Speech Test User',
      email: 'speech-test@example.com',
      dealerId: vehicle.dealer_id
    }));
    
    console.log('📤 Sending request...');
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      body: formData,
      headers: {
        ...formData.getHeaders()
      }
    });
    
    console.log('\n📥 Response received:');
    console.log('  - Status:', voiceResponse.status);
    console.log('  - OK:', voiceResponse.ok);
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ Voice endpoint is working');
      console.log('📝 Response data:', JSON.stringify(voiceData, null, 2));
      
      if (voiceData.data?.transcription === "Sorry, I couldn't understand your voice. Please try again.") {
        console.log('\n⚠️ Whisper API is not recognizing the speech-like audio');
        console.log('This suggests the issue might be:');
        console.log('1. Audio format not compatible with Whisper');
        console.log('2. Audio quality too low for transcription');
        console.log('3. Server-side FormData handling issue');
        console.log('4. Network or API connectivity problem');
      } else if (voiceData.data?.transcription) {
        console.log('\n✅ Whisper API successfully transcribed speech-like audio');
        console.log('📝 Transcription:', voiceData.data.transcription);
      }
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ Voice endpoint error');
      console.log('Error:', errorData);
    }
    
    // Clean up
    if (fs.existsSync(audioFilePath)) {
      fs.unlinkSync(audioFilePath);
      console.log('\n🧹 Cleaned up test audio file');
    }
    
  } catch (error) {
    console.error('❌ Error testing voice endpoint:', error.message);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

testVoiceWithSpeech(); 