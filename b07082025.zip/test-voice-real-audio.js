import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { pool } from './src/database/connection.js';
import FormData from 'form-data';

const BASE_URL = 'http://localhost:3000';

async function testVoiceWithRealAudio() {
  console.log('🎤 Testing Voice Endpoint with Real Audio...\n');
  
  try {
    // Get a real vehicle ID from the database for the dealer with API settings
    console.log('1. Getting real vehicle ID from database...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id = '0aa94346-ed1d-420e-8823-bcd97bf6456f'
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for dealer with API settings');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    console.log(`🏢 Dealer ID: ${vehicle.dealer_id}`);
    
    // Check if there are any existing audio files we can use
    const uploadsDir = path.join(process.cwd(), 'uploads', 'daive-audio');
    const existingFiles = fs.readdirSync(uploadsDir).filter(file => 
      file.endsWith('.wav') && fs.statSync(path.join(uploadsDir, file)).size > 1000
    );
    
    let audioFilePath;
    if (existingFiles.length > 0) {
      // Use an existing audio file
      audioFilePath = path.join(uploadsDir, existingFiles[0]);
      console.log(`✅ Using existing audio file: ${existingFiles[0]}`);
    } else {
      // Create a proper WAV file with real audio content
      console.log('2. Creating real audio file...');
      audioFilePath = path.join(process.cwd(), 'test-real-audio.wav');
      
      // Create a proper WAV file with a simple tone
      const sampleRate = 16000;
      const duration = 3; // 3 seconds
      const numSamples = sampleRate * duration;
      
      // WAV header
      const header = Buffer.alloc(44);
      header.write('RIFF', 0);
      header.writeUInt32LE(36 + numSamples * 2, 4);
      header.write('WAVE', 8);
      header.write('fmt ', 12);
      header.writeUInt32LE(16, 16);
      header.writeUInt16LE(1, 20);
      header.writeUInt16LE(1, 22);
      header.writeUInt32LE(sampleRate, 24);
      header.writeUInt32LE(sampleRate * 2, 28);
      header.writeUInt16LE(2, 32);
      header.writeUInt16LE(16, 34);
      header.write('data', 36);
      header.writeUInt32LE(numSamples * 2, 40);
      
      // Generate a more complex audio signal (sine wave with some variation)
      const audioData = Buffer.alloc(numSamples * 2);
      for (let i = 0; i < numSamples; i++) {
        // Create a varying frequency tone
        const frequency = 440 + Math.sin(i / 1000) * 100; // Varying frequency
        const sample = Math.sin(2 * Math.PI * frequency * i / sampleRate) * 0.3;
        audioData.writeInt16LE(Math.floor(sample * 32767), i * 2);
      }
      
      const wavFile = Buffer.concat([header, audioData]);
      fs.writeFileSync(audioFilePath, wavFile);
      console.log('✅ Real audio file created');
    }
    
    // Test voice endpoint with real audio
    console.log('\n3. Testing voice endpoint with real audio...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(audioFilePath), {
      filename: path.basename(audioFilePath),
      contentType: 'audio/wav'
    });
    formData.append('vehicleId', vehicle.id);
    formData.append('sessionId', 'test-session-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'Test Customer',
      email: 'test@example.com',
      dealerId: vehicle.dealer_id
    }));
    
    console.log('📤 Sending request with:');
    console.log('  - vehicleId:', vehicle.id);
    console.log('  - sessionId:', 'test-session-' + Date.now());
    console.log('  - dealerId:', vehicle.dealer_id);
    console.log('  - audio file:', audioFilePath);
    console.log('  - file size:', formatFileSize(fs.statSync(audioFilePath).size));
    
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      body: formData,
      headers: {
        ...formData.getHeaders()
      }
    });
    
    console.log('\n📥 Response received:');
    console.log('  - Status:', voiceResponse.status);
    console.log('  - OK:', voiceResponse.ok);
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ Voice endpoint is working');
      console.log('📝 Response data:', JSON.stringify(voiceData, null, 2));
      
      if (voiceData.data?.transcription === "Sorry, I couldn't understand your voice. Please try again.") {
        console.log('\n⚠️ Whisper API is not recognizing the audio');
        console.log('This could be due to:');
        console.log('1. Invalid audio format');
        console.log('2. Audio file too short or silent');
        console.log('3. OpenAI API key issues');
        console.log('4. Network connectivity problems');
      } else if (voiceData.data?.transcription) {
        console.log('\n✅ Whisper API successfully transcribed audio');
        console.log('📝 Transcription:', voiceData.data.transcription);
      }
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ Voice endpoint error');
      console.log('Error:', errorData);
    }
    
    // Clean up test file if we created it
    if (!existingFiles.length && fs.existsSync(audioFilePath)) {
      fs.unlinkSync(audioFilePath);
      console.log('\n🧹 Cleaned up test audio file');
    }
    
  } catch (error) {
    console.error('❌ Error testing voice endpoint:', error.message);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

testVoiceWithRealAudio(); 