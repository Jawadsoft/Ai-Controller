import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testVoiceSettingsUpdate() {
  try {
    console.log('🧪 Testing Voice Settings Update with TTS and Speech Provider fields...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Test data with all fields including TTS and Speech providers
    const testVoiceSettings = {
      enabled: true,
      language: 'en-US',
      voiceSpeed: 1.2,
      voicePitch: 1.1,
      voiceProvider: 'elevenlabs',
      speechProvider: 'deepgram',
      ttsProvider: 'deepgram'
    };

    console.log('\n📤 Sending voice settings with all fields:');
    console.log(JSON.stringify(testVoiceSettings, null, 2));

    // Save voice settings
    const saveResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(testVoiceSettings)
    });

    const saveResult = await saveResponse.json();
    console.log('\n💾 Save Response:');
    console.log(JSON.stringify(saveResult, null, 2));

    if (saveResult.success) {
      console.log('✅ Voice settings saved successfully!');
      
      // Now retrieve the settings to verify they were saved correctly
      console.log('\n📥 Retrieving saved voice settings...');
      
      const getResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const getResult = await getResponse.json();
      console.log('\n📋 Retrieved Voice Settings:');
      console.log(JSON.stringify(getResult, null, 2));

      if (getResult.success) {
        const settings = getResult.data;
        console.log('\n🔍 Verification:');
        console.log(`- Enabled: ${settings.enabled}`);
        console.log(`- Language: ${settings.language}`);
        console.log(`- Voice Speed: ${settings.voiceSpeed}`);
        console.log(`- Voice Pitch: ${settings.voicePitch}`);
        console.log(`- Voice Provider: ${settings.voiceProvider}`);
        console.log(`- Speech Provider: ${settings.speechProvider}`);
        console.log(`- TTS Provider: ${settings.ttsProvider}`);

        // Check if all fields are present and correct
        const allFieldsPresent = settings.hasOwnProperty('speechProvider') && 
                               settings.hasOwnProperty('ttsProvider') &&
                               settings.speechProvider === 'deepgram' &&
                               settings.ttsProvider === 'deepgram';

        if (allFieldsPresent) {
          console.log('\n🎉 SUCCESS: All voice settings fields are being saved and retrieved correctly!');
        } else {
          console.log('\n❌ FAILURE: Some voice settings fields are missing or incorrect');
        }
      } else {
        console.log('\n❌ Failed to retrieve voice settings');
      }
    } else {
      console.log('\n❌ Failed to save voice settings');
    }

  } catch (error) {
    console.error('❌ Error testing voice settings:', error);
  }
}

// Run the test
testVoiceSettingsUpdate(); 