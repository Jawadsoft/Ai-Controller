import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testVoiceUIDeepgram() {
  try {
    console.log('🧪 Testing Voice Settings UI with Deepgram Option...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // First, let's check current voice settings
    console.log('\n2. Checking current voice settings...');
    const currentResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const currentData = await currentResponse.json();
    console.log('📋 Current Voice Settings:');
    console.log(JSON.stringify(currentData, null, 2));

    // Now set voice provider to Deepgram through the API (simulating UI selection)
    console.log('\n3. Setting voice provider to Deepgram...');
    const deepgramSettings = {
      enabled: true,
      language: 'en-US',
      voiceSpeed: 1.2,
      voicePitch: 1.1,
      voiceProvider: 'deepgram',  // This simulates selecting Deepgram in the UI
      speechProvider: 'deepgram',
      ttsProvider: 'deepgram'
    };

    console.log('📤 Sending settings with Deepgram as voice provider:');
    console.log(JSON.stringify(deepgramSettings, null, 2));

    const saveResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(deepgramSettings)
    });

    const saveResult = await saveResponse.json();
    console.log('\n💾 Save Response:');
    console.log(JSON.stringify(saveResult, null, 2));

    if (saveResult.success) {
      console.log('✅ Voice settings with Deepgram saved successfully!');
      
      // Verify the settings were saved correctly
      console.log('\n4. Verifying saved settings...');
      const verifyResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const verifyResult = await verifyResponse.json();
      console.log('\n📋 Verified Voice Settings:');
      console.log(JSON.stringify(verifyResult, null, 2));

      if (verifyResult.success) {
        const settings = verifyResult.data;
        console.log('\n🔍 UI Simulation Results:');
        console.log(`- Voice Provider (UI Dropdown): ${settings.voiceProvider}`);
        console.log(`- Speech Provider (UI Dropdown): ${settings.speechProvider}`);
        console.log(`- TTS Provider (UI Dropdown): ${settings.ttsProvider}`);

        if (settings.voiceProvider === 'deepgram') {
          console.log('\n🎉 SUCCESS: Deepgram is now set as the voice provider!');
          console.log('✅ You can now select Deepgram from the Voice Provider dropdown in the UI');
          console.log('✅ The voice settings tab will dynamically update with Deepgram selected');
        } else {
          console.log('\n❌ FAILURE: Voice provider is not set to Deepgram');
        }
      } else {
        console.log('\n❌ Failed to verify voice settings');
      }
    } else {
      console.log('\n❌ Failed to save voice settings');
    }

  } catch (error) {
    console.error('❌ Error testing voice UI with Deepgram:', error);
  }
}

// Run the test
testVoiceUIDeepgram(); 