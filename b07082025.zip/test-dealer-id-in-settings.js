import { pool } from './src/database/connection.js';

async function testDealerIdInSettings() {
  try {
    console.log('🔍 Testing Dealer ID Handling in API and Voice Settings...\n');
    
    // Test 1: Check current API settings implementation
    console.log('📋 Test 1: Current API Settings Implementation');
    console.log('Current behavior: All API settings are stored with dealer_id = NULL (global)');
    
    const apiSettingsQuery = `
      SELECT setting_type, setting_value, dealer_id
      FROM daive_api_settings
      WHERE setting_type IN ('openai_key', 'elevenlabs_key', 'dealer_id')
      ORDER BY setting_type
    `;
    
    const apiResult = await pool.query(apiSettingsQuery);
    console.log('Current API Settings in DB:');
    apiResult.rows.forEach(row => {
      const maskedValue = row.setting_value && row.setting_value.length > 10 ? 
        row.setting_value.substring(0, 8) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
        row.setting_value;
      console.log(`   ${row.setting_type}: ${maskedValue} (dealer_id: ${row.dealer_id || 'NULL'})`);
    });
    
    // Test 2: Check current voice settings implementation
    console.log('\n🎵 Test 2: Current Voice Settings Implementation');
    console.log('Current behavior: Voice settings are also stored with dealer_id = NULL (global)');
    
    const voiceSettingsQuery = `
      SELECT setting_type, setting_value, dealer_id
      FROM daive_api_settings
      WHERE setting_type LIKE 'voice_%'
      ORDER BY setting_type
    `;
    
    const voiceResult = await pool.query(voiceSettingsQuery);
    console.log('Current Voice Settings in DB:');
    voiceResult.rows.forEach(row => {
      console.log(`   ${row.setting_type}: ${row.setting_value} (dealer_id: ${row.dealer_id || 'NULL'})`);
    });
    
    // Test 3: Test dealer-specific API setting storage
    console.log('\n🏢 Test 3: Testing Dealer-Specific API Setting Storage');
    
    // First, get a real dealer ID from the database
    const dealerQuery = 'SELECT id, business_name FROM dealers LIMIT 1';
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length > 0) {
      const testDealerId = dealerResult.rows[0].id;
      const businessName = dealerResult.rows[0].business_name;
      
      console.log(`Using dealer: ${businessName} (ID: ${testDealerId})`);
      
      // Test inserting a dealer-specific setting
      const dealerSpecificQuery = `
        INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
        VALUES ($1, 'dealer_specific_api_key', 'test-dealer-api-key-123')
        ON CONFLICT (dealer_id, setting_type) 
        DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()
        RETURNING *
      `;
      
      const dealerSpecificResult = await pool.query(dealerSpecificQuery, [testDealerId]);
      
      if (dealerSpecificResult.rows.length > 0) {
        console.log('✅ Successfully stored dealer-specific API setting');
        console.log(`   Dealer ID: ${dealerSpecificResult.rows[0].dealer_id}`);
        console.log(`   Setting: ${dealerSpecificResult.rows[0].setting_type}`);
        console.log(`   Value: ${dealerSpecificResult.rows[0].setting_value}`);
      }
      
      // Test retrieving dealer-specific vs global settings
      const allSettingsQuery = `
        SELECT setting_type, setting_value, dealer_id, 
               CASE 
                 WHEN dealer_id IS NULL THEN 'Global'
                 ELSE 'Dealer-Specific'
               END as scope
        FROM daive_api_settings
        WHERE dealer_id IS NULL OR dealer_id = $1
        ORDER BY scope, setting_type
      `;
      
      const allSettingsResult = await pool.query(allSettingsQuery, [testDealerId]);
      
      console.log('\n📊 All Settings (Global vs Dealer-Specific):');
      let currentScope = '';
      allSettingsResult.rows.forEach(row => {
        if (row.scope !== currentScope) {
          currentScope = row.scope;
          console.log(`\n   ${currentScope} Settings:`);
        }
        const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
          row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          row.setting_value;
        console.log(`     ${row.setting_type}: ${maskedValue}`);
      });
      
      // Clean up test data
      await pool.query(
        'DELETE FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
        [testDealerId, 'dealer_specific_api_key']
      );
      console.log('\n🧹 Cleaned up test data');
      
    } else {
      console.log('❌ No dealers found in database for testing');
    }
    
    // Test 4: Analyze the current implementation issues
    console.log('\n⚠️  Test 4: Current Implementation Analysis');
    console.log('Issues identified:');
    console.log('   1. API settings endpoint saves with dealer_id = NULL (global)');
    console.log('   2. Voice settings endpoint checks req.user.dealer_id but still saves with dealer_id = NULL');
    console.log('   3. This means all settings are global, not dealer-specific');
    console.log('   4. The dealer_id field we added is just another global setting, not the actual dealer context');
    
    // Test 5: Proposed solution demonstration
    console.log('\n💡 Test 5: Proposed Solution Demonstration');
    console.log('To make settings truly dealer-specific, we should:');
    console.log('   1. Use req.user.dealer_id when saving settings');
    console.log('   2. Filter by dealer_id when retrieving settings');
    console.log('   3. Fall back to global settings if dealer-specific ones don\'t exist');
    
    // Demonstrate how dealer-specific settings would work
    if (dealerResult.rows.length > 0) {
      const testDealerId = dealerResult.rows[0].id;
      
      // Save a dealer-specific OpenAI key
      const dealerOpenAIQuery = `
        INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
        VALUES ($1, 'openai_key', 'dealer-specific-openai-key-456')
        ON CONFLICT (dealer_id, setting_type) 
        DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()
        RETURNING *
      `;
      
      await pool.query(dealerOpenAIQuery, [testDealerId]);
      
      // Show how retrieval would work with dealer-specific priority
      const priorityQuery = `
        WITH dealer_settings AS (
          SELECT setting_type, setting_value, 'dealer' as source
          FROM daive_api_settings 
          WHERE dealer_id = $1 AND setting_type = 'openai_key'
        ),
        global_settings AS (
          SELECT setting_type, setting_value, 'global' as source
          FROM daive_api_settings 
          WHERE dealer_id IS NULL AND setting_type = 'openai_key'
        )
        SELECT * FROM dealer_settings
        UNION ALL
        SELECT * FROM global_settings
        WHERE NOT EXISTS (SELECT 1 FROM dealer_settings)
      `;
      
      const priorityResult = await pool.query(priorityQuery, [testDealerId]);
      
      console.log('Example: OpenAI Key Resolution (Dealer-specific takes priority):');
      priorityResult.rows.forEach(row => {
        const maskedValue = row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4);
        console.log(`   Source: ${row.source} | Value: ${maskedValue}`);
      });
      
      // Clean up
      await pool.query(
        'DELETE FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
        [testDealerId, 'openai_key']
      );
    }
    
    console.log('\n🎉 Analysis completed!');
    console.log('\n📝 Summary:');
    console.log('   ✅ Current implementation stores all settings globally (dealer_id = NULL)');
    console.log('   ✅ dealer_id field we added is just another global setting value');
    console.log('   ⚠️  Settings are not actually dealer-specific despite checking req.user.dealer_id');
    console.log('   💡 Consider implementing true dealer-specific settings with fallback to global');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

// Run the test
testDealerIdInSettings();