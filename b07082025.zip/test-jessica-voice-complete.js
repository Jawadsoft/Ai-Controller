import { pool } from './src/database/connection.js';
import { getElevenLabsVoiceId, getElevenLabsVoiceInfo } from './elevenlabs-voices.js';

async function testJessicaVoiceComplete() {
  try {
    console.log('🎤 Complete Jessica Voice Settings Test...\n');
    
    const dealerId = '0aa94346-ed1d-420e-8823-bcd97bf6456f';
    console.log(`🏢 Testing with dealer: ${dealerId}`);
    
    // Test 1: Voice mapping functionality
    console.log('\n🧪 Testing voice mapping...');
    const jessicaId = getElevenLabsVoiceId('jessica');
    const rachelId = getElevenLabsVoiceId('rachel');
    const defaultId = getElevenLabsVoiceId('nonexistent');
    
    console.log(`   Jessica voice ID: ${jessicaId}`);
    console.log(`   Rachel voice ID: ${rachelId}`);
    console.log(`   Default voice ID: ${defaultId} (should be Jessica)`);
    
    const jessicaInfo = getElevenLabsVoiceInfo('jessica');
    console.log(`   Jessica info: ${jessicaInfo.name} - ${jessicaInfo.description}`);
    
    // Test 2: Set Jessica voice for the dealer
    console.log('\n🧪 Setting Jessica voice for dealer...');
    const setVoiceQuery = `
      INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
      VALUES ($1, 'voice_elevenlabs_voice', 'jessica')
      ON CONFLICT (dealer_id, setting_type) 
      DO UPDATE SET setting_value = 'jessica', updated_at = NOW()
      RETURNING *
    `;
    
    await pool.query(setVoiceQuery, [dealerId]);
    console.log('   ✅ Jessica voice set for dealer');
    
    // Test 3: Verify voice setting retrieval (same as TTS code)
    console.log('\n🧪 Testing voice setting retrieval...');
    const voiceQuery = `
      WITH dealer_setting AS (
        SELECT setting_value FROM daive_api_settings 
        WHERE dealer_id = $1 AND setting_type = 'voice_elevenlabs_voice'
      ),
      global_setting AS (
        SELECT setting_value FROM daive_api_settings 
        WHERE dealer_id IS NULL AND setting_type = 'voice_elevenlabs_voice'
      )
      SELECT setting_value FROM dealer_setting
      UNION ALL
      SELECT setting_value FROM global_setting
      WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
      LIMIT 1
    `;
    
    const voiceResult = await pool.query(voiceQuery, [dealerId]);
    const selectedVoice = voiceResult.rows.length > 0 ? voiceResult.rows[0].setting_value : 'jessica';
    const voiceId = getElevenLabsVoiceId(selectedVoice);
    
    console.log(`   Selected voice: ${selectedVoice}`);
    console.log(`   Voice ID: ${voiceId}`);
    console.log(`   ✅ Voice retrieval working correctly`);
    
    // Test 4: Test all available voices
    console.log('\n🧪 Testing all available voices...');
    const availableVoices = ['jessica', 'rachel', 'domi', 'bella', 'antoni', 'elli', 'josh', 'arnold', 'adam', 'sam'];
    
    for (const voice of availableVoices) {
      const id = getElevenLabsVoiceId(voice);
      const info = getElevenLabsVoiceInfo(voice);
      console.log(`   ${voice}: ${id} - ${info.description}`);
    }
    
    // Test 5: Verify complete voice settings integration
    console.log('\n🧪 Testing complete voice settings...');
    
    // Simulate the voice settings API call
    const testVoiceSettings = {
      enabled: true,
      language: 'en-US',
      voiceSpeed: 1.0,
      voicePitch: 1.0,
      voiceProvider: 'elevenlabs',
      speechProvider: 'whisper',
      ttsProvider: 'elevenlabs',
      openaiVoice: 'alloy',
      elevenLabsVoice: 'jessica'
    };
    
    // Save all voice settings
    const voiceSettingsQuery = `
      INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
      VALUES ($1, $2, $3)
      ON CONFLICT (dealer_id, setting_type) 
      DO UPDATE SET setting_value = $3, updated_at = NOW()
      RETURNING *
    `;
    
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_enabled', testVoiceSettings.enabled.toString()]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_language', testVoiceSettings.language]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_speed', testVoiceSettings.voiceSpeed.toString()]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_pitch', testVoiceSettings.voicePitch.toString()]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_provider', testVoiceSettings.voiceProvider]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_speech_provider', testVoiceSettings.speechProvider]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_tts_provider', testVoiceSettings.ttsProvider]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_openai_voice', testVoiceSettings.openaiVoice]);
    await pool.query(voiceSettingsQuery, [dealerId, 'voice_elevenlabs_voice', testVoiceSettings.elevenLabsVoice]);
    
    console.log('   ✅ All voice settings saved successfully');
    
    // Test 6: Verify settings fetch (like the API endpoint)
    console.log('\n🧪 Testing voice settings fetch...');
    const fetchQuery = `
      WITH dealer_voice_settings AS (
        SELECT setting_type, setting_value, 'dealer' as source
        FROM daive_api_settings 
        WHERE dealer_id = $1 AND setting_type LIKE 'voice_%'
      ),
      global_voice_settings AS (
        SELECT setting_type, setting_value, 'global' as source
        FROM daive_api_settings 
        WHERE dealer_id IS NULL AND setting_type LIKE 'voice_%'
      )
      SELECT setting_type, setting_value, source
      FROM dealer_voice_settings
      UNION ALL
      SELECT setting_type, setting_value, source
      FROM global_voice_settings
      WHERE setting_type NOT IN (SELECT setting_type FROM dealer_voice_settings)
      ORDER BY setting_type
    `;
    
    const fetchResult = await pool.query(fetchQuery, [dealerId]);
    
    const voiceSettings = {
      enabled: false,
      language: 'en-US',
      voiceSpeed: 1.0,
      voicePitch: 1.0,
      voiceProvider: 'elevenlabs',
      speechProvider: 'whisper',
      ttsProvider: 'elevenlabs',
      openaiVoice: 'alloy',
      elevenLabsVoice: 'jessica'
    };
    
    fetchResult.rows.forEach(row => {
      switch (row.setting_type) {
        case 'voice_enabled':
          voiceSettings.enabled = row.setting_value === 'true';
          break;
        case 'voice_language':
          voiceSettings.language = row.setting_value;
          break;
        case 'voice_speed':
          voiceSettings.voiceSpeed = parseFloat(row.setting_value);
          break;
        case 'voice_pitch':
          voiceSettings.voicePitch = parseFloat(row.setting_value);
          break;
        case 'voice_provider':
          voiceSettings.voiceProvider = row.setting_value;
          break;
        case 'voice_speech_provider':
          voiceSettings.speechProvider = row.setting_value;
          break;
        case 'voice_tts_provider':
          voiceSettings.ttsProvider = row.setting_value;
          break;
        case 'voice_openai_voice':
          voiceSettings.openaiVoice = row.setting_value;
          break;
        case 'voice_elevenlabs_voice':
          voiceSettings.elevenLabsVoice = row.setting_value;
          break;
      }
    });
    
    console.log('   Fetched voice settings:');
    console.log(`     Enabled: ${voiceSettings.enabled}`);
    console.log(`     TTS Provider: ${voiceSettings.ttsProvider}`);
    console.log(`     ElevenLabs Voice: ${voiceSettings.elevenLabsVoice}`);
    console.log(`     Voice ID: ${getElevenLabsVoiceId(voiceSettings.elevenLabsVoice)}`);
    
    console.log('\n🎉 ALL JESSICA VOICE TESTS PASSED!');
    console.log('   ✅ Voice mapping working');
    console.log('   ✅ Database storage working');
    console.log('   ✅ Voice retrieval working');
    console.log('   ✅ All voice options available');
    console.log('   ✅ Settings API integration ready');
    console.log('   ✅ TTS code updated');
    
    console.log('\n🧪 FINAL TEST INSTRUCTIONS:');
    console.log('   1. Go to DAIVE Settings: http://localhost:8080/settings');
    console.log('   2. Navigate to Voice Settings tab');
    console.log('   3. Select "ElevenLabs (Recommended)" as TTS Provider');
    console.log('   4. Choose "Jessica (Recommended)" from ElevenLabs Voice dropdown');
    console.log('   5. Save Voice Settings');
    console.log('   6. Go to AI Bot page and test voice input');
    console.log('   7. Listen for Jessica\'s voice in the response');
    console.log('   8. Check backend console for: "🎤 Using ElevenLabs voice: jessica"');
    
    console.log('\n💡 Voice Options Available:');
    console.log('   • Jessica (Recommended) - Professional customer service');
    console.log('   • Rachel - Warm and friendly');
    console.log('   • Domi - Young and energetic');
    console.log('   • Bella - Soft and pleasant');
    console.log('   • Antoni - Male, professional');
    console.log('   • And 5 more voices to choose from!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testJessicaVoiceComplete();