import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testVehicleDetailDeepgram() {
  try {
    console.log('🧪 Testing VehicleDetail AI Assistant with Deepgram...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Check current voice settings
    console.log('\n2. Checking voice settings...');
    const voiceSettingsResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const voiceSettingsData = await voiceSettingsResponse.json();
    console.log('📋 Voice Settings:');
    console.log(JSON.stringify(voiceSettingsData, null, 2));

    if (voiceSettingsData.success) {
      const voiceSettings = voiceSettingsData.data;
      console.log('\n🔍 Voice Configuration:');
      console.log(`- Voice Provider: ${voiceSettings.voiceProvider}`);
      console.log(`- TTS Provider: ${voiceSettings.ttsProvider}`);
      console.log(`- Speech Provider: ${voiceSettings.speechProvider}`);
      console.log(`- Voice Enabled: ${voiceSettings.enabled}`);

      if (voiceSettings.voiceProvider !== 'deepgram') {
        console.log('\n⚠️ Voice Provider is not set to Deepgram!');
        console.log('💡 Please set Voice Provider to Deepgram in DAIVE Settings');
        return;
      }

      if (!voiceSettings.enabled) {
        console.log('\n⚠️ Voice responses are not enabled!');
        console.log('💡 Please enable voice responses in DAIVE Settings');
        return;
      }
    }

    // Test chat functionality with a vehicle
    console.log('\n3. Testing chat functionality with vehicle...');
    
    // First, get a list of vehicles to test with
    const vehiclesResponse = await fetch(`${BASE_URL}/api/vehicles`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const vehiclesData = await vehiclesResponse.json();
    console.log('📋 Vehicles Response Status:', vehiclesResponse.status);

    if (vehiclesData.success && vehiclesData.data.length > 0) {
      const testVehicle = vehiclesData.data[0];
      console.log('✅ Found test vehicle:', testVehicle.id);
      console.log('🚗 Vehicle:', `${testVehicle.year} ${testVehicle.make} ${testVehicle.model}`);

      // Test chat with the vehicle
      console.log('\n4. Testing chat with vehicle...');
      const chatResponse = await fetch(`${BASE_URL}/api/daive/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          vehicleId: testVehicle.id,
          sessionId: `test-session-${Date.now()}`,
          message: 'Hello, can you tell me about this vehicle?',
          customerInfo: {
            name: 'Test Customer',
            email: 'test@example.com',
            dealerId: testVehicle.dealer_id || '0aa94346-ed1d-420e-8823-bcd97bf6456f'
          }
        })
      });

      const chatData = await chatResponse.json();
      console.log('📋 Chat Response:');
      console.log(JSON.stringify(chatData, null, 2));

      if (chatData.success) {
        console.log('✅ Chat response successful!');
        console.log('💬 Response:', chatData.data.response);
        
        // Test Deepgram TTS generation for the response
        console.log('\n5. Testing Deepgram TTS generation...');
        
        // Get the Deepgram API key
        const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        const apiSettingsData = await apiSettingsResponse.json();
        const deepgramKey = apiSettingsData.data.deepgram_key?.value;
        
        if (deepgramKey) {
          console.log('🔑 Using Deepgram API key to generate audio...');
          
          // Test direct Deepgram TTS call
          const ttsResponse = await fetch('https://api.deepgram.com/v1/speak', {
            method: 'POST',
            headers: {
              'Authorization': `Token ${deepgramKey}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              text: chatData.data.response
            })
          });

          if (ttsResponse.ok) {
            const audioBuffer = await ttsResponse.arrayBuffer();
            console.log('✅ Audio generation successful!');
            console.log('🔊 Audio buffer size:', audioBuffer.byteLength, 'bytes');
            
            // Save the audio file
            const fs = await import('fs');
            const audioFileName = `vehicle-detail-response-${Date.now()}.mp3`;
            const audioPath = `./${audioFileName}`;
            fs.writeFileSync(audioPath, Buffer.from(audioBuffer));
            console.log('💾 Audio saved to:', audioPath);
            console.log('🎉 SUCCESS: VehicleDetail AI Assistant with Deepgram is working correctly!');
            
          } else {
            const errorText = await ttsResponse.text();
            console.log('❌ Audio generation failed:', errorText);
          }
        } else {
          console.log('❌ No Deepgram API key found');
        }
      } else {
        console.log('❌ Chat response failed:', chatData.error);
      }
    } else {
      console.log('❌ No vehicles found to test with');
    }

  } catch (error) {
    console.error('❌ Error testing VehicleDetail with Deepgram:', error);
  }
}

// Run the test
testVehicleDetailDeepgram(); 