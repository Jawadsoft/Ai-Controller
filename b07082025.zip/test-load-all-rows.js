import fetch from 'node-fetch';

async function testLoadAllRows() {
  try {
    console.log('Testing load-all-rows endpoint...');
    
    // Test without authentication first to see if the endpoint is reachable
    const testData = {
      configId: 'test-config-id',
      fileName: 'test-file.csv'
    };

    console.log('Sending request with data:', testData);

    const response = await fetch('http://localhost:3000/api/import/load-all-rows', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
        // No Authorization header for this test
      },
      body: JSON.stringify(testData)
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers.raw());

    const responseText = await response.text();
    console.log('Response body:', responseText);

    if (response.ok) {
      const data = JSON.parse(responseText);
      console.log('Success:', data);
    } else {
      console.error('Error response:', responseText);
    }

  } catch (error) {
    console.error('Test failed:', error);
  }
}

testLoadAllRows(); 