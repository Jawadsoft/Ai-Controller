import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

async function testOpenAITTS() {
  try {
    console.log('🎤 Testing OpenAI TTS (tts-1-hd)...\n');
    
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      console.error('❌ OPENAI_API_KEY environment variable is required');
      process.exit(1);
    }
    
    // Test 1: Test basic TTS functionality
    console.log('1. Testing OpenAI TTS API connection...');
    
    const testText = "Hello! I'm D.A.I.V.E., your AI vehicle assistant. How can I help you today?";
    
    const response = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'tts-1-hd',
        input: testText,
        voice: 'alloy',
        response_format: 'mp3',
        speed: 1.0
      })
    });
    
    if (response.ok) {
      console.log('✅ OpenAI TTS API connection successful');
      
      // Save the audio file
      const audioBuffer = await response.arrayBuffer();
      const audioFileName = `test-openai-tts-${Date.now()}.mp3`;
      const audioPath = path.join('./uploads/daive-audio', audioFileName);
      
      // Ensure directory exists
      const dir = path.dirname(audioPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(audioPath, Buffer.from(audioBuffer));
      console.log(`✅ Audio file saved: ${audioPath}`);
      console.log(`📁 File size: ${(audioBuffer.byteLength / 1024).toFixed(2)} KB`);
    } else {
      const errorText = await response.text();
      console.error('❌ OpenAI TTS API failed:', response.status, errorText);
      return;
    }
    
    // Test 2: Test different voices
    console.log('\n2. Testing different OpenAI voices...');
    
    const voices = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'];
    
    for (const voice of voices) {
      console.log(`   Testing voice: ${voice}`);
      
      const voiceResponse = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'tts-1-hd',
          input: `This is a test of the ${voice} voice.`,
          voice: voice,
          response_format: 'mp3',
          speed: 1.0
        })
      });
      
      if (voiceResponse.ok) {
        console.log(`   ✅ ${voice} voice working`);
      } else {
        console.log(`   ❌ ${voice} voice failed`);
      }
    }
    
    // Test 3: Test different speeds
    console.log('\n3. Testing different speeds...');
    
    const speeds = [0.5, 1.0, 1.5];
    
    for (const speed of speeds) {
      console.log(`   Testing speed: ${speed}x`);
      
      const speedResponse = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'tts-1-hd',
          input: `This is a test at ${speed}x speed.`,
          voice: 'alloy',
          response_format: 'mp3',
          speed: speed
        })
      });
      
      if (speedResponse.ok) {
        console.log(`   ✅ ${speed}x speed working`);
      } else {
        console.log(`   ❌ ${speed}x speed failed`);
      }
    }
    
    console.log('\n✅ OpenAI TTS testing completed successfully!');
    console.log('📁 Check the uploads/daive-audio directory for generated audio files.');
    
  } catch (error) {
    console.error('❌ OpenAI TTS test error:', error);
  }
}

testOpenAITTS(); 