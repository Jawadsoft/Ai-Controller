import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testDeepgramAPIKey() {
  try {
    console.log('🧪 Testing Deepgram API Key Validity...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Get the Deepgram API key
    console.log('\n2. Getting Deepgram API key...');
    const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const apiSettingsData = await apiSettingsResponse.json();
    const deepgramKey = apiSettingsData.data.deepgram_key?.value;
    
    if (!deepgramKey) {
      console.log('❌ No Deepgram API key found!');
      return;
    }

    console.log('✅ Deepgram API key found');
    console.log('🔑 Key length:', deepgramKey.length);
    console.log('🔑 Key format check:', deepgramKey.startsWith('fc3ae1a176') ? 'Looks like test key' : 'Different format');

    // Test with a simple text-to-speech request
    console.log('\n3. Testing Deepgram TTS with minimal payload...');
    
    const testPayload = {
      text: "Hello world"
    };
    
    console.log('📝 Test payload:', JSON.stringify(testPayload, null, 2));
    
    const deepgramResponse = await fetch('https://api.deepgram.com/v1/speak', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${deepgramKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testPayload)
    });

    console.log('📊 Deepgram API Response Status:', deepgramResponse.status);
    
    if (deepgramResponse.ok) {
      const audioBuffer = await deepgramResponse.arrayBuffer();
      console.log('✅ Deepgram API call successful!');
      console.log('🔊 Audio buffer size:', audioBuffer.byteLength, 'bytes');
      
      // Save the test audio file
      const fs = await import('fs');
      const testAudioPath = './test-deepgram-simple.mp3';
      fs.writeFileSync(testAudioPath, Buffer.from(audioBuffer));
      console.log('💾 Test audio saved to:', testAudioPath);
      
    } else {
      const errorText = await deepgramResponse.text();
      console.log('❌ Deepgram API call failed!');
      console.log('📊 Error Status:', deepgramResponse.status);
      console.log('📊 Error Response:', errorText);
      
      // Try to parse the error
      try {
        const errorJson = JSON.parse(errorText);
        console.log('📊 Parsed Error:', errorJson);
      } catch (e) {
        console.log('📊 Raw Error Text:', errorText);
      }
    }

    // Test with the full payload format
    console.log('\n4. Testing Deepgram TTS with full payload...');
    
    const fullPayload = {
      text: "Hello, this is a test of Deepgram text-to-speech.",
      model: "aura-asteria",
      voice: "asteria"
    };
    
    console.log('📝 Full payload:', JSON.stringify(fullPayload, null, 2));
    
    const fullResponse = await fetch('https://api.deepgram.com/v1/speak', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${deepgramKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(fullPayload)
    });

    console.log('📊 Full Payload Response Status:', fullResponse.status);
    
    if (fullResponse.ok) {
      const audioBuffer = await fullResponse.arrayBuffer();
      console.log('✅ Full payload API call successful!');
      console.log('🔊 Audio buffer size:', audioBuffer.byteLength, 'bytes');
      
      // Save the test audio file
      const fs = await import('fs');
      const testAudioPath = './test-deepgram-full.mp3';
      fs.writeFileSync(testAudioPath, Buffer.from(audioBuffer));
      console.log('💾 Full test audio saved to:', testAudioPath);
      
    } else {
      const errorText = await fullResponse.text();
      console.log('❌ Full payload API call failed!');
      console.log('📊 Error Status:', fullResponse.status);
      console.log('📊 Error Response:', errorText);
    }

    // Test the API key with a different endpoint
    console.log('\n5. Testing Deepgram API key with balance endpoint...');
    const balanceResponse = await fetch('https://api.deepgram.com/v1/usage', {
      headers: {
        'Authorization': `Token ${deepgramKey}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('📊 Balance API Response Status:', balanceResponse.status);
    
    if (balanceResponse.ok) {
      const balanceData = await balanceResponse.json();
      console.log('✅ Balance API call successful!');
      console.log('📊 Balance Data:', JSON.stringify(balanceData, null, 2));
    } else {
      const errorText = await balanceResponse.text();
      console.log('❌ Balance API call failed!');
      console.log('📊 Error Response:', errorText);
    }

  } catch (error) {
    console.error('❌ Error testing Deepgram API key:', error);
  }
}

// Run the test
testDeepgramAPIKey(); 