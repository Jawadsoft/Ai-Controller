import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000/api';

// Test data
const testVehicleId = 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5'; // Real Toyota Corolla from database
const testSessionId = 'daive_test_' + Date.now();

async function testDAIVE() {
  console.log('🧪 Testing D.A.I.V.E. Module...\n');

  try {
    // Test 1: Chat endpoint
    console.log('1️⃣ Testing Chat Endpoint...');
    const chatResponse = await fetch(`${BASE_URL}/daive/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: testVehicleId,
        sessionId: testSessionId,
        message: "Tell me about this vehicle",
        customerInfo: {
          name: "Test Customer",
          email: "test@example.com"
        }
      }),
    });

    const chatData = await chatResponse.json();
    console.log('Chat Response Status:', chatResponse.status);
    console.log('Chat Response:', JSON.stringify(chatData, null, 2));

    // Test 2: Conversation history
    console.log('\n2️⃣ Testing Conversation History...');
    const historyResponse = await fetch(`${BASE_URL}/daive/conversation/${testSessionId}`);
    const historyData = await historyResponse.json();
    console.log('History Response Status:', historyResponse.status);
    console.log('History Response:', JSON.stringify(historyData, null, 2));

    // Test 3: Health check
    console.log('\n3️⃣ Testing Health Check...');
    const healthResponse = await fetch(`${BASE_URL.replace('/api', '')}/health`);
    const healthData = await healthResponse.json();
    console.log('Health Response Status:', healthResponse.status);
    console.log('Health Response:', JSON.stringify(healthData, null, 2));

    console.log('\n✅ D.A.I.V.E. API Tests Completed!');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run the test
testDAIVE(); 