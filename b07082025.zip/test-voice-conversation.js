import fetch from 'node-fetch';
import fs from 'fs';
import FormData from 'form-data';

const BASE_URL = 'http://localhost:3000';

async function testVoiceConversation() {
  try {
    console.log('🧪 Testing Complete Voice Conversation Flow...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Check if we have a test audio file
    console.log('\n2. Checking for test audio file...');
    const testAudioPath = './test-deepgram-working.mp3';
    
    if (!fs.existsSync(testAudioPath)) {
      console.log('❌ Test audio file not found. Creating a simple test audio...');
      
      // Get Deepgram API key to create a test audio file
      const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const apiSettingsData = await apiSettingsResponse.json();
      const deepgramKey = apiSettingsData.data.deepgram_key?.value;
      
      if (deepgramKey) {
        console.log('🔑 Creating test audio file...');
        
        const ttsResponse = await fetch('https://api.deepgram.com/v1/speak', {
          method: 'POST',
          headers: {
            'Authorization': `Token ${deepgramKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            text: 'Hello, can you tell me about this vehicle?'
          })
        });

        if (ttsResponse.ok) {
          const audioBuffer = await ttsResponse.arrayBuffer();
          fs.writeFileSync(testAudioPath, Buffer.from(audioBuffer));
          console.log('✅ Test audio file created');
        } else {
          console.log('❌ Failed to create test audio file');
          return;
        }
      } else {
        console.log('❌ No Deepgram API key found');
        return;
      }
    } else {
      console.log('✅ Test audio file found');
    }

    // Test voice conversation with audio file
    console.log('\n3. Testing voice conversation with audio file...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath));
    formData.append('vehicleId', 'test-vehicle-123');
    formData.append('sessionId', 'test-session-456');
    formData.append('customerInfo', JSON.stringify({
      name: 'Test Customer',
      email: 'test@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }));

    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        ...formData.getHeaders()
      },
      body: formData
    });

    const voiceData = await voiceResponse.json();
    console.log('📋 Voice Conversation Response:');
    console.log(JSON.stringify(voiceData, null, 2));

    if (voiceData.success) {
      console.log('✅ Voice conversation successful!');
      console.log('💬 Transcription:', voiceData.transcription);
      console.log('🤖 AI Response:', voiceData.response);
      
      if (voiceData.audioResponseUrl) {
        console.log('🔊 Audio Response URL:', voiceData.audioResponseUrl);
        console.log('🎉 SUCCESS: Complete voice conversation flow is working!');
      } else {
        console.log('⚠️ No audio response URL returned');
      }
    } else {
      console.log('❌ Voice conversation failed:', voiceData.error);
    }

  } catch (error) {
    console.error('❌ Error testing voice conversation:', error);
  }
}

// Run the test
testVoiceConversation(); 