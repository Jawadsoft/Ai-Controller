import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { pool } from './src/database/connection.js';
import FormData from 'form-data';

const BASE_URL = 'http://localhost:3000';

async function testFrontendVoiceIntegration() {
  console.log('🎤 Testing Frontend Voice Integration...\n');
  
  try {
    // Get a real vehicle ID from the database
    console.log('1. Getting real vehicle ID from database...');
    const vehicleQuery = `
      SELECT id, make, model, year, dealer_id 
      FROM vehicles 
      WHERE dealer_id = '0aa94346-ed1d-420e-8823-bcd97bf6456f'
      LIMIT 1
    `;
    
    const vehicleResult = await pool.query(vehicleQuery);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found for dealer with API settings');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log(`✅ Found vehicle: ${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`);
    
    // Create a test audio file that simulates frontend recording
    console.log('\n2. Creating frontend-style audio file...');
    const audioFilePath = path.join(process.cwd(), 'test-frontend-voice.wav');
    
    // Create a WAV file that simulates what the frontend would send
    const sampleRate = 16000;
    const duration = 4; // 4 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate speech-like audio with varying patterns
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      const time = i / sampleRate;
      
      // Create varying speech-like patterns
      const baseFreq = 200 + Math.sin(time * 1.5) * 100;
      const modFreq = 600 + Math.sin(time * 2.5) * 150;
      const highFreq = 1200 + Math.sin(time * 3.5) * 200;
      
      // Combine frequencies to simulate speech
      const sample1 = Math.sin(2 * Math.PI * baseFreq * time) * 0.25;
      const sample2 = Math.sin(2 * Math.PI * modFreq * time) * 0.15;
      const sample3 = Math.sin(2 * Math.PI * highFreq * time) * 0.1;
      
      // Add some variation to simulate natural speech
      const variation = Math.sin(time * 8) * 0.05;
      const noise = (Math.random() - 0.5) * 0.01;
      
      const combinedSample = sample1 + sample2 + sample3 + variation + noise;
      audioData.writeInt16LE(Math.floor(combinedSample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(audioFilePath, wavFile);
    
    console.log('✅ Frontend-style audio file created');
    console.log('📊 File size:', formatFileSize(wavFile.length));
    
    // Test the voice endpoint with frontend-style data
    console.log('\n3. Testing voice endpoint with frontend-style request...');
    
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(audioFilePath), {
      filename: 'frontend-voice-test.wav',
      contentType: 'audio/wav'
    });
    formData.append('vehicleId', vehicle.id);
    formData.append('sessionId', 'frontend-test-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'Frontend Test User',
      email: 'frontend-test@example.com',
      dealerId: vehicle.dealer_id
    }));
    
    console.log('📤 Sending frontend-style request...');
    const voiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      body: formData,
      headers: {
        ...formData.getHeaders()
      }
    });
    
    console.log('\n📥 Response received:');
    console.log('  - Status:', voiceResponse.status);
    console.log('  - OK:', voiceResponse.ok);
    
    if (voiceResponse.ok) {
      const voiceData = await voiceResponse.json();
      console.log('✅ Voice endpoint is working with frontend data');
      console.log('📝 Response data:', JSON.stringify(voiceData, null, 2));
      
      if (voiceData.data?.transcription && 
          voiceData.data.transcription !== "Sorry, I couldn't understand your voice. Please try again.") {
        console.log('\n🎉 SUCCESS: Voice recognition is working!');
        console.log('📝 Transcription:', voiceData.data.transcription);
        console.log('🤖 AI Response:', voiceData.data.response);
        console.log('📊 Lead Score:', voiceData.data.leadScore);
      } else {
        console.log('\n⚠️ Voice recognition failed');
        console.log('This might be due to:');
        console.log('1. Audio quality not suitable for transcription');
        console.log('2. Audio format issues');
        console.log('3. Whisper API limitations with generated audio');
      }
    } else {
      const errorData = await voiceResponse.text();
      console.log('❌ Voice endpoint error');
      console.log('Error:', errorData);
    }
    
    // Clean up
    if (fs.existsSync(audioFilePath)) {
      fs.unlinkSync(audioFilePath);
      console.log('\n🧹 Cleaned up test audio file');
    }
    
  } catch (error) {
    console.error('❌ Error testing frontend voice integration:', error.message);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

testFrontendVoiceIntegration(); 