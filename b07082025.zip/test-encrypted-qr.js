import { generateVehicleHash, encryptVehicleData, decryptVehicleData } from './src/lib/qrCodeGenerator.js';
import { pool } from './src/database/connection.js';

async function testEncryptedQR() {
  try {
    console.log('🔐 Testing encrypted QR code functionality...\n');
    
    // Get a test vehicle
    const vehicleResult = await pool.query(`
      SELECT id, vin, make, model, year 
      FROM vehicles 
      LIMIT 1
    `);
    
    if (vehicleResult.rows.length === 0) {
      console.log('❌ No vehicles found in database');
      return;
    }
    
    const vehicle = vehicleResult.rows[0];
    console.log('Test vehicle:');
    console.log(`   ID: ${vehicle.id}`);
    console.log(`   VIN: ${vehicle.vin}`);
    console.log(`   Make/Model: ${vehicle.year} ${vehicle.make} ${vehicle.model}`);
    console.log('');
    
    // Test encryption
    console.log('1. Testing encryption...');
    const encryptedData = encryptVehicleData(vehicle.id, vehicle.vin);
    console.log(`   Encrypted data: ${encryptedData.substring(0, 50)}...`);
    
    // Test decryption
    console.log('\n2. Testing decryption...');
    const decryptedData = decryptVehicleData(encryptedData);
    if (decryptedData) {
      console.log(`   Decrypted data: ${JSON.stringify(decryptedData)}`);
    } else {
      console.log('   ❌ Decryption failed');
    }
    
    // Test hash generation
    console.log('\n3. Testing hash generation...');
    const vehicleHash = generateVehicleHash(vehicle.id, vehicle.vin);
    console.log(`   Vehicle hash: ${vehicleHash}`);
    
    // Test URL generation
    console.log('\n4. Testing URL generation...');
    const frontendURL = 'http://localhost:8081';
    const qrURL = `${frontendURL}/vehicle/qr/${vehicleHash}`;
    console.log(`   QR Code URL: ${qrURL}`);
    
    // Test hash verification
    console.log('\n5. Testing hash verification...');
    const testHash = generateVehicleHash(vehicle.id, vehicle.vin);
    if (testHash === vehicleHash) {
      console.log('   ✅ Hash verification successful');
    } else {
      console.log('   ❌ Hash verification failed');
    }
    
    // Test with different VIN
    console.log('\n6. Testing with different VIN...');
    const wrongHash = generateVehicleHash(vehicle.id, 'WRONG_VIN');
    if (wrongHash !== vehicleHash) {
      console.log('   ✅ Hash is unique for different VINs');
    } else {
      console.log('   ❌ Hash collision detected');
    }
    
    console.log('\n🎉 Encrypted QR code functionality is working!');
    console.log('\n📋 Summary:');
    console.log(`   - Vehicle ID: ${vehicle.id}`);
    console.log(`   - Original VIN: ${vehicle.vin}`);
    console.log(`   - Encrypted Hash: ${vehicleHash}`);
    console.log(`   - QR Code URL: ${qrURL}`);
    console.log('\n🔒 The VIN is now encrypted and not visible in the QR code URL!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await pool.end();
  }
}

testEncryptedQR(); 