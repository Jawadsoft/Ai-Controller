// Test script to debug authentication
import jwt from 'jsonwebtoken';
import { query } from './src/database/connection.js';

async function testAuth() {
  try {
    // Test the exact query from the auth middleware
    const userId = '2e00a324-5931-4377-aef1-9ee9362e11a6'; // dealer1@example.com
    
    const userResult = await query(
      'SELECT u.*, ur.role, d.id as dealer_id FROM users u LEFT JOIN user_roles ur ON u.id = ur.user_id LEFT JOIN dealers d ON u.id = d.user_id WHERE u.id = $1',
      [userId]
    );

    console.log('=== Auth Query Result ===');
    if (userResult.rows.length > 0) {
      const user = userResult.rows[0];
      console.log('User ID:', user.id);
      console.log('Email:', user.email);
      console.log('Role:', user.role);
      console.log('Dealer ID:', user.dealer_id);
      console.log('All user properties:', Object.keys(user));
    } else {
      console.log('No user found');
    }
    
    // Test the ETL route logic
    const dealerId = userResult.rows[0]?.dealer_id;
    console.log('\n=== ETL Route Check ===');
    console.log('Dealer ID from auth:', dealerId);
    console.log('Dealer ID exists:', !!dealerId);
    
    if (!dealerId) {
      console.log('❌ This would cause 403 "Dealer access required"');
    } else {
      console.log('✅ This should work for ETL routes');
    }
    
  } catch (error) {
    console.error('Error testing auth:', error);
  }
}

testAuth(); 