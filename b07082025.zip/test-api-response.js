// Test script to see the exact API response structure
import fetch from 'node-fetch';

async function testAPIResponse() {
  try {
    console.log('🔍 Testing API response structure...');
    
    const response = await fetch('http://localhost:8080/api/etl/configs', {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIyZTAwYTMyNC01OTMxLTQzNzctYWVmMS05ZWU5MzYyZTExYTYiLCJpYXQiOjE3NTM5OTMyNTcsImV4cCI6MTc1NDU5ODA1N30.osMXcViMC5SMtdmBZQjWYY4I_6Q4svR_SuALLGm-954'
      }
    });
    
    const data = await response.json();
    console.log('\n=== API Response Structure ===');
    console.log('Success:', data.success);
    console.log('Data length:', data.data?.length);
    
    if (data.data && data.data.length > 0) {
      const config = data.data[0];
      console.log('\n=== First Config Structure ===');
      console.log('All keys:', Object.keys(config));
      console.log('Config object:', JSON.stringify(config, null, 2));
    }
    
  } catch (error) {
    console.error('❌ Error testing API response:', error);
  }
}

testAPIResponse(); 