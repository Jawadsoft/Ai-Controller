const fetch = require('node-fetch');

async function testSpruceVoice() {
  console.log('🧪 Testing Spruce Voice TTS...\n');
  
  try {
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: 'test-vehicle-id',
        sessionId: 'test-session-' + Date.now(),
        message: 'Hello, this is a test of the spruce voice. Can you hear the difference?',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
        }
      }),
    });

    const data = await response.json();
    console.log('📥 Response Status:', response.status);
    console.log('📥 Response Data:', {
      success: data.success,
      hasResponse: !!data.data?.response,
      hasAudioUrl: !!data.data?.audioResponseUrl,
      audioUrl: data.data?.audioResponseUrl,
      responseLength: data.data?.response?.length || 0
    });

    if (data.success && data.data.audioResponseUrl) {
      console.log('✅ TTS working with spruce voice!');
      console.log('🔊 Audio URL:', data.data.audioResponseUrl);
      console.log('🎤 Voice: spruce (should be different from alloy)');
      
      // Check if the audio file was created
      const audioUrl = data.data.audioResponseUrl;
      if (audioUrl) {
        console.log('📁 Audio file created at:', audioUrl);
        console.log('🎵 You can play this audio to hear the spruce voice');
      }
    } else {
      console.log('⚠️ TTS not working or no audio generated');
      console.log('🔍 Response:', data.data?.response?.substring(0, 100) + '...');
    }
  } catch (error) {
    console.error('❌ Error testing spruce voice:', error);
  }
}

// Run the test
testSpruceVoice().catch(console.error); 