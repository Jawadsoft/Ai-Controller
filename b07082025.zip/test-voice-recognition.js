import { pool } from './src/database/connection.js';

async function testVoiceRecognition() {
  console.log('🎤 Testing Voice Recognition Configuration...\n');
  
  try {
    // Test 1: Check if dealer has OpenAI API key
    console.log('1. Checking dealer API configuration...');
    const dealerResult = await pool.query(
      'SELECT id FROM dealers WHERE email = $1',
      ['dealer1@example.com']
    );
    
    if (dealerResult.rows.length === 0) {
      console.log('❌ Dealer not found');
      return;
    }
    
    const dealerId = dealerResult.rows[0].id;
    console.log(`✅ Dealer found with ID: ${dealerId}`);
    
    // Check OpenAI API key
    const openaiResult = await pool.query(
      'SELECT setting_value FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
      [dealerId, 'openai_key']
    );
    
    if (openaiResult.rows.length > 0) {
      const openaiKey = openaiResult.rows[0].setting_value;
      console.log('✅ OpenAI API key is configured');
      console.log(`📝 Key starts with: ${openaiKey.substring(0, 8)}...`);
    } else {
      console.log('❌ OpenAI API key not found');
      console.log('Please configure OpenAI API key in DAIVE Settings → API Keys');
      return;
    }
    
    // Test 2: Check voice settings
    console.log('\n2. Checking voice settings...');
    const voiceSettings = await pool.query(
      'SELECT setting_type, setting_value FROM daive_api_settings WHERE dealer_id = $1 AND setting_type LIKE $2',
      [dealerId, 'voice_%']
    );
    
    console.log('📋 Voice Settings:');
    voiceSettings.rows.forEach(row => {
      console.log(`   ${row.setting_type}: ${row.setting_value}`);
    });
    
    // Test 3: Check if voice is enabled
    const voiceEnabled = voiceSettings.rows.find(row => 
      row.setting_type === 'voice_enabled' && row.setting_value === 'true'
    );
    
    if (voiceEnabled) {
      console.log('✅ Voice is enabled for this dealer');
    } else {
      console.log('⚠️ Voice is not enabled');
      console.log('Please enable voice in DAIVE Settings → Voice Settings');
    }
    
    // Test 4: Check ElevenLabs configuration
    console.log('\n3. Checking ElevenLabs configuration...');
    const elevenLabsResult = await pool.query(
      'SELECT setting_value FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
      [dealerId, 'elevenlabs_key']
    );
    
    if (elevenLabsResult.rows.length > 0) {
      const elevenLabsKey = elevenLabsResult.rows[0].setting_value;
      console.log('✅ ElevenLabs API key is configured');
      console.log(`📝 Key starts with: ${elevenLabsKey.substring(0, 8)}...`);
    } else {
      console.log('❌ ElevenLabs API key not found');
      console.log('Please configure ElevenLabs API key in DAIVE Settings → API Keys');
    }
    
    console.log('\n🎯 Voice Recognition Status:');
    console.log('✅ OpenAI API key configured for speech-to-text');
    console.log('✅ ElevenLabs API key configured for text-to-speech');
    console.log('✅ Voice settings are properly configured');
    console.log('\n📱 Next Steps:');
    console.log('1. Make sure voice is enabled in DAIVE Settings');
    console.log('2. Test voice input in a vehicle chat');
    console.log('3. Speak clearly when using the microphone button');
    console.log('4. Check browser microphone permissions');
    
  } catch (error) {
    console.error('❌ Error testing voice recognition:', error);
  } finally {
    await pool.end();
  }
}

testVoiceRecognition(); 