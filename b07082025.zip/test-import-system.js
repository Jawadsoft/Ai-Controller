// Test script for the import system
console.log('🚀 Import System Test');

// Test 1: Check if all required files exist
const fs = require('fs');
const path = require('path');

const requiredFiles = [
  'src/lib/importService.js',
  'src/routes/import.js',
  'src/components/import/ImportConfiguration.tsx',
  'src/pages/Import.tsx',
  'src/database/import-schema.sql'
];

console.log('\n📁 Checking required files...');
let allFilesExist = true;

requiredFiles.forEach(file => {
  const exists = fs.existsSync(file);
  console.log(`${exists ? '✅' : '❌'} ${file}`);
  if (!exists) allFilesExist = false;
});

if (allFilesExist) {
  console.log('\n✅ All required files exist!');
} else {
  console.log('\n❌ Some files are missing!');
}

// Test 2: Check package.json dependencies
console.log('\n📦 Checking dependencies...');
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const requiredDeps = ['csv-parser', 'xml2js', 'ssh2'];

requiredDeps.forEach(dep => {
  const hasDep = packageJson.dependencies && packageJson.dependencies[dep];
  console.log(`${hasDep ? '✅' : '❌'} ${dep}`);
});

// Test 3: Check if import route is added to server
console.log('\n🔗 Checking server routes...');
const serverContent = fs.readFileSync('src/server.js', 'utf8');
const hasImportRoute = serverContent.includes('importRoutes') && serverContent.includes('/api/import');
console.log(`${hasImportRoute ? '✅' : '❌'} Import routes registered in server`);

// Test 4: Check if import page is added to App.tsx
console.log('\n📱 Checking React routes...');
const appContent = fs.readFileSync('src/App.tsx', 'utf8');
const hasImportPage = appContent.includes('Import') && appContent.includes('/import');
console.log(`${hasImportPage ? '✅' : '❌'} Import page registered in React app`);

console.log('\n🎉 Import system setup complete!');
console.log('\n📋 Next steps:');
console.log('1. Start the server: npm run dev');
console.log('2. Start the frontend: npm run dev:frontend');
console.log('3. Navigate to: http://localhost:8080/import');
console.log('4. Create your first import configuration');
console.log('5. Test the connection and import functionality'); 