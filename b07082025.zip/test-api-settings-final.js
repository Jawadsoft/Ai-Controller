import fetch from 'node-fetch';

async function testApiSettingsFinal() {
  try {
    console.log('🧪 Testing API settings (final verification)...\n');
    
    // Test the API settings endpoint
    const response = await fetch('http://localhost:3000/api/daive/api-settings', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer public'
      }
    });
    
    console.log('📥 Response status:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ API Response received:');
      console.log(JSON.stringify(data, null, 2));
      
      // Check if deepgram_key is present
      if (data.success && data.data) {
        const settings = data.data;
        
        console.log('\n📋 Settings found:');
        Object.keys(settings).forEach(key => {
          const setting = settings[key];
          console.log(`   ${key}: ${setting.value ? setting.value.substring(0, 20) + '...' : 'null'} (${setting.isActive ? 'active' : 'inactive'})`);
        });
        
        // Check specifically for deepgram_key
        if (settings.deepgram_key) {
          console.log('\n✅ SUCCESS: deepgram_key is present in the API response!');
          console.log(`   Value: ${settings.deepgram_key.value.substring(0, 20)}...`);
          console.log(`   Active: ${settings.deepgram_key.isActive}`);
        } else {
          console.log('\n❌ ERROR: deepgram_key is still missing from the API response');
        }
        
        // Check speech_provider
        if (settings.speech_provider) {
          console.log(`\n🎤 Speech provider: ${settings.speech_provider.value}`);
          if (settings.speech_provider.value === 'deepgram') {
            console.log('✅ Speech provider is correctly set to deepgram');
          } else {
            console.log('❌ Speech provider is not set to deepgram');
          }
        }
        
        // Check voice_enabled
        if (settings.voice_enabled) {
          console.log(`\n🔊 Voice enabled: ${settings.voice_enabled.value}`);
          if (settings.voice_enabled.value === 'true') {
            console.log('✅ Voice is enabled');
          } else {
            console.log('❌ Voice is not enabled');
          }
        }
        
        // Overall configuration check
        const hasDeepgramKey = settings.deepgram_key && settings.deepgram_key.isActive;
        const hasSpeechProvider = settings.speech_provider && settings.speech_provider.value === 'deepgram';
        const hasVoiceEnabled = settings.voice_enabled && settings.voice_enabled.value === 'true';
        const hasElevenLabsKey = settings.elevenlabs_key && settings.elevenlabs_key.isActive;
        
        console.log('\n🎯 Configuration Summary:');
        console.log(`   Deepgram Key: ${hasDeepgramKey ? '✅' : '❌'}`);
        console.log(`   Speech Provider (Deepgram): ${hasSpeechProvider ? '✅' : '❌'}`);
        console.log(`   Voice Enabled: ${hasVoiceEnabled ? '✅' : '❌'}`);
        console.log(`   ElevenLabs Key: ${hasElevenLabsKey ? '✅' : '❌'}`);
        
        if (hasDeepgramKey && hasSpeechProvider && hasVoiceEnabled && hasElevenLabsKey) {
          console.log('\n🎉 PERFECT: All voice recognition settings are correctly configured!');
          console.log('   Voice recognition should now work with Deepgram.');
        } else {
          console.log('\n⚠️ Some voice recognition settings are missing or incorrect.');
          console.log('   Please check the DAIVE Settings page to configure missing items.');
        }
        
      } else {
        console.log('❌ Invalid response format');
      }
      
    } else {
      const errorText = await response.text();
      console.error('❌ API request failed:', response.status, response.statusText);
      console.error('Error details:', errorText);
    }
    
  } catch (error) {
    console.error('❌ Error testing API settings:', error);
  }
}

testApiSettingsFinal(); 