import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:password@localhost:5432/vehicle_management'
});

async function testDatabaseInsertion() {
  const client = await pool.connect();
  try {
    console.log('=== TESTING DATABASE INSERTION ===');
    
    // Get the latest import config
    const configsResult = await client.query(`
      SELECT id, dealer_id, config_name 
      FROM import_configs 
      ORDER BY created_at DESC LIMIT 1
    `);
    
    if (configsResult.rows.length === 0) {
      console.log('No import configs found!');
      return;
    }
    
    const config = configsResult.rows[0];
    console.log(`Using config: ${config.config_name} (ID: ${config.id})`);
    console.log(`Config dealer_id: ${config.dealer_id}`);
    
    // Test data (transformed from CSV)
    const testRecord = {
      vin: '2GNAXKEX6J6282582',
      make: 'Chevrolet',
      model: 'Equinox',
      series: 'LT',
      stock_number: 'J6282582',
      body_style: '4D Sport Utility',
      certified: false,
      color: 'Mosaic Black Metallic',
      interior_color: 'Jet Black',
      engine_type: '2.0L Turbocharged',
      displacement: 'R',
      features: 'Confidence & Convenience Package|Driver Confidence Package|Driver Convenience Package|Preferred Equipment Group 2LT|Trailering Equipment|6 Speaker Audio System Feature|6 Speakers|AM/FM radio: SiriusXM|Premium audio system: Chevrolet MyLink|Radio data system|Radio: Chevrolet MyLink AM/FM Stereo|SiriusXM Satellite Radio|USB Port & Auxiliary Input Jack|Air Conditioning|Dual Zone Automatic Climate Control|Rear window defroster|8-Way Power Driver Seat Adjuster|Bluetooth® For Phone|Power driver seat|Power steering|Power windows|Remote keyless entry|Remote Vehicle Starter System|Steering wheel mounted audio controls|Universal Home Remote|Four wheel independent suspension|Speed-sensing steering|Traction control|4-Wheel Antilock 4-Wheel Disc Brakes|4-Wheel Disc Brakes|ABS brakes|Dual front impact airbags|Dual front side impact airbags|Emergency communication system: OnStar and Chevrolet connected services capable|Front anti-roll bar|Low tire pressure warning|Occupant sensing airbag|Overhead airbag|Rear anti-roll bar|Rear Power Liftgate|Brake assist|Electronic Stability Control|Exterior Parking Camera Rear|Delay-off headlights|Fully automatic headlights|High-Intensity Discharge Headlights|Panic alarm|Security system|Speed control|Bumpers: body-color|Dual Stainless-Steel Exhaust w/Bright Tips|Heated door mirrors|Outside Heated Power-Adjustable Mirrors|Power door mirrors|Roof rack: rails only|Spoiler|3-Spoke Leather-Wrapped Steering Wheel|Apple CarPlay/Android Auto|Compass|Driver door bin|Driver vanity mirror|Front reading lights|Illuminated entry|Lane Change Alert w/Side Blind Zone Alert|Leather Shift Knob|Outside temperature display|Overhead console|Passenger vanity mirror|Premium Cloth Seat Trim|Rear Cross Traffic Alert|Rear Park Assist w/Audible Warning|Rear reading lights|Rear seat center armrest|Tachometer|Telescoping steering wheel|Tilt steering wheel|Trip computer|Front Bucket Seats|Front Center Armrest|Front Passenger 4-Way Manual Seat Adjuster|Heated Driver & Front Passenger Seats|Split folding rear seat|Passenger door bin|Body-Color Trailer Hitch Close-Out Cover|Factory Installed Trailer Hitch|18 Aluminum Wheels|Alloy wheels|Rear window wiper|Variably intermittent wipers|3.17 Final Drive Axle Ratio|** Alloy Wheels / Premium Wheels|** Apple CarPlay / Android Auto|** Backup Camera / Parking Sensors|** Bluetooth, Hands-Free|** Brake Assist|** Cruise Control|** Keyless Entry|** Premium Sound System / Premium Audio|** Satellite Radio Capable|** Security System|** Stability Control|** Steering Wheel Controls|** USB Port',
      odometer: 62060,
      price: 16888,
      other_price: 16250,
      transmission: '9-Speed Automatic with Overdrive',
      msrp: null,
      dealer_discount: null,
      consumer_rebate: null,
      dealer_accessories: null,
      total_customer_savings: null,
      total_dealer_rebate: null,
      photo_url_list: 'http://imageonthefly.autodatadirect.com/images/?width=1200&height=900&IMG=CAC80CHS151A01301.jpg',
      year: 2018,
      reference_dealer_id: 'MP7042_ClayCooleyHyundaiofRockwall'
    };
    
    console.log('\n=== TEST RECORD ===');
    console.log('VIN:', testRecord.vin);
    console.log('Make:', testRecord.make);
    console.log('Model:', testRecord.model);
    console.log('Year:', testRecord.year);
    console.log('Odometer:', testRecord.odometer);
    console.log('Price:', testRecord.price);
    
    // Prepare query parameters
    const queryParams = [
      config.dealer_id,                           // p_dealer_id (session dealer ID)
      testRecord.vin,                             // p_vin
      testRecord.make,                            // p_make
      testRecord.model,                           // p_model
      testRecord.series,                          // p_series
      testRecord.stock_number,                    // p_stock_number
      testRecord.body_style,                      // p_body_style
      testRecord.certified,                       // p_certified
      testRecord.color,                           // p_color
      testRecord.interior_color,                  // p_interior_color
      testRecord.engine_type,                     // p_engine_type
      testRecord.displacement,                    // p_displacement
      testRecord.features,                        // p_features
      testRecord.odometer,                        // p_odometer
      testRecord.price,                           // p_price
      testRecord.other_price,                     // p_other_price
      testRecord.transmission,                    // p_transmission
      testRecord.msrp,                            // p_msrp
      testRecord.dealer_discount,                 // p_dealer_discount
      testRecord.consumer_rebate,                 // p_consumer_rebate
      testRecord.dealer_accessories,              // p_dealer_accessories
      testRecord.total_customer_savings,          // p_total_customer_savings
      testRecord.total_dealer_rebate,             // p_total_dealer_rebate
      testRecord.photo_url_list,                  // p_photo_url_list
      testRecord.year,                            // p_year
      testRecord.reference_dealer_id              // p_reference_dealer_id
    ];
    
    console.log('\n=== QUERY PARAMETERS ===');
    const paramNames = [
      'p_dealer_id', 'p_vin', 'p_make', 'p_model', 'p_series', 'p_stock_number', 'p_body_style', 'p_certified',
      'p_color', 'p_interior_color', 'p_engine_type', 'p_displacement', 'p_features', 'p_odometer', 'p_price',
      'p_other_price', 'p_transmission', 'p_msrp', 'p_dealer_discount', 'p_consumer_rebate', 'p_dealer_accessories',
      'p_total_customer_savings', 'p_total_dealer_rebate', 'p_photo_url_list', 'p_year', 'p_reference_dealer_id'
    ];
    queryParams.forEach((param, index) => {
      const paramType = param === null ? 'null' : typeof param;
      const paramValue = param === null ? 'null' : 
                        typeof param === 'string' ? `'${param}'` : 
                        typeof param === 'boolean' ? param.toString() : param;
      console.log(`  ${paramNames[index]}: ${paramValue} (${paramType})`);
    });
    
    // Test the database function
    console.log('\n=== TESTING DATABASE FUNCTION ===');
    try {
      const result = await client.query(`
        SELECT import_vehicle_from_csv(
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26
        ) as vehicle_id
      `, queryParams);
      
      console.log('✅ Database function executed successfully!');
      console.log('Vehicle ID:', result.rows[0]?.vehicle_id);
      
      // Check if the vehicle was inserted
      const checkResult = await client.query(`
        SELECT id, vin, make, model, year, odometer, price 
        FROM vehicles 
        WHERE vin = $1 AND dealer_id = $2
      `, [testRecord.vin, config.dealer_id]);
      
      if (checkResult.rows.length > 0) {
        console.log('✅ Vehicle found in database:');
        console.log('  ID:', checkResult.rows[0].id);
        console.log('  VIN:', checkResult.rows[0].vin);
        console.log('  Make:', checkResult.rows[0].make);
        console.log('  Model:', checkResult.rows[0].model);
        console.log('  Year:', checkResult.rows[0].year);
        console.log('  Odometer:', checkResult.rows[0].odometer);
        console.log('  Price:', checkResult.rows[0].price);
      } else {
        console.log('❌ Vehicle not found in database');
      }
      
    } catch (error) {
      console.error('❌ Database function error:', error.message);
      console.error('Error details:', {
        code: error.code,
        detail: error.detail,
        hint: error.hint,
        where: error.where
      });
    }
    
  } catch (error) {
    console.error('Error testing database insertion:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

testDatabaseInsertion(); 