import fetch from 'node-fetch';

async function testVehicleSpecificChat() {
  try {
    console.log('🧪 Testing Vehicle-Specific D.A.I.V.E. Chat...\n');
    
    // Test with different vehicle IDs to verify specificity
    const testVehicles = [
      {
        id: 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5',
        info: 'Toyota Corolla 2025'
      },
      {
        id: '1f06a092-3eed-43d5-be13-763753e447ce',
        info: 'Suzuki Cultus 2025'
      },
      {
        id: '112f619c-9742-42b9-b48c-447b95f8f3cc',
        info: 'Honda City 2024'
      }
    ];
    
    for (const vehicle of testVehicles) {
      console.log(`\n🚗 Testing vehicle: ${vehicle.info} (ID: ${vehicle.id})`);
      
      const testData = {
        vehicleId: vehicle.id,
        sessionId: 'vehicle_test_' + Date.now() + '_' + vehicle.id.substring(0, 8),
        message: 'I want an ideal car for my family',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com'
        }
      };
      
      try {
        const response = await fetch('http://localhost:3000/api/daive/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(testData),
        });
        
        const data = await response.json();
        
        if (data.success) {
          console.log(`✅ ${vehicle.info}: Success`);
          console.log(`   Response: ${data.data.response.substring(0, 100)}...`);
          console.log(`   Lead Score: ${data.data.leadScore}%`);
          console.log(`   Conversation ID: ${data.data.conversationId}`);
          
          // Test follow-up to verify context is maintained
          const followUpData = {
            ...testData,
            message: 'What safety features does this vehicle have?'
          };
          
          const followUpResponse = await fetch('http://localhost:3000/api/daive/chat', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(followUpData),
          });
          
          const followUpResult = await followUpResponse.json();
          
          if (followUpResult.success) {
            console.log(`   Follow-up: ${followUpResult.data.response.substring(0, 80)}...`);
          }
          
        } else {
          console.log(`❌ ${vehicle.info}: Failed - ${data.error}`);
        }
        
      } catch (error) {
        console.log(`❌ ${vehicle.info}: Error - ${error.message}`);
      }
    }
    
    console.log('\n🎯 Vehicle-specific chat test completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testVehicleSpecificChat(); 