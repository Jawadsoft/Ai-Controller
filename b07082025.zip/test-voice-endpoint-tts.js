import { pool } from './src/database/connection.js';

async function testVoiceEndpointTTS() {
  try {
    console.log('🎤 Testing Voice Endpoint TTS Fix...\n');
    
    const dealerId = '0aa94346-ed1d-420e-8823-bcd97bf6456f'; // From your logs
    console.log(`🏢 Testing with dealer: ${dealerId}`);
    
    // Test the voice endpoint voice_enabled query (now fixed)
    console.log('\n📋 Test 1: Voice Endpoint - Voice Enabled');
    const voiceQuery = `
      WITH dealer_setting AS (
        SELECT setting_value FROM daive_api_settings 
        WHERE dealer_id = $1 AND setting_type = 'voice_enabled'
      ),
      global_setting AS (
        SELECT setting_value FROM daive_api_settings 
        WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
      )
      SELECT setting_value FROM dealer_setting
      UNION ALL
      SELECT setting_value FROM global_setting
      WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
      LIMIT 1
    `;
    
    const voiceResult = await pool.query(voiceQuery, [dealerId]);
    
    if (voiceResult.rows.length > 0 && voiceResult.rows[0].setting_value === 'true') {
      console.log('   ✅ Voice enabled: true');
      
      // Test TTS provider
      console.log('\n🎤 Test 2: Voice Endpoint - TTS Provider');
      const ttsProviderQuery = `
        WITH dealer_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id = $1 AND setting_type = 'voice_tts_provider'
        ),
        global_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id IS NULL AND setting_type = 'voice_tts_provider'
        )
        SELECT setting_value FROM dealer_setting
        UNION ALL
        SELECT setting_value FROM global_setting
        WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
        LIMIT 1
      `;
      
      const ttsResult = await pool.query(ttsProviderQuery, [dealerId]);
      
      if (ttsResult.rows.length > 0) {
        const provider = ttsResult.rows[0].setting_value;
        console.log(`   ✅ TTS Provider: ${provider}`);
        
        // Test API key for provider
        console.log('\n🔑 Test 3: Voice Endpoint - API Key');
        let keyType = provider === 'elevenlabs' ? 'elevenlabs_key' : 
                     provider === 'openai' ? 'openai_key' : 'deepgram_key';
        
        const keyQuery = `
          WITH dealer_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id = $1 AND setting_type = $2
          ),
          global_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id IS NULL AND setting_type = $2
          )
          SELECT setting_value FROM dealer_setting
          UNION ALL
          SELECT setting_value FROM global_setting
          WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
          LIMIT 1
        `;
        
        const keyResult = await pool.query(keyQuery, [dealerId, keyType]);
        
        if (keyResult.rows.length > 0 && keyResult.rows[0].setting_value) {
          const maskedKey = keyResult.rows[0].setting_value.substring(0, 8) + '...' + 
                          keyResult.rows[0].setting_value.substring(keyResult.rows[0].setting_value.length - 4);
          console.log(`   ✅ ${keyType}: ${maskedKey}`);
          
          console.log('\n🎉 Voice Endpoint TTS Should Now Work!');
          console.log('   ✅ Voice enabled: true');
          console.log(`   ✅ TTS provider: ${provider}`);
          console.log(`   ✅ API key: Present`);
          console.log('   ✅ Queries use dealer-specific with global fallback');
          
          console.log('\n🧪 Test Instructions:');
          console.log('   1. Go to AI bot page: http://localhost:8080');
          console.log('   2. Click microphone button and record voice message');
          console.log('   3. Check browser console for "Audio Response: [URL]" instead of "None"');
          console.log('   4. Audio should play automatically after transcription');
          
        } else {
          console.log(`   ❌ Missing ${keyType} - voice TTS will not work`);
        }
      } else {
        console.log('   ❌ No TTS provider configured');
      }
    } else {
      console.log('   ❌ Voice not enabled');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testVoiceEndpointTTS();