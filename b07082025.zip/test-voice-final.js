import { pool } from './src/database/connection.js';

async function testVoiceFinal() {
  try {
    console.log('🎉 Final Voice TTS Test - Complete Fix Verification...\n');
    
    const dealerId = '0aa94346-ed1d-420e-8823-bcd97bf6456f';
    console.log(`🏢 Testing with dealer: ${dealerId}`);
    
    // Test all critical TTS queries that should now work
    const tests = [
      {
        name: 'Voice Enabled',
        query: `
          WITH dealer_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id = $1 AND setting_type = 'voice_enabled'
          ),
          global_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
          )
          SELECT setting_value FROM dealer_setting
          UNION ALL
          SELECT setting_value FROM global_setting
          WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
          LIMIT 1
        `,
        expected: 'true'
      },
      {
        name: 'TTS Provider',
        query: `
          WITH dealer_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id = $1 AND setting_type = 'voice_tts_provider'
          ),
          global_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id IS NULL AND setting_type = 'voice_tts_provider'
          )
          SELECT setting_value FROM dealer_setting
          UNION ALL
          SELECT setting_value FROM global_setting
          WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
          LIMIT 1
        `,
        expected: 'elevenlabs'
      },
      {
        name: 'ElevenLabs API Key',
        query: `
          WITH dealer_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id = $1 AND setting_type = 'elevenlabs_key'
          ),
          global_setting AS (
            SELECT setting_value FROM daive_api_settings 
            WHERE dealer_id IS NULL AND setting_type = 'elevenlabs_key'
          )
          SELECT setting_value FROM dealer_setting
          UNION ALL
          SELECT setting_value FROM global_setting
          WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
          LIMIT 1
        `,
        expected: 'present'
      }
    ];
    
    let allTestsPassed = true;
    
    for (const test of tests) {
      console.log(`\n🧪 Testing: ${test.name}`);
      
      const result = await pool.query(test.query, [dealerId]);
      
      if (result.rows.length > 0) {
        const value = result.rows[0].setting_value;
        
        if (test.expected === 'present') {
          if (value && value.length > 0) {
            const maskedValue = value.substring(0, 8) + '...' + value.substring(value.length - 4);
            console.log(`   ✅ ${test.name}: ${maskedValue}`);
          } else {
            console.log(`   ❌ ${test.name}: Missing`);
            allTestsPassed = false;
          }
        } else if (value === test.expected) {
          console.log(`   ✅ ${test.name}: ${value}`);
        } else {
          console.log(`   ❌ ${test.name}: ${value} (expected: ${test.expected})`);
          allTestsPassed = false;
        }
      } else {
        console.log(`   ❌ ${test.name}: No result found`);
        allTestsPassed = false;
      }
    }
    
    if (allTestsPassed) {
      console.log('\n🎉 ALL VOICE TTS TESTS PASSED!');
      console.log('   ✅ Voice is enabled');
      console.log('   ✅ TTS provider is configured (ElevenLabs)');
      console.log('   ✅ API key is present');
      console.log('   ✅ All queries use dealer-specific with global fallback');
      console.log('   ✅ Both chat and voice endpoints are fixed');
      
      console.log('\n🧪 FINAL TEST INSTRUCTIONS:');
      console.log('   1. Go to AI bot page: http://localhost:8080');
      console.log('   2. Click microphone button 🎤');
      console.log('   3. Record a voice message (e.g., "Hello, can you hear me?")');
      console.log('   4. Watch browser console for:');
      console.log('      🔊 Audio Response: /uploads/daive-audio/response-[timestamp].mp3');
      console.log('      (Instead of "🔊 Audio Response: None")');
      console.log('   5. Audio should play automatically');
      
      console.log('\n💡 What should happen now:');
      console.log('   📝 Voice transcription: ✅ Working');
      console.log('   🤖 AI text response: ✅ Working');
      console.log('   🔊 TTS audio generation: ✅ Should now work');
      console.log('   🎵 Audio playback: ✅ Should now work');
      
    } else {
      console.log('\n❌ Some tests failed - TTS may still not work');
    }
    
    console.log('\n🔍 If still not working:');
    console.log('   1. Check backend terminal for TTS generation logs');
    console.log('   2. Check if uploads/daive-audio/ directory exists');
    console.log('   3. Verify ElevenLabs API key is valid');
    console.log('   4. Check browser network tab for audio file requests');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testVoiceFinal();