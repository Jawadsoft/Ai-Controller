import fetch from 'node-fetch';

async function testAlternativeVehicles() {
  try {
    console.log('🧪 Testing D.A.I.V.E. Alternative Vehicles Feature...\n');
    
    const testVehicleId = 'fe21b82a-5e3b-46e4-a51d-0f6806a46cc5'; // Toyota Corolla
    const sessionId = 'alt_test_' + Date.now();
    
    // Test 1: Ask for alternatives
    console.log('1️⃣ Testing alternative vehicles request...');
    const alternativeRequest = {
      vehicleId: testVehicleId,
      sessionId: sessionId,
      message: 'Show me other vehicles from this dealer',
      customerInfo: {
        name: 'Test Customer',
        email: 'test@example.com'
      }
    };
    
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(alternativeRequest),
    });
    
    const data = await response.json();
    
    if (data.success) {
      console.log('✅ Alternative vehicles request successful!');
      console.log('Response:', data.data.response);
      console.log('Lead Score:', data.data.leadScore + '%');
      
      // Test 2: Ask with different phrasing
      console.log('\n2️⃣ Testing different alternative request phrases...');
      
      const alternativePhrases = [
        'Do you have any other options?',
        'Show me more vehicles',
        'What else do you have available?',
        'I want to see alternatives',
        'Compare with other vehicles'
      ];
      
      for (const phrase of alternativePhrases) {
        const altRequest = {
          ...alternativeRequest,
          message: phrase,
          sessionId: 'alt_test_' + Date.now() + '_' + phrase.substring(0, 10)
        };
        
        const altResponse = await fetch('http://localhost:3000/api/daive/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(altRequest),
        });
        
        const altData = await altResponse.json();
        
        if (altData.success) {
          console.log(`✅ "${phrase}" - Success`);
          console.log(`   Response includes alternatives: ${altData.data.response.includes('other great options') ? 'Yes' : 'No'}`);
        } else {
          console.log(`❌ "${phrase}" - Failed: ${altData.error}`);
        }
      }
      
      // Test 3: Test with a vehicle that might not have alternatives
      console.log('\n3️⃣ Testing with different vehicle...');
      const differentVehicleId = '1f06a092-3eed-43d5-be13-763753e447ce'; // Suzuki Cultus
      
      const diffRequest = {
        vehicleId: differentVehicleId,
        sessionId: 'alt_test_diff_' + Date.now(),
        message: 'Show me other vehicles from this dealer',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com'
        }
      };
      
      const diffResponse = await fetch('http://localhost:3000/api/daive/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(diffRequest),
      });
      
      const diffData = await diffResponse.json();
      
      if (diffData.success) {
        console.log('✅ Different vehicle test successful!');
        console.log('Response:', diffData.data.response.substring(0, 200) + '...');
      } else {
        console.log('❌ Different vehicle test failed:', diffData.error);
      }
      
    } else {
      console.log('❌ Alternative vehicles request failed:', data.error);
    }
    
    console.log('\n🎯 Alternative vehicles feature test completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testAlternativeVehicles(); 