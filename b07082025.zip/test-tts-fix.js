import { pool } from './src/database/connection.js';

async function testTTSFix() {
  try {
    console.log('🧪 Testing TTS Fix...\n');
    
    // Test 1: Simulate the TTS query with dealer ID
    console.log('📋 Test 1: Testing TTS Query with Dealer ID');
    
    // Get a dealer that has voice settings
    const dealerQuery = `
      SELECT DISTINCT dealer_id 
      FROM daive_api_settings 
      WHERE dealer_id IS NOT NULL AND setting_type = 'voice_enabled'
      LIMIT 1
    `;
    
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length > 0) {
      const dealerId = dealerResult.rows[0].dealer_id;
      console.log(`✅ Testing with dealer ID: ${dealerId}`);
      
      // Test voice_enabled query (this is what TTS code now uses)
      const voiceQuery = `
        WITH dealer_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id = $1 AND setting_type = 'voice_enabled'
        ),
        global_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
        )
        SELECT setting_value FROM dealer_setting
        UNION ALL
        SELECT setting_value FROM global_setting
        WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
        LIMIT 1
      `;
      
      const voiceResult = await pool.query(voiceQuery, [dealerId]);
      
      if (voiceResult.rows.length > 0) {
        console.log(`   ✅ voice_enabled: ${voiceResult.rows[0].setting_value}`);
        
        if (voiceResult.rows[0].setting_value === 'true') {
          console.log('   🎉 Voice is enabled! TTS should work now.');
          
          // Test TTS provider query
          const ttsProviderQuery = `
            WITH dealer_setting AS (
              SELECT setting_value FROM daive_api_settings 
              WHERE dealer_id = $1 AND setting_type = 'voice_tts_provider'
            ),
            global_setting AS (
              SELECT setting_value FROM daive_api_settings 
              WHERE dealer_id IS NULL AND setting_type = 'voice_tts_provider'
            )
            SELECT setting_value FROM dealer_setting
            UNION ALL
            SELECT setting_value FROM global_setting
            WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
            LIMIT 1
          `;
          
          const ttsResult = await pool.query(ttsProviderQuery, [dealerId]);
          
          if (ttsResult.rows.length > 0) {
            const provider = ttsResult.rows[0].setting_value;
            console.log(`   ✅ TTS Provider: ${provider}`);
            
            // Test API key for the provider
            let keyType = '';
            if (provider === 'elevenlabs') keyType = 'elevenlabs_key';
            else if (provider === 'openai') keyType = 'openai_key';
            else if (provider === 'deepgram') keyType = 'deepgram_key';
            
            if (keyType) {
              const keyQuery = `
                WITH dealer_setting AS (
                  SELECT setting_value FROM daive_api_settings 
                  WHERE dealer_id = $1 AND setting_type = $2
                ),
                global_setting AS (
                  SELECT setting_value FROM daive_api_settings 
                  WHERE dealer_id IS NULL AND setting_type = $2
                )
                SELECT setting_value FROM dealer_setting
                UNION ALL
                SELECT setting_value FROM global_setting
                WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
                LIMIT 1
              `;
              
              const keyResult = await pool.query(keyQuery, [dealerId, keyType]);
              
              if (keyResult.rows.length > 0 && keyResult.rows[0].setting_value) {
                const maskedKey = keyResult.rows[0].setting_value.substring(0, 8) + '...' + 
                                keyResult.rows[0].setting_value.substring(keyResult.rows[0].setting_value.length - 4);
                console.log(`   ✅ API Key (${keyType}): ${maskedKey}`);
                console.log('\n🎉 TTS Configuration Complete!');
                console.log('   ✅ Voice enabled: true');
                console.log(`   ✅ TTS provider: ${provider}`);
                console.log(`   ✅ API key: Present`);
                console.log('\n💡 TTS should now work on the AI bot page!');
              } else {
                console.log(`   ❌ Missing API key for ${provider}`);
              }
            }
          } else {
            console.log('   ❌ No TTS provider configured');
          }
        } else {
          console.log('   ❌ Voice is disabled');
        }
      } else {
        console.log('   ❌ No voice_enabled setting found');
      }
    } else {
      console.log('❌ No dealers with voice settings found');
    }
    
    console.log('\n📝 TTS Troubleshooting Checklist:');
    console.log('   1. ✅ Fixed TTS queries to use dealer-specific settings');
    console.log('   2. ✅ Verified dealer has voice_enabled = true');
    console.log('   3. ✅ Verified TTS provider is configured');
    console.log('   4. ✅ Verified API key is present');
    console.log('\n🎯 Next: Test on AI bot page by sending a text message');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testTTSFix();