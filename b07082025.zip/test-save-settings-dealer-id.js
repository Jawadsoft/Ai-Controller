import { pool } from './src/database/connection.js';

async function testSaveSettingsDealerId() {
  try {
    console.log('🔍 Testing How dealer_id is Saved in API and Voice Settings...\n');
    
    // Check current state before testing
    console.log('📊 Current Settings in Database:');
    const currentQuery = `
      SELECT setting_type, setting_value, dealer_id,
             CASE 
               WHEN dealer_id IS NULL THEN 'Global'
               ELSE 'Dealer-Specific'
             END as scope
      FROM daive_api_settings
      ORDER BY scope, setting_type
    `;
    
    const currentResult = await pool.query(currentQuery);
    
    let currentScope = '';
    currentResult.rows.forEach(row => {
      if (row.scope !== currentScope) {
        currentScope = row.scope;
        console.log(`\n   ${currentScope}:`);
      }
      const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
        row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
        row.setting_value;
      console.log(`     ${row.setting_type}: ${maskedValue}`);
    });
    
    // Test API Settings Save Behavior
    console.log('\n🔧 Testing API Settings Save Behavior:');
    console.log('Current implementation: dealer_id = NULL (global) regardless of user context');
    
    // Simulate what happens when API settings are saved
    const apiSettingQuery = `
      INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
      VALUES (NULL, $1, $2)
      ON CONFLICT (dealer_id, setting_type) 
      DO UPDATE SET setting_value = $2, updated_at = NOW()
      RETURNING dealer_id, setting_type, setting_value
    `;
    
    const apiResult = await pool.query(apiSettingQuery, ['test_api_setting', 'test_value_123']);
    console.log('✅ API Setting Saved:');
    console.log(`   dealer_id: ${apiResult.rows[0].dealer_id || 'NULL (Global)'}`);
    console.log(`   setting_type: ${apiResult.rows[0].setting_type}`);
    console.log(`   setting_value: ${apiResult.rows[0].setting_value}`);
    
    // Test Voice Settings Save Behavior
    console.log('\n🎵 Testing Voice Settings Save Behavior:');
    console.log('Current implementation: Also saves with dealer_id = NULL despite checking req.user.dealer_id');
    
    // Simulate what happens when voice settings are saved
    const voiceSettingQuery = `
      INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
      VALUES (NULL, $1, $2)
      ON CONFLICT (dealer_id, setting_type) 
      DO UPDATE SET setting_value = $2, updated_at = NOW()
      RETURNING dealer_id, setting_type, setting_value
    `;
    
    const voiceResult = await pool.query(voiceSettingQuery, ['test_voice_setting', 'test_voice_value']);
    console.log('✅ Voice Setting Saved:');
    console.log(`   dealer_id: ${voiceResult.rows[0].dealer_id || 'NULL (Global)'}`);
    console.log(`   setting_type: ${voiceResult.rows[0].setting_type}`);
    console.log(`   setting_value: ${voiceResult.rows[0].setting_value}`);
    
    // Show what dealer-specific saving would look like
    console.log('\n🏢 Demonstrating Dealer-Specific Saving:');
    
    const dealerQuery = 'SELECT id, business_name FROM dealers LIMIT 1';
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length > 0) {
      const testDealerId = dealerResult.rows[0].id;
      const businessName = dealerResult.rows[0].business_name;
      
      console.log(`Using dealer: ${businessName} (ID: ${testDealerId})`);
      
      // Save with actual dealer_id
      const dealerSpecificQuery = `
        INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
        VALUES ($1, $2, $3)
        ON CONFLICT (dealer_id, setting_type) 
        DO UPDATE SET setting_value = $3, updated_at = NOW()
        RETURNING dealer_id, setting_type, setting_value
      `;
      
      const dealerApiResult = await pool.query(dealerSpecificQuery, [testDealerId, 'dealer_specific_openai_key', 'sk-dealer-specific-key']);
      console.log('✅ Dealer-Specific API Setting Saved:');
      console.log(`   dealer_id: ${dealerApiResult.rows[0].dealer_id}`);
      console.log(`   setting_type: ${dealerApiResult.rows[0].setting_type}`);
      console.log(`   setting_value: ${dealerApiResult.rows[0].setting_value.substring(0, 15)}...`);
      
      const dealerVoiceResult = await pool.query(dealerSpecificQuery, [testDealerId, 'dealer_voice_provider', 'elevenlabs_custom']);
      console.log('✅ Dealer-Specific Voice Setting Saved:');
      console.log(`   dealer_id: ${dealerVoiceResult.rows[0].dealer_id}`);
      console.log(`   setting_type: ${dealerVoiceResult.rows[0].setting_type}`);
      console.log(`   setting_value: ${dealerVoiceResult.rows[0].setting_value}`);
      
      // Clean up test data
      await pool.query('DELETE FROM daive_api_settings WHERE setting_type IN ($1, $2, $3, $4)', 
        ['test_api_setting', 'test_voice_setting', 'dealer_specific_openai_key', 'dealer_voice_provider']);
      console.log('\n🧹 Cleaned up test data');
    }
    
    console.log('\n📝 Key Findings:');
    console.log('   ❌ API settings always save with dealer_id = NULL (global)');
    console.log('   ❌ Voice settings also save with dealer_id = NULL despite dealer context check');
    console.log('   ✅ Database supports dealer-specific settings (dealer_id column exists)');
    console.log('   ✅ The "dealer_id" setting we added is just a global configuration value');
    console.log('   💡 To make settings truly dealer-specific, modify the save queries to use req.user.dealer_id');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

// Run the test
testSaveSettingsDealerId();