import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';
const TEST_TOKEN = 'your-test-token-here'; // Replace with actual token

async function testApiSettings() {
  console.log('Testing API Settings functionality...\n');

  try {
    // Test saving API settings
    console.log('1. Testing API settings save...');
    const saveResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TEST_TOKEN}`
      },
      body: JSON.stringify({
        settingType: 'openai_key',
        settingValue: 'sk-test-key-123456789'
      })
    });

    const saveData = await saveResponse.json();
    console.log('Save response:', saveData);

    // Test getting API settings
    console.log('\n2. Testing API settings retrieval...');
    const getResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      headers: {
        'Authorization': `Bearer ${TEST_TOKEN}`
      }
    });

    const getData = await getResponse.json();
    console.log('Get response:', getData);

    // Test API connection test
    console.log('\n3. Testing API connection test...');
    const testResponse = await fetch(`${BASE_URL}/api/daive/test-api`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TEST_TOKEN}`
      },
      body: JSON.stringify({
        apiType: 'openai'
      })
    });

    const testData = await testResponse.json();
    console.log('Test response:', testData);

    console.log('\n✅ API Settings tests completed!');

  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

testApiSettings(); 