import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testDeepgramConnection() {
  try {
    console.log('🧪 Testing Deepgram API Connection...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Get the Deepgram API key
    console.log('\n2. Getting Deepgram API key...');
    const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const apiSettingsData = await apiSettingsResponse.json();
    const deepgramKey = apiSettingsData.data.deepgram_key?.value;
    
    if (!deepgramKey) {
      console.log('❌ No Deepgram API key found!');
      return;
    }

    console.log('✅ Deepgram API key found');
    console.log('🔑 Key:', deepgramKey.substring(0, 10) + '...');

    // Test Deepgram API directly
    console.log('\n3. Testing Deepgram API directly...');
    
    // Test the speak endpoint
    const testText = 'Hello, this is a test of Deepgram text-to-speech.';
    console.log('📝 Test text:', testText);
    
    const deepgramResponse = await fetch('https://api.deepgram.com/v1/speak', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${deepgramKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        text: testText,
        model: 'aura-asteria',
        voice: 'asteria',
        encoding: 'mp3',
        container: 'mp3',
        sample_rate: 24000
      })
    });

    console.log('📊 Deepgram API Response Status:', deepgramResponse.status);
    console.log('📊 Deepgram API Response Headers:', Object.fromEntries(deepgramResponse.headers.entries()));

    if (deepgramResponse.ok) {
      const audioBuffer = await deepgramResponse.arrayBuffer();
      console.log('✅ Deepgram API call successful!');
      console.log('🔊 Audio buffer size:', audioBuffer.byteLength, 'bytes');
      
      // Save the test audio file
      const fs = await import('fs');
      const testAudioPath = './test-deepgram-output.mp3';
      fs.writeFileSync(testAudioPath, Buffer.from(audioBuffer));
      console.log('💾 Test audio saved to:', testAudioPath);
      
    } else {
      const errorText = await deepgramResponse.text();
      console.log('❌ Deepgram API call failed!');
      console.log('📊 Error Status:', deepgramResponse.status);
      console.log('📊 Error Response:', errorText);
    }

    // Test the voices endpoint
    console.log('\n4. Testing Deepgram voices endpoint...');
    const voicesResponse = await fetch('https://api.deepgram.com/v1/speak/voices', {
      headers: {
        'Authorization': `Token ${deepgramKey}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('📊 Voices API Response Status:', voicesResponse.status);
    
    if (voicesResponse.ok) {
      const voicesData = await voicesResponse.json();
      console.log('✅ Voices API call successful!');
      console.log('🎭 Available voices:', voicesData.voices?.length || 0);
    } else {
      const errorText = await voicesResponse.text();
      console.log('❌ Voices API call failed!');
      console.log('📊 Error Response:', errorText);
    }

  } catch (error) {
    console.error('❌ Error testing Deepgram connection:', error);
  }
}

// Run the test
testDeepgramConnection(); 