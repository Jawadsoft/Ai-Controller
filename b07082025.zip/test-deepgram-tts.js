import DeepgramTTSService from './src/lib/deepgram-tts.js';
import fs from 'fs';
import path from 'path';

async function testDeepgramTTS() {
  try {
    console.log('🎤 Testing Deepgram TTS...\n');
    
    const apiKey = process.env.DEEPGRAM_API_KEY;
    if (!apiKey) {
      console.error('❌ DEEPGRAM_API_KEY environment variable is required');
      process.exit(1);
    }
    
    const deepgramTTS = new DeepgramTTSService(apiKey);
    
    // Test 1: Test connection
    console.log('1. Testing Deepgram TTS connection...');
    const connectionResult = await deepgramTTS.testConnection();
    
    if (connectionResult.success) {
      console.log('✅ Deepgram TTS connection successful');
    } else {
      console.log('❌ Deepgram TTS connection failed:', connectionResult.error);
      return;
    }
    
    // Test 2: Get available voices
    console.log('\n2. Getting available voices...');
    const voicesResult = await deepgramTTS.getAvailableVoices();
    
    if (voicesResult.success) {
      console.log('✅ Available voices:', voicesResult.voices);
    } else {
      console.log('❌ Failed to get voices:', voicesResult.error);
    }
    
    // Test 3: Get available models
    console.log('\n3. Getting available models...');
    const modelsResult = await deepgramTTS.getAvailableModels();
    
    if (modelsResult.success) {
      console.log('✅ Available models:', modelsResult.models);
    } else {
      console.log('❌ Failed to get models:', modelsResult.error);
    }
    
    // Test 4: Synthesize speech
    console.log('\n4. Testing speech synthesis...');
    const testText = "Hello! I'm D.A.I.V.E., your AI vehicle assistant. How can I help you today?";
    
    const synthesisResult = await deepgramTTS.synthesizeSpeech(testText, {
      model: 'aura-asteria',
      voice: 'asteria',
      encoding: 'mp3',
      container: 'mp3',
      sample_rate: 24000
    });
    
    if (synthesisResult.success) {
      console.log('✅ Speech synthesis successful');
      console.log('📊 Audio format:', synthesisResult.format);
      console.log('📊 Sample rate:', synthesisResult.sampleRate);
      console.log('📊 Audio buffer size:', synthesisResult.audioBuffer.length, 'bytes');
      
      // Save the audio file
      const audioFileName = `deepgram-tts-test-${Date.now()}.mp3`;
      const audioPath = path.join(process.cwd(), audioFileName);
      
      const saved = await deepgramTTS.saveToFile(synthesisResult.audioBuffer, audioPath);
      
      if (saved) {
        console.log('✅ Audio saved to:', audioFileName);
        console.log('🎵 You can play this file to hear the synthesized speech');
      } else {
        console.log('❌ Failed to save audio file');
      }
    } else {
      console.log('❌ Speech synthesis failed:', synthesisResult.error);
    }
    
    console.log('\n🎉 Deepgram TTS test completed!');
    
  } catch (error) {
    console.error('❌ Error testing Deepgram TTS:', error);
  }
}

testDeepgramTTS(); 