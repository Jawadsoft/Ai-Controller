const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

// Test TTS integration for both chat and voice endpoints
async function testTTSChatEndpoint() {
  console.log('🧪 Testing TTS in Chat Endpoint...');
  
  try {
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicleId: 'test-vehicle-id',
        sessionId: 'test-session-' + Date.now(),
        message: 'What are the safety features of this vehicle?',
        customerInfo: {
          name: 'Test User',
          email: 'test@example.com',
          dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
        }
      }),
    });

    const data = await response.json();
    console.log('📥 Chat Response Status:', response.status);
    console.log('📥 Chat Response Data:', {
      success: data.success,
      hasResponse: !!data.data?.response,
      hasAudioUrl: !!data.data?.audioResponseUrl,
      audioUrl: data.data?.audioResponseUrl,
      responseLength: data.data?.response?.length || 0
    });

    if (data.success && data.data.audioResponseUrl) {
      console.log('✅ TTS working in chat endpoint!');
      console.log('🔊 Audio URL:', data.data.audioResponseUrl);
    } else {
      console.log('⚠️ TTS not working in chat endpoint');
      console.log('🔍 Response:', data.data?.response?.substring(0, 100) + '...');
    }
  } catch (error) {
    console.error('❌ Error testing chat endpoint:', error);
  }
}

async function testTTSVoiceEndpoint() {
  console.log('🧪 Testing TTS in Voice Endpoint...');
  
  try {
    // Create a simple test audio file (1 second of silence)
    const testAudioPath = './test-audio.wav';
    const testAudioBuffer = Buffer.alloc(44 + 16000 * 2); // 1 second of 16kHz audio
    
    // Write WAV header
    testAudioBuffer.write('RIFF', 0);
    testAudioBuffer.writeUInt32LE(36 + 16000 * 2, 4);
    testAudioBuffer.write('WAVE', 8);
    testAudioBuffer.write('fmt ', 12);
    testAudioBuffer.writeUInt32LE(16, 16);
    testAudioBuffer.writeUInt16LE(1, 20);
    testAudioBuffer.writeUInt16LE(1, 22);
    testAudioBuffer.writeUInt32LE(16000, 24);
    testAudioBuffer.writeUInt32LE(32000, 28);
    testAudioBuffer.writeUInt16LE(2, 32);
    testAudioBuffer.writeUInt16LE(16, 34);
    testAudioBuffer.write('data', 36);
    testAudioBuffer.writeUInt32LE(16000 * 2, 40);
    
    fs.writeFileSync(testAudioPath, testAudioBuffer);

    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath), 'test-audio.wav');
    formData.append('vehicleId', 'test-vehicle-id');
    formData.append('sessionId', 'test-session-' + Date.now());
    formData.append('customerInfo', JSON.stringify({
      name: 'Test User',
      email: 'test@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }));

    const response = await fetch('http://localhost:3000/api/daive/voice', {
      method: 'POST',
      body: formData
    });

    const data = await response.json();
    console.log('📥 Voice Response Status:', response.status);
    console.log('📥 Voice Response Data:', {
      success: data.success,
      hasTranscription: !!data.data?.transcription,
      hasResponse: !!data.data?.response,
      hasAudioUrl: !!data.data?.audioResponseUrl,
      audioUrl: data.data?.audioResponseUrl,
      transcription: data.data?.transcription,
      responseLength: data.data?.response?.length || 0
    });

    if (data.success && data.data.audioResponseUrl) {
      console.log('✅ TTS working in voice endpoint!');
      console.log('🔊 Audio URL:', data.data.audioResponseUrl);
    } else {
      console.log('⚠️ TTS not working in voice endpoint');
      console.log('🔍 Response:', data.data?.response?.substring(0, 100) + '...');
    }

    // Clean up test file
    fs.unlinkSync(testAudioPath);
  } catch (error) {
    console.error('❌ Error testing voice endpoint:', error);
  }
}

async function runTests() {
  console.log('🚀 Starting TTS Integration Tests...\n');
  
  await testTTSChatEndpoint();
  console.log('');
  await testTTSVoiceEndpoint();
  
  console.log('\n✅ TTS Integration Tests Completed!');
}

// Run tests if this file is executed directly
if (require.main === module) {
  runTests().catch(console.error);
}

module.exports = { testTTSChatEndpoint, testTTSVoiceEndpoint }; 