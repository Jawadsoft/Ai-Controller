import { pool } from './src/database/connection.js';

async function testFetchSimple() {
  try {
    console.log('🔍 Simple Test: DAIVE Settings Fetch Behavior\n');
    
    // Test 1: Current API Settings Fetch
    console.log('📋 API Settings Fetch:');
    const apiQuery = `
      SELECT setting_type, setting_value, dealer_id
      FROM daive_api_settings
      WHERE dealer_id IS NULL
      ORDER BY setting_type
    `;
    
    const apiResult = await pool.query(apiQuery);
    console.log(`   Current fetch finds: ${apiResult.rows.length} GLOBAL settings only`);
    console.log('   ❌ Ignores all dealer-specific settings');
    
    // Test 2: Current Voice Settings Fetch  
    console.log('\n🎵 Voice Settings Fetch:');
    const voiceQuery = `
      SELECT setting_type, setting_value, dealer_id
      FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type LIKE 'voice_%'
    `;
    
    const voiceResult = await pool.query(voiceQuery);
    console.log(`   Current fetch finds: ${voiceResult.rows.length} GLOBAL voice settings only`);
    console.log('   ❌ Ignores all dealer-specific voice settings');
    
    // Test 3: Check if dealer-specific settings exist
    console.log('\n🏢 Dealer-Specific Settings Check:');
    const dealerSettingsQuery = `
      SELECT COUNT(*) as count, COUNT(DISTINCT dealer_id) as dealers
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL
    `;
    
    const dealerSettingsResult = await pool.query(dealerSettingsQuery);
    const count = dealerSettingsResult.rows[0].count;
    const dealers = dealerSettingsResult.rows[0].dealers;
    
    if (count > 0) {
      console.log(`   ✅ Found ${count} dealer-specific settings for ${dealers} dealers`);
      console.log('   ❌ But current fetch endpoints ignore them all');
    } else {
      console.log('   ❌ No dealer-specific settings found');
    }
    
    console.log('\n📝 Summary:');
    console.log('   ❌ DAIVE settings fetch is NOT dealer_id wise');
    console.log('   ❌ Both API and Voice settings fetch only global settings');
    console.log('   ❌ No authentication or dealer context in GET endpoints');
    console.log('   💡 All dealers see the same global settings');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testFetchSimple();