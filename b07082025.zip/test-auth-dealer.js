import jwt from 'jsonwebtoken';
import { pool } from './src/database/connection.js';
import dotenv from 'dotenv';

dotenv.config();

async function testAuth() {
  try {
    console.log('🔐 Testing authentication with dealer_id...\n');
    
    // Get a dealer user
    const userResult = await pool.query(`
      SELECT u.*, ur.role, d.id as dealer_id 
      FROM users u 
      LEFT JOIN user_roles ur ON u.id = ur.user_id 
      LEFT JOIN dealers d ON u.id = d.user_id 
      WHERE ur.role = 'dealer' 
      LIMIT 1
    `);
    
    if (userResult.rows.length === 0) {
      console.log('❌ No dealer users found');
      return;
    }
    
    const user = userResult.rows[0];
    console.log('👤 Found dealer user:');
    console.log(`   Email: ${user.email}`);
    console.log(`   Role: ${user.role}`);
    console.log(`   Dealer ID: ${user.dealer_id}`);
    console.log('');
    
    // Generate a JWT token
    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );
    
    console.log('🎫 Generated JWT token:');
    console.log(`   Token: ${token.substring(0, 50)}...`);
    console.log('');
    
    // Test the authentication middleware logic
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    console.log('🔍 Decoded token:');
    console.log(`   User ID: ${decoded.userId}`);
    console.log('');
    
    // Test the query that the middleware uses
    const authResult = await pool.query(
      'SELECT u.*, ur.role, d.id as dealer_id FROM users u LEFT JOIN user_roles ur ON u.id = ur.user_id LEFT JOIN dealers d ON u.id = d.user_id WHERE u.id = $1',
      [decoded.userId]
    );
    
    if (authResult.rows.length > 0) {
      const authUser = authResult.rows[0];
      console.log('✅ Authentication test successful:');
      console.log(`   User ID: ${authUser.id}`);
      console.log(`   Email: ${authUser.email}`);
      console.log(`   Role: ${authUser.role}`);
      console.log(`   Dealer ID: ${authUser.dealer_id}`);
      console.log('');
      
      if (authUser.dealer_id) {
        console.log('🎉 dealer_id is properly included in user object!');
      } else {
        console.log('⚠️  dealer_id is missing from user object');
      }
    } else {
      console.log('❌ Authentication test failed - user not found');
    }
    
  } catch (error) {
    console.error('Error testing auth:', error);
  } finally {
    await pool.end();
  }
}

testAuth(); 