import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';

async function testDeepgramTTSAudio() {
  try {
    console.log('🧪 Testing Deepgram TTS Audio Response...\n');

    // First, get a valid auth token
    console.log('1. Getting auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'dealer1@example.com',
        password: 'dealeriq'
      }),
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful, got token');

    // Check if Deepgram API key is configured
    console.log('\n2. Checking Deepgram API key...');
    const apiSettingsResponse = await fetch(`${BASE_URL}/api/daive/api-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const apiSettingsData = await apiSettingsResponse.json();
    console.log('📋 API Settings Response:');
    console.log(JSON.stringify(apiSettingsData, null, 2));

    if (apiSettingsData.success) {
      const settings = apiSettingsData.data;
      const deepgramKey = settings.deepgram_key?.value || '';
      
      if (deepgramKey) {
        console.log('✅ Deepgram API key is configured');
        console.log('🔑 Key length:', deepgramKey.length);
      } else {
        console.log('❌ No Deepgram API key found!');
        console.log('💡 Please configure your Deepgram API key in the DAIVE Settings → API Keys tab');
        return;
      }
    } else {
      console.log('❌ Failed to get API settings');
      return;
    }

    // Check current voice settings
    console.log('\n3. Checking voice settings...');
    const voiceSettingsResponse = await fetch(`${BASE_URL}/api/daive/voice-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const voiceSettingsData = await voiceSettingsResponse.json();
    console.log('📋 Voice Settings:');
    console.log(JSON.stringify(voiceSettingsData, null, 2));

    if (voiceSettingsData.success) {
      const voiceSettings = voiceSettingsData.data;
      console.log('\n🔍 Voice Configuration:');
      console.log(`- Voice Provider: ${voiceSettings.voiceProvider}`);
      console.log(`- TTS Provider: ${voiceSettings.ttsProvider}`);
      console.log(`- Speech Provider: ${voiceSettings.speechProvider}`);
      console.log(`- Voice Enabled: ${voiceSettings.enabled}`);

      if (voiceSettings.ttsProvider !== 'deepgram') {
        console.log('\n⚠️ TTS Provider is not set to Deepgram!');
        console.log('💡 Please set TTS Provider to Deepgram in Voice Settings');
        return;
      }

      if (!voiceSettings.enabled) {
        console.log('\n⚠️ Voice responses are not enabled!');
        console.log('💡 Please enable voice responses in Voice Settings');
        return;
      }
    }

    // Test Deepgram TTS directly
    console.log('\n4. Testing Deepgram TTS directly...');
    const testTTSResponse = await fetch(`${BASE_URL}/api/daive/test-api`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ apiType: 'deepgram' })
    });

    const testTTSData = await testTTSResponse.json();
    console.log('📋 TTS Test Response:');
    console.log(JSON.stringify(testTTSData, null, 2));

    // Test voice conversation endpoint
    console.log('\n5. Testing voice conversation with Deepgram TTS...');
    const testVoiceResponse = await fetch(`${BASE_URL}/api/daive/voice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        vehicleId: 'test-vehicle-123',
        sessionId: 'test-session-456',
        message: 'Hello, can you tell me about this vehicle?',
        customerInfo: {
          name: 'Test Customer',
          email: 'test@example.com'
        }
      })
    });

    const testVoiceData = await testVoiceResponse.json();
    console.log('📋 Voice Conversation Response:');
    console.log(JSON.stringify(testVoiceData, null, 2));

    if (testVoiceData.success && testVoiceData.audioResponseUrl) {
      console.log('\n🎉 SUCCESS: Audio response generated!');
      console.log('🔊 Audio URL:', testVoiceData.audioResponseUrl);
      console.log('💡 You should be able to play the audio response');
    } else {
      console.log('\n❌ FAILURE: No audio response generated');
      console.log('🔍 Check the server logs for more details');
    }

  } catch (error) {
    console.error('❌ Error testing Deepgram TTS audio:', error);
  }
}

// Run the test
testDeepgramTTSAudio(); 