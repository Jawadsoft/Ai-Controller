import { pool } from './src/database/connection.js';

async function testTTSWithDealerSettings() {
  try {
    console.log('🧪 Testing TTS with Dealer-Specific Settings...\n');
    
    // Test 1: Check if we have dealer-specific voice settings
    console.log('📋 Test 1: Checking Dealer-Specific Voice Settings');
    
    const dealerVoiceQuery = `
      SELECT dealer_id, setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL AND setting_type IN ('voice_enabled', 'voice_tts_provider', 'elevenlabs_key', 'openai_key', 'deepgram_key')
      ORDER BY dealer_id, setting_type
    `;
    
    const dealerResult = await pool.query(dealerVoiceQuery);
    
    if (dealerResult.rows.length > 0) {
      console.log('✅ Found dealer-specific voice settings:');
      let currentDealer = '';
      dealerResult.rows.forEach(row => {
        if (row.dealer_id !== currentDealer) {
          currentDealer = row.dealer_id;
          console.log(`\n   Dealer ${row.dealer_id}:`);
        }
        const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
          row.setting_value.substring(0, 8) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          row.setting_value;
        console.log(`     ${row.setting_type}: ${maskedValue}`);
      });
    } else {
      console.log('❌ No dealer-specific voice settings found');
    }
    
    // Test 2: Check if we have global voice settings
    console.log('\n📋 Test 2: Checking Global Voice Settings');
    
    const globalVoiceQuery = `
      SELECT setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type IN ('voice_enabled', 'voice_tts_provider', 'elevenlabs_key', 'openai_key', 'deepgram_key')
      ORDER BY setting_type
    `;
    
    const globalResult = await pool.query(globalVoiceQuery);
    
    if (globalResult.rows.length > 0) {
      console.log('✅ Found global voice settings:');
      globalResult.rows.forEach(row => {
        const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
          row.setting_value.substring(0, 8) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          row.setting_value;
        console.log(`   ${row.setting_type}: ${maskedValue}`);
      });
    } else {
      console.log('❌ No global voice settings found');
    }
    
    // Test 3: Test the query pattern used by TTS
    console.log('\n🔍 Test 3: Testing Current TTS Query Pattern');
    
    const currentTTSQuery = `
      SELECT setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
      LIMIT 1
    `;
    
    const currentResult = await pool.query(currentTTSQuery);
    console.log(`Current TTS query finds: ${currentResult.rows.length} results`);
    
    if (currentResult.rows.length > 0) {
      console.log(`   voice_enabled: ${currentResult.rows[0].setting_value}`);
    } else {
      console.log('   ❌ No voice_enabled setting found with current query');
    }
    
    // Test 4: Test dealer-specific query with fallback
    console.log('\n💡 Test 4: Testing Dealer-Specific Query with Global Fallback');
    
    // Get a test dealer ID
    const dealerQuery = 'SELECT id FROM dealers LIMIT 1';
    const dealerIdResult = await pool.query(dealerQuery);
    
    if (dealerIdResult.rows.length > 0) {
      const testDealerId = dealerIdResult.rows[0].id;
      console.log(`Using test dealer ID: ${testDealerId}`);
      
      const newTTSQuery = `
        WITH dealer_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id = $1 AND setting_type = 'voice_enabled'
        ),
        global_setting AS (
          SELECT setting_value FROM daive_api_settings 
          WHERE dealer_id IS NULL AND setting_type = 'voice_enabled'
        )
        SELECT setting_value FROM dealer_setting
        UNION ALL
        SELECT setting_value FROM global_setting
        WHERE NOT EXISTS (SELECT 1 FROM dealer_setting)
        LIMIT 1
      `;
      
      const newResult = await pool.query(newTTSQuery, [testDealerId]);
      console.log(`New TTS query finds: ${newResult.rows.length} results`);
      
      if (newResult.rows.length > 0) {
        console.log(`   voice_enabled: ${newResult.rows[0].setting_value}`);
        console.log('   ✅ Dealer-specific query with fallback works!');
      } else {
        console.log('   ❌ Dealer-specific query with fallback failed');
      }
    }
    
    console.log('\n📝 Summary:');
    console.log('   The issue is that TTS code still uses global queries (dealer_id IS NULL)');
    console.log('   But voice settings are now dealer-specific');
    console.log('   Solution: Update TTS queries to use dealer-specific with global fallback');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await pool.end();
  }
}

testTTSWithDealerSettings();