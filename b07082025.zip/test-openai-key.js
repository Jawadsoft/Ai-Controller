import fetch from 'node-fetch';
import { pool } from './src/database/connection.js';

async function testOpenAIKey() {
  console.log('🔑 Testing OpenAI API Key...\n');
  
  try {
    // Get the dealer's OpenAI API key
    console.log('1. Getting OpenAI API key from database...');
    const dealerQuery = `
      SELECT setting_value
      FROM daive_api_settings
      WHERE dealer_id = '0aa94346-ed1d-420e-8823-bcd97bf6456f' 
      AND setting_type = 'openai_key'
    `;
    
    const result = await pool.query(dealerQuery);
    
    if (result.rows.length === 0) {
      console.log('❌ No OpenAI API key found for dealer');
      return;
    }
    
    const openaiKey = result.rows[0].setting_value;
    console.log('✅ OpenAI API key found');
    console.log('📝 Key starts with:', openaiKey.substring(0, 8) + '...');
    
    // Test 1: Test OpenAI API key with a simple completion
    console.log('\n2. Testing OpenAI API key with completion...');
    const completionResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'user', content: 'Say "Hello, this is a test" and nothing else.' }
        ],
        max_tokens: 50
      })
    });
    
    if (completionResponse.ok) {
      const completionData = await completionResponse.json();
      console.log('✅ OpenAI API key is valid');
      console.log('📝 Test response:', completionData.choices[0]?.message?.content);
    } else {
      const errorText = await completionResponse.text();
      console.log('❌ OpenAI API key test failed');
      console.log('Status:', completionResponse.status);
      console.log('Error:', errorText);
    }
    
    // Test 2: Test Whisper API directly
    console.log('\n3. Testing Whisper API directly...');
    
    // Create a simple test audio file
    const fs = await import('fs');
    const path = await import('path');
    
    const testAudioPath = path.join(process.cwd(), 'test-whisper-direct.wav');
    
    // Create a simple WAV file
    const sampleRate = 16000;
    const duration = 2; // 2 seconds
    const numSamples = sampleRate * duration;
    
    // WAV header
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + numSamples * 2, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * 2, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write('data', 36);
    header.writeUInt32LE(numSamples * 2, 40);
    
    // Generate a simple tone
    const audioData = Buffer.alloc(numSamples * 2);
    for (let i = 0; i < numSamples; i++) {
      const sample = Math.sin(2 * Math.PI * 440 * i / sampleRate) * 0.3;
      audioData.writeInt16LE(Math.floor(sample * 32767), i * 2);
    }
    
    const wavFile = Buffer.concat([header, audioData]);
    fs.writeFileSync(testAudioPath, wavFile);
    
    // Test Whisper API
    const FormData = (await import('form-data')).default;
    const formData = new FormData();
    formData.append('file', fs.createReadStream(testAudioPath), {
      filename: 'test.wav',
      contentType: 'audio/wav'
    });
    formData.append('model', 'whisper-1');
    
    const whisperResponse = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        ...formData.getHeaders()
      },
      body: formData
    });
    
    if (whisperResponse.ok) {
      const whisperData = await whisperResponse.json();
      console.log('✅ Whisper API is working');
      console.log('📝 Transcription:', whisperData.text);
    } else {
      const errorText = await whisperResponse.text();
      console.log('❌ Whisper API test failed');
      console.log('Status:', whisperResponse.status);
      console.log('Error:', errorText);
    }
    
    // Clean up
    if (fs.existsSync(testAudioPath)) {
      fs.unlinkSync(testAudioPath);
    }
    
  } catch (error) {
    console.error('❌ Error testing OpenAI API key:', error.message);
  } finally {
    await pool.end();
  }
}

testOpenAIKey(); 