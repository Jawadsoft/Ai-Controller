import { pool } from './src/database/connection.js';

async function testDAIVEFetchDealerId() {
  try {
    console.log('🔍 Testing DAIVE Settings Fetch - Dealer ID Behavior...\n');
    
    // Test 1: Check API Settings Fetch Behavior
    console.log('📋 Test 1: API Settings Fetch Behavior');
    console.log('Current implementation: WHERE dealer_id IS NULL (only global settings)');
    
    // Simulate the exact query used in the API settings endpoint
    const apiSettingsQuery = `
      SELECT setting_type, setting_value, is_active
      FROM daive_api_settings
      WHERE dealer_id IS NULL
      ORDER BY setting_type
    `;
    
    const apiResult = await pool.query(apiSettingsQuery);
    console.log(`✅ API Settings Fetched: ${apiResult.rows.length} global settings found`);
    
    apiResult.rows.forEach(row => {
      const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
        row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
        row.setting_value;
      console.log(`   ${row.setting_type}: ${maskedValue} (Active: ${row.is_active})`);
    });
    
    // Test 2: Check Voice Settings Fetch Behavior
    console.log('\n🎵 Test 2: Voice Settings Fetch Behavior');
    console.log('Current implementation: WHERE dealer_id IS NULL AND setting_type LIKE \'voice_%\'');
    
    // Simulate the exact query used in the voice settings endpoint
    const voiceSettingsQuery = `
      SELECT setting_type, setting_value
      FROM daive_api_settings
      WHERE dealer_id IS NULL AND setting_type LIKE 'voice_%'
    `;
    
    const voiceResult = await pool.query(voiceSettingsQuery);
    console.log(`✅ Voice Settings Fetched: ${voiceResult.rows.length} global voice settings found`);
    
    voiceResult.rows.forEach(row => {
      console.log(`   ${row.setting_type}: ${row.setting_value}`);
    });
    
    // Test 3: Check what dealer-specific settings exist (if any)
    console.log('\n🏢 Test 3: Checking for Dealer-Specific Settings');
    
    const dealerSpecificQuery = `
      SELECT dealer_id, setting_type, setting_value, 
             (SELECT business_name FROM dealers WHERE id = daive_api_settings.dealer_id) as dealer_name
      FROM daive_api_settings
      WHERE dealer_id IS NOT NULL
      ORDER BY dealer_id, setting_type
    `;
    
    const dealerSpecificResult = await pool.query(dealerSpecificQuery);
    
    if (dealerSpecificResult.rows.length > 0) {
      console.log(`✅ Found ${dealerSpecificResult.rows.length} dealer-specific settings:`);
      
      let currentDealerId = '';
      dealerSpecificResult.rows.forEach(row => {
        if (row.dealer_id !== currentDealerId) {
          currentDealerId = row.dealer_id;
          console.log(`\n   Dealer: ${row.dealer_name || 'Unknown'} (${row.dealer_id}):`);
        }
        const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
          row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          row.setting_value;
        console.log(`     ${row.setting_type}: ${maskedValue}`);
      });
    } else {
      console.log('❌ No dealer-specific settings found in database');
    }
    
    // Test 4: Demonstrate what dealer-specific fetch would look like
    console.log('\n💡 Test 4: Demonstrating Dealer-Specific Fetch');
    
    const dealerQuery = 'SELECT id, business_name FROM dealers LIMIT 1';
    const dealerResult = await pool.query(dealerQuery);
    
    if (dealerResult.rows.length > 0) {
      const testDealerId = dealerResult.rows[0].id;
      const businessName = dealerResult.rows[0].business_name;
      
      console.log(`Using dealer: ${businessName} (ID: ${testDealerId})`);
      
      // Create some test dealer-specific settings
      const testSettings = [
        ['test_dealer_openai_key', 'sk-dealer-specific-openai-key-123'],
        ['test_dealer_voice_provider', 'dealer_custom_elevenlabs'],
        ['test_dealer_voice_enabled', 'true']
      ];
      
      console.log('\n🔧 Creating test dealer-specific settings...');
      for (const [settingType, settingValue] of testSettings) {
        await pool.query(
          `INSERT INTO daive_api_settings (dealer_id, setting_type, setting_value)
           VALUES ($1, $2, $3)
           ON CONFLICT (dealer_id, setting_type) 
           DO UPDATE SET setting_value = $3, updated_at = NOW()`,
          [testDealerId, settingType, settingValue]
        );
      }
      console.log('✅ Test dealer-specific settings created');
      
      // Show current fetch behavior (ignores dealer-specific settings)
      console.log('\n📊 Current Fetch Behavior (Global Only):');
      const currentFetchResult = await pool.query(apiSettingsQuery);
      const globalTestSettings = currentFetchResult.rows.filter(row => 
        row.setting_type.startsWith('test_dealer_')
      );
      
      if (globalTestSettings.length > 0) {
        console.log('   Global test settings found:');
        globalTestSettings.forEach(row => {
          console.log(`     ${row.setting_type}: ${row.setting_value}`);
        });
      } else {
        console.log('   ❌ No test settings found in global fetch (as expected)');
      }
      
      // Show what dealer-specific fetch would return
      console.log('\n🎯 Proposed Dealer-Specific Fetch:');
      const dealerSpecificFetchQuery = `
        SELECT setting_type, setting_value, is_active
        FROM daive_api_settings
        WHERE dealer_id = $1 OR dealer_id IS NULL
        ORDER BY dealer_id NULLS LAST, setting_type
      `;
      
      const dealerSpecificFetchResult = await pool.query(dealerSpecificFetchQuery, [testDealerId]);
      console.log(`   Found ${dealerSpecificFetchResult.rows.length} settings (dealer-specific + global):`);
      
      dealerSpecificFetchResult.rows.forEach(row => {
        if (row.setting_type.startsWith('test_dealer_')) {
          const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
            row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
            row.setting_value;
          console.log(`     ${row.setting_type}: ${maskedValue} (dealer-specific)`);
        }
      });
      
      // Show priority-based fetch (dealer-specific overrides global)
      console.log('\n🏆 Priority-Based Fetch (Dealer > Global):');
      const priorityFetchQuery = `
        WITH dealer_settings AS (
          SELECT setting_type, setting_value, is_active, 'dealer' as source
          FROM daive_api_settings 
          WHERE dealer_id = $1
        ),
        global_settings AS (
          SELECT setting_type, setting_value, is_active, 'global' as source
          FROM daive_api_settings 
          WHERE dealer_id IS NULL
        ),
        combined_settings AS (
          SELECT * FROM dealer_settings
          UNION ALL
          SELECT * FROM global_settings
          WHERE setting_type NOT IN (SELECT setting_type FROM dealer_settings)
        )
        SELECT * FROM combined_settings ORDER BY setting_type
      `;
      
      const priorityResult = await pool.query(priorityFetchQuery, [testDealerId]);
      const priorityTestSettings = priorityResult.rows.filter(row => 
        row.setting_type.startsWith('test_dealer_') || 
        ['openai_key', 'elevenlabs_key', 'voice_provider'].includes(row.setting_type)
      );
      
      console.log('   Sample settings with priority (dealer overrides global):');
      priorityTestSettings.forEach(row => {
        const maskedValue = row.setting_value && row.setting_value.length > 15 ? 
          row.setting_value.substring(0, 10) + '...' + row.setting_value.substring(row.setting_value.length - 4) :
          row.setting_value;
        console.log(`     ${row.setting_type}: ${maskedValue} (${row.source})`);
      });
      
      // Clean up test data
      console.log('\n🧹 Cleaning up test data...');
      for (const [settingType] of testSettings) {
        await pool.query(
          'DELETE FROM daive_api_settings WHERE dealer_id = $1 AND setting_type = $2',
          [testDealerId, settingType]
        );
      }
      console.log('✅ Test data cleaned up');
      
    } else {
      console.log('❌ No dealers found in database for testing');
    }
    
    console.log('\n📝 Summary of Current DAIVE Settings Fetch Behavior:');
    console.log('   ❌ API Settings: Fetches ONLY global settings (dealer_id IS NULL)');
    console.log('   ❌ Voice Settings: Fetches ONLY global voice settings (dealer_id IS NULL)');
    console.log('   ❌ No dealer context used in fetch queries');
    console.log('   ❌ Dealer-specific settings are ignored even if they exist');
    console.log('   ❌ No authentication token or dealer_id checking in GET endpoints');
    
    console.log('\n💡 Recommendations:');
    console.log('   1. Add authenticateToken middleware to GET endpoints');
    console.log('   2. Use req.user.dealer_id in fetch queries');
    console.log('   3. Implement priority-based fetching (dealer-specific > global)');
    console.log('   4. Consider fallback to global settings when dealer-specific not available');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error);
    console.error('Stack trace:', error.stack);
  } finally {
    await pool.end();
  }
}

// Run the test
testDAIVEFetchDealerId();