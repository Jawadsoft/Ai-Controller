const fetch = require('node-fetch');
const fs = require('fs');

console.log('🔍 Comparing API calls between DAIVEChat and AI Bot Page...\n');

// Test 1: DAIVEChat text chat
async function testDAIVEChatText() {
  console.log('1️⃣ Testing DAIVEChat text chat...');
  
  const daiveChatPayload = {
    vehicleId: '0fcaedd8-042e-4094-80ca-85cb71cd5584',
    sessionId: 'daivechat-test-comparison',
    message: 'Hello, I want to learn about vehicles',
    customerInfo: {
      name: 'D.A.I.V.E. Chat User',
      email: 'chat@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }
  };

  try {
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(daiveChatPayload)
    });

    const data = await response.json();
    
    console.log('📤 DAIVEChat request payload:', JSON.stringify(daiveChatPayload, null, 2));
    console.log('📥 DAIVEChat response:', {
      success: data.success,
      hasResponse: !!data.data?.response,
      responseLength: data.data?.response?.length || 0,
      leadScore: data.data?.leadScore,
      shouldHandoff: data.data?.shouldHandoff
    });
    
    return data.success && data.data?.response;
  } catch (error) {
    console.error('❌ DAIVEChat text chat error:', error.message);
    return false;
  }
}

// Test 2: AI Bot text chat
async function testAIBotText() {
  console.log('\n2️⃣ Testing AI Bot text chat...');
  
  const aiBotPayload = {
    vehicleId: '0fcaedd8-042e-4094-80ca-85cb71cd5584',
    sessionId: 'aibot-test-comparison',
    message: 'Hello, I want to learn about vehicles',
    customerInfo: {
      name: 'AI Bot User',
      email: 'aibot@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }
  };

  try {
    const response = await fetch('http://localhost:3000/api/daive/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(aiBotPayload)
    });

    const data = await response.json();
    
    console.log('📤 AI Bot request payload:', JSON.stringify(aiBotPayload, null, 2));
    console.log('📥 AI Bot response:', {
      success: data.success,
      hasResponse: !!data.data?.response,
      responseLength: data.data?.response?.length || 0,
      leadScore: data.data?.leadScore,
      shouldHandoff: data.data?.shouldHandoff
    });
    
    return data.success && data.data?.response;
  } catch (error) {
    console.error('❌ AI Bot text chat error:', error.message);
    return false;
  }
}

// Test 3: Check if there are any differences in the payloads
function comparePayloads() {
  console.log('\n3️⃣ Comparing request payloads...');
  
  const daiveChatPayload = {
    vehicleId: '0fcaedd8-042e-4094-80ca-85cb71cd5584',
    sessionId: 'daivechat-test-comparison',
    message: 'Hello, I want to learn about vehicles',
    customerInfo: {
      name: 'D.A.I.V.E. Chat User',
      email: 'chat@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }
  };

  const aiBotPayload = {
    vehicleId: '0fcaedd8-042e-4094-80ca-85cb71cd5584',
    sessionId: 'aibot-test-comparison',
    message: 'Hello, I want to learn about vehicles',
    customerInfo: {
      name: 'AI Bot User',
      email: 'aibot@example.com',
      dealerId: '0aa94346-ed1d-420e-8823-bcd97bf6456f'
    }
  };

  console.log('✅ Both payloads have the same structure');
  console.log('✅ Both include dealerId in customerInfo');
  console.log('✅ Both use the same vehicleId');
  console.log('✅ Both call the same endpoint: /api/daive/chat');
  
  return true;
}

async function runComparison() {
  console.log('🎯 Starting API comparison test...\n');
  
  const daiveChatWorks = await testDAIVEChatText();
  const aiBotWorks = await testAIBotText();
  const payloadsMatch = comparePayloads();
  
  console.log('\n📊 Comparison Results:');
  console.log(`✅ DAIVEChat text chat: ${daiveChatWorks ? 'Working' : 'Failed'}`);
  console.log(`✅ AI Bot text chat: ${aiBotWorks ? 'Working' : 'Failed'}`);
  console.log(`✅ Payloads match: ${payloadsMatch ? 'Yes' : 'No'}`);
  
  if (daiveChatWorks && aiBotWorks) {
    console.log('\n🎉 Both APIs are working correctly!');
    console.log('💡 The issue might be in the frontend React component');
    console.log('🔍 Check browser console for any JavaScript errors');
  } else if (daiveChatWorks && !aiBotWorks) {
    console.log('\n⚠️ DAIVEChat works but AI Bot doesn\'t');
    console.log('🔍 There might be a difference in the API calls');
  } else {
    console.log('\n❌ Both APIs are failing');
    console.log('🔍 Check backend server and database connection');
  }
}

runComparison().catch(console.error); 