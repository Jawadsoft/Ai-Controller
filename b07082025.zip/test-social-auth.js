import dotenv from 'dotenv';

dotenv.config();

console.log('🔍 Social Authentication Status Check');
console.log('=====================================');

// Check environment variables
const config = {
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    enabled: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
  },
  facebook: {
    appId: process.env.FACEBOOK_APP_ID,
    appSecret: process.env.FACEBOOK_APP_SECRET,
    enabled: !!(process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET)
  },
  github: {
    clientId: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    enabled: !!(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET)
  },
  session: {
    secret: process.env.SESSION_SECRET,
    configured: !!process.env.SESSION_SECRET
  },
  urls: {
    frontend: process.env.FRONTEND_URL || 'http://localhost:5173',
    backend: process.env.BACKEND_URL || 'http://localhost:3000'
  }
};

console.log('\n📋 Current Status:');
console.log('------------------');
console.log('🚫 Social Authentication: DISABLED');
console.log('✅ Traditional Email/Password: ENABLED');

console.log('\n📋 Environment Variables Status:');
console.log('--------------------------------');

// Google
console.log(`Google OAuth: ${config.google.enabled ? '✅ Configured' : '❌ Not configured'}`);
if (config.google.enabled) {
  console.log(`  Client ID: ${config.google.clientId ? '✅ Set' : '❌ Missing'}`);
  console.log(`  Client Secret: ${config.google.clientSecret ? '✅ Set' : '❌ Missing'}`);
}

// Facebook
console.log(`\nFacebook OAuth: ${config.facebook.enabled ? '✅ Configured' : '❌ Not configured'}`);
if (config.facebook.enabled) {
  console.log(`  App ID: ${config.facebook.appId ? '✅ Set' : '❌ Missing'}`);
  console.log(`  App Secret: ${config.facebook.appSecret ? '✅ Set' : '❌ Missing'}`);
}

// GitHub
console.log(`\nGitHub OAuth: ${config.github.enabled ? '✅ Configured' : '❌ Not configured'}`);
if (config.github.enabled) {
  console.log(`  Client ID: ${config.github.clientId ? '✅ Set' : '❌ Missing'}`);
  console.log(`  Client Secret: ${config.github.clientSecret ? '✅ Set' : '❌ Missing'}`);
}

// Session
console.log(`\nSession Secret: ${config.session.configured ? '✅ Set' : '❌ Not set'}`);

// URLs
console.log('\n🌐 URLs:');
console.log(`  Frontend: ${config.urls.frontend}`);
console.log(`  Backend: ${config.urls.backend}`);

// Summary
const enabledProviders = [config.google.enabled, config.facebook.enabled, config.github.enabled].filter(Boolean).length;

console.log('\n📊 Summary:');
console.log(`  Social providers configured: ${enabledProviders}/3`);
console.log(`  Session configured: ${config.session.configured ? 'Yes' : 'No'}`);

console.log('\n🚫 Social Authentication is currently DISABLED');
console.log('   The application will only use email/password authentication.');
console.log('   Social login buttons and routes have been disabled.');

console.log('\n🔧 To Re-enable Social Authentication Later:');
console.log('   1. Uncomment social auth routes in src/routes/auth.js');
console.log('   2. Uncomment passport strategies in src/lib/passport.js');
console.log('   3. Uncomment session middleware in src/server.js');
console.log('   4. Uncomment SocialLogin import in src/pages/Auth.tsx');
console.log('   5. Configure OAuth provider credentials in .env file');
console.log('   6. Follow SOCIAL_AUTH_SETUP.md for detailed instructions');

console.log('\n✅ Current Authentication Methods:');
console.log('   - Email/Password Login');
console.log('   - Email/Password Registration');
console.log('   - JWT Token Authentication');

console.log('\n🎯 Next Steps:');
console.log('   1. Start the application: npm run dev');
console.log('   2. Test traditional login at: http://localhost:5173/auth');
console.log('   3. Create accounts using email/password only'); 